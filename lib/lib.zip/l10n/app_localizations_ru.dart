// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Russian (`ru`).
class AppLocalizationsRu extends AppLocalizations {
  AppLocalizationsRu([String locale = 'ru']) : super(locale);

  @override
  String get appTitle => 'Оповещение QLD';

  @override
  String get noBuyZone => 'Зона без покупок';

  @override
  String get tapToViewStrategy => 'Посмотреть стратегию';

  @override
  String get buyNow => 'Купить сейчас';

  @override
  String get buyingInProgress => 'Покупка выполняется';

  @override
  String get hold => 'Держать';

  @override
  String get navHome => 'Домой';

  @override
  String get navChart => 'График';

  @override
  String get navExchange => 'Валюты';

  @override
  String get navFearGreed => 'Страх';

  @override
  String get fearGreedTitle => 'Страх и жадность';

  @override
  String get fearGreedSubtitle => 'Настроения рынка США от CNN';

  @override
  String get fearGreedUnavailable =>
      'Не удалось загрузить данные страха и жадности.';

  @override
  String get navAlert => 'Сигналы';

  @override
  String get navStrategy => 'Стратегия';

  @override
  String get alertRecovery10 => 'QLD восстановился на 10%';

  @override
  String get alertMarketOpen => 'Рынок США открылся';

  @override
  String get alertNewHigh => 'Достигнут новый максимум';

  @override
  String get portfolio => 'Портфель';

  @override
  String get portfolioAssetInput => 'Активы';

  @override
  String get portfolioClose => 'Закрыть';

  @override
  String get portfolioQldShares => 'Кол-во QLD';

  @override
  String get portfolioTqqqShares => 'Кол-во TQQQ';

  @override
  String get portfolioQldAveragePrice => 'Средняя цена QLD';

  @override
  String get portfolioTqqqAveragePrice => 'Средняя цена TQQQ';

  @override
  String get portfolioCashUsd => 'Деньги USD';

  @override
  String get portfolioTotal => 'Итого';

  @override
  String get portfolioProfitLoss => 'Приб./уб.';

  @override
  String get portfolioSharesUnit => 'акц.';

  @override
  String get portfolioReturnRate => 'Доходность';

  @override
  String get portfolioAveragePriceShort => 'Средняя цена';

  @override
  String get portfolioPriceLoading => 'загрузка цены';

  @override
  String get portfolioToBreakeven => 'До безубытка';

  @override
  String get portfolioBreakevenCleared => 'Выше безубытка';

  @override
  String get basePosition => 'Базовая позиция';

  @override
  String get from10yHigh => 'к максимуму 10 лет';

  @override
  String get holdQLDPlusCash => 'Держать QLD + 30% кэш';

  @override
  String get basePositionDescription =>
      '[ Strategy Guide ]\n\nThis strategy does not invest all assets into QLD at once.\n\nAt the beginning, only part of the assets is invested, while the rest is held in cash to prepare for major market declines.\n\nExample:\n- Invest only 70% of initial assets into QLD\n- Hold the remaining 30% in cash\n\nQLD is an ETF that tracks approximately 2x the daily movement of the Nasdaq-100 Index.\n\nTherefore, in the initial state:\n2x leverage × 70% investment = approximately 1.4x overall exposure.\n\nFor example:\n- Nasdaq +1%\n→ Total assets about +1.4%\n\nWhen a major decline occurs, the cash held is used step by step for additional buying.\n\nExample:\n- Additional buying around the QLD -40% zone\n\nThis allows more shares to be accumulated at lower prices, and when the market recovers, the average entry price can be significantly reduced.\n\nAs a result, this strategy may produce higher returns during recovery phases than a simple buy-and-hold strategy.\n\nThe core of this strategy is:\n- Reduce volatility with cash during rising markets\n- Use cash to buy more during major declines and lower the average cost.';

  @override
  String get buySignalMessage => 'Сигналы покупки появятся здесь.';

  @override
  String get currentPrice => 'Текущая цена';

  @override
  String get tenYearHigh => 'Максимум 10 лет';

  @override
  String get buyStrategy => 'Стратегия покупки';

  @override
  String get noBuyZoneTitle => 'Зона без покупок';

  @override
  String get strategyOverview => 'Обзор';

  @override
  String get corePrinciple => 'Главный принцип';

  @override
  String get suggestedAllocation => 'Рекомендуемое распределение';

  @override
  String get riskManagement => 'Управление риском';

  @override
  String get actionGuide => 'План действий';

  @override
  String get marketStable =>
      'The Nasdaq market has historically maintained a long-term upward trend driven by technological innovation and global growth companies in the United States. Based on this growth potential, ProShares Ultra QQQ (QLD) is a leveraged ETF designed to track 2x the daily performance of the Nasdaq-100 Index, making it an efficient investment vehicle during long-term bullish market conditions.\n\nHowever, due to the nature of leveraged ETFs, volatility and downside risk can increase significantly during market downturns. Therefore, disciplined risk management is more important than simple buy-and-hold strategies. Maintaining approximately 30% of total assets in cash while gradually buying during sharp declines can help lower the average entry price and maximize long-term compounded returns.\n\nIn other words, the core of the QLD strategy is to utilize leverage efficiency during bull markets while maintaining sufficient cash reserves to respond flexibly during market corrections.';

  @override
  String get noPanicSignals =>
      'The Nasdaq market is not simply a collection of companies. It operates through a continuous rebalancing and replacement mechanism that maintains competitiveness over time. Innovative companies with strong growth and profitability are added to the index, while weaker companies gradually lose weight or are removed.\n\nThis structure continuously reallocates capital toward productive and high-growth businesses, strengthening the market’s long-term growth potential. Supported by technological innovation in the United States, the expansion of global platform companies, and ongoing monetary liquidity growth, the Nasdaq has become one of the primary markets absorbing global capital flows.\n\nIn other words, the Nasdaq is not just a market that rises over time, but a structural growth system driven by constant innovation and corporate evolution. Because of these characteristics, it is widely viewed as a market with strong long-term upside potential that benefits from both technological advancement and monetary expansion.';

  @override
  String get maintainBalanced =>
      'Maintaining balanced positions and sufficient cash reserves allows for flexible responses during future market corrections.';

  @override
  String get cashReserveRule => 'Always maintain at least 30% cash reserves.';

  @override
  String get cashPsychology =>
      'Holding cash provides psychological stability and enables consistent buying opportunities during future market downturns.';

  @override
  String get allocation1 => '• Maintain core QLD positions';

  @override
  String get allocation2 =>
      '• Secure at least 30% cash by taking profits when possible';

  @override
  String get allocation3 => '• Never chase short-term price surges';

  @override
  String get allocation4 => '• Prepare for future buying opportunities';

  @override
  String get risk1 =>
      'Even strong bull markets can reverse sharply at any time.';

  @override
  String get risk2 =>
      'Lack of cash reserves can reduce flexibility during market corrections.';

  @override
  String get guide1 => '✅ Stay disciplined';

  @override
  String get guide2 => '✅ Maintain strategic cash reserves';

  @override
  String get guide3 => '✅ Focus on long-term positioning';

  @override
  String get guide4 => '❌ Avoid emotional overbuying';

  @override
  String get minus20Title => 'Стратегия -20%';

  @override
  String get minus20Headline => 'Начать дробные регулярные покупки QLD';

  @override
  String get minus20OverviewTitle => 'Strategy Overview';

  @override
  String get minus20OverviewText =>
      'This zone represents approximately a 10% correction in QQQ.\n\nSince the decline is still relatively moderate, maintaining cash reserves remains important.';

  @override
  String get minus20AllocationTitle => 'Suggested Allocation';

  @override
  String get minus20AllocationText =>
      '• Start accumulating with very small positions or simply hold\n• Proceed with slow and gradual buying\n• Avoid aggressive early entries\n• Preserve cash for larger potential declines';

  @override
  String get minus20HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus20HistoryText =>
      '• Average recovery period: approximately 1–2 months\n• Nasdaq has historically rebounded frequently after -20% corrections\n• Psychological pressure is relatively lower compared to major crashes';

  @override
  String get minus20RiskTitle => 'Risk Warning';

  @override
  String get minus20RiskText =>
      'Further downside is still possible after a -20% decline.\n\nAggressive early entries may create liquidity risk during deeper corrections.';

  @override
  String get minus20GuideTitle => 'Action Guide';

  @override
  String get minus20GuideText =>
      '✅ Start slowly\n✅ Buying is not mandatory at this stage\n✅ Maintain sufficient cash reserves\n❌ Avoid emotional buying';

  @override
  String get minus30Title => 'Стратегия -30%';

  @override
  String get minus30Headline => 'Купить TQQQ на 10% кэша';

  @override
  String get minus30OverviewTitle => 'Strategy Overview';

  @override
  String get minus30OverviewText =>
      'This zone represents a high-opportunity accumulation phase.\n\nHistorically, Nasdaq corrections around -30% have often provided strong long-term buying opportunities.\n\nAlthough fear and volatility increase significantly at this stage, disciplined dollar-cost averaging can improve long-term returns.';

  @override
  String get minus30AllocationTitle => 'Suggested Allocation';

  @override
  String get minus30AllocationText =>
      '• Deploy approximately 10% of available cash\n• Continue gradual accumulation\n• Avoid deploying all capital too quickly\n• Maintain flexibility for deeper declines';

  @override
  String get minus30HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus30HistoryText =>
      '• Average recovery period ranges from approximately 6 months to over 1 year\n• Historically, strong rebounds often followed -30% corrections\n• Volatility and psychological pressure increase significantly in this zone';

  @override
  String get minus30RiskTitle => 'Risk Warning';

  @override
  String get minus30RiskText =>
      'Markets may remain highly volatile even after a -30% decline.\n\nOvercommitting capital without cash reserves can increase both psychological and financial risks.';

  @override
  String get minus30GuideTitle => 'Action Guide';

  @override
  String get minus30GuideText =>
      '✅ Maintain disciplined accumulation\n✅ Control emotions\n✅ Preserve remaining cash\n❌ Avoid panic buying and excessive leverage';

  @override
  String get minus40Title => 'Стратегия -40%';

  @override
  String get minus40Headline => 'Использовать 30% кэша - вход TQQQ';

  @override
  String get minus40OverviewTitle => 'Strategy Overview';

  @override
  String get minus40OverviewText =>
      'The -40% zone is a period of extreme market fear, but it can also become an important long-term buying opportunity. Maintaining a planned strategy is more important than emotional reactions.';

  @override
  String get minus40AllocationTitle => 'Capital Allocation';

  @override
  String get minus40AllocationText =>
      'Avoid deploying all capital at once. Scale in gradually across multiple stages while preserving sufficient cash for potential further downside.';

  @override
  String get minus40HistoryTitle => 'Crash History';

  @override
  String get minus40HistoryText =>
      'Historically, markets have eventually recovered even after major crashes. Extreme fear zones have often created opportunities for long-term investors.';

  @override
  String get minus40RiskTitle => 'Psychological Risk';

  @override
  String get minus40RiskText =>
      'As declines deepen, fear and anxiety intensify. It is important to stay disciplined and avoid reacting emotionally to short-term volatility and news.';

  @override
  String get minus40GuideTitle => 'Survival Guide';

  @override
  String get minus40GuideText =>
      'Focus on long-term survival rather than predicting short-term rebounds. Avoid excessive leverage and emotional all-in positions while maintaining a consistent accumulation strategy.';

  @override
  String get minus50Title => 'Стратегия -50%';

  @override
  String get minus50Headline => 'Купить TQQQ на весь оставшийся кэш';

  @override
  String get minus50OverviewTitle => 'Deploy Remaining Cash into TQQQ';

  @override
  String get minus50OverviewText =>
      'A -50% decline represents an extreme market fear environment. Most investors experience panic during this phase, and volatility can remain exceptionally high.';

  @override
  String get minus50AllocationTitle => 'Capital Allocation';

  @override
  String get minus50AllocationText =>
      'Deploy remaining cash into TQQQ. Continue lowering the average entry price through systematic recurring purchases afterward.';

  @override
  String get minus50HistoryTitle => 'After Major Crashes';

  @override
  String get minus50HistoryText =>
      'Historically, markets have recovered over time following major crashes. The Nasdaq has structurally maintained long-term growth. Extreme fear should be viewed as opportunity rather than panic.';

  @override
  String get minus50RiskTitle => 'Psychological Pressure';

  @override
  String get minus50RiskText =>
      'Rather than feeling psychological pressure, investors should recognize this phase as a potential deep-value buying opportunity.';

  @override
  String get minus50GuideTitle => 'Survival Strategy';

  @override
  String get minus50GuideText =>
      'Accumulate TQQQ aggressively while continuously lowering the average cost basis through systematic recurring purchases.';

  @override
  String get exchangeUsdKrw => 'Доллар/вона';

  @override
  String get exchangeUsdJpy => 'Доллар/иена';

  @override
  String get exchangeEurUsd => 'Евро/доллар';

  @override
  String get exchangeUsdRub => 'Доллар/рубль';

  @override
  String get exchangeUsdTwd => 'Доллар/тайваньский доллар';

  @override
  String get exchangeUsdCny => 'Доллар/юань';

  @override
  String get fearGreedExtremeFear => 'Крайний страх';

  @override
  String get fearGreedFear => 'Страх';

  @override
  String get fearGreedNeutral => 'Нейтрально';

  @override
  String get fearGreedGreed => 'Жадность';

  @override
  String get fearGreedExtremeGreed => 'Крайняя жадность';

  @override
  String get fearGreedIndicatorsTitle => '7 индикаторов страха и жадности';

  @override
  String get fearGreedFaqTitle => 'Описание индекса страха и жадности';

  @override
  String get fearGreedWhatTitle => 'Что такое индекс страха и жадности CNN?';

  @override
  String get fearGreedWhatBody =>
      'Индекс показывает настроение фондового рынка и помогает оценить, выглядят ли акции справедливо оцененными. Чрезмерный страх часто давит на цены вниз, а чрезмерная жадность может толкать их вверх.';

  @override
  String get fearGreedCalculatedTitle => 'Как он рассчитывается?';

  @override
  String get fearGreedCalculatedBody =>
      'Индекс объединяет семь показателей: рыночный импульс, силу цен, ширину рынка, опционы put/call, спрос на мусорные облигации, волатильность и спрос на защитные активы. Каждый показатель имеет равный вес в шкале от 0 до 100.';

  @override
  String get fearGreedFrequencyTitle => 'Как часто он обновляется?';

  @override
  String get fearGreedFrequencyBody =>
      'Каждый компонент и общий индекс обновляются по мере появления новых рыночных данных.';

  @override
  String get fearGreedUseTitle => 'Как его использовать?';

  @override
  String get fearGreedUseBody =>
      'Используйте его как индикатор настроения рынка. Он помогает замечать эмоциональные крайности, но решения стоит сверять с ценой, фундаментальными факторами, управлением риском и собственной стратегией.';

  @override
  String get strategyAdLabel => 'Реклама';

  @override
  String get alertSettingsTitle => 'Настройки уведомлений';

  @override
  String get alertHighTitle => 'Уведомление о новом максимуме';

  @override
  String get alertHighSubtitle =>
      'Уведомлять, когда после установки достигнут новый максимум';

  @override
  String get alertMarketOpenTitle => 'Уведомление об открытии рынка';

  @override
  String get alertMarketOpenSubtitle =>
      'Уведомлять один раз в день при открытии регулярной сессии США';

  @override
  String get alertStrategySettingTitle => 'Уведомление стратегии';

  @override
  String get alertStrategySettingSubtitle =>
      'Уведомлять об изменениях зон -20%, -30%, -40% и -50%';

  @override
  String get noBuyHeadline =>
      'Не покупать дополнительно. Держать 30% наличными.';

  @override
  String get noBuyActionTitle => 'Немедленное действие';

  @override
  String get noBuyActionText =>
      'Не покупайте новые QLD/TQQQ. Сохраняйте текущую позицию QLD и держите 30% наличными.';

  @override
  String get noBuyCashTitle => 'Правило наличных';

  @override
  String get noBuyCashText =>
      'Наличные — резерв для следующей зоны падения. Не уменьшайте их даже при росте рынка.';

  @override
  String get noBuyAvoidTitle => 'Избегать';

  @override
  String get noBuyAvoidText =>
      'Не догоняйте цену только потому, что она растет. Ждите зоны -20%.';

  @override
  String get noBuyNextTitle => 'Следующий шаг';

  @override
  String get noBuyNextText =>
      'При достижении -20% подготовьте небольшие регулярные покупки QLD.';

  @override
  String get minus20ActionTitle => 'Немедленное действие';

  @override
  String get minus20ActionText =>
      'Начните очень маленькие регулярные покупки QLD. Не вкладывайте крупную сумму сразу.';

  @override
  String get minus20BuyRuleTitle => 'Правило покупки';

  @override
  String get minus20BuyRuleText =>
      'Используйте только малую часть наличных. Цель — начать ритм, а не сделать крупный вход.';

  @override
  String get minus20CashTitle => 'Управление наличными';

  @override
  String get minus20CashText =>
      'Большая часть наличных должна остаться для зон -30%, -40% и -50%.';

  @override
  String get minus20AvoidTitle => 'Избегать';

  @override
  String get minus20AvoidText =>
      'Не покупайте TQQQ агрессивно. Зона -20% все еще ранняя.';

  @override
  String get minus30ActionTitle => 'Немедленное действие';

  @override
  String get minus30ActionText =>
      'Используйте только 10% доступных наличных для покупки TQQQ. Перед ордером проверьте общий остаток.';

  @override
  String get minus30BuyRuleTitle => 'Правило покупки';

  @override
  String get minus30BuyRuleText =>
      'Если наличных \$10 000, используйте только \$1 000 для TQQQ и сохраните 90%.';

  @override
  String get minus30AdditionalTitle => 'Дополнительное действие';

  @override
  String get minus30AdditionalText =>
      'Накопление QLD можно продолжать, но дополнительные покупки TQQQ ждут следующей зоны.';

  @override
  String get minus30AvoidTitle => 'Избегать';

  @override
  String get minus30AvoidText =>
      'Не тратьте слишком много наличных из-за ожидания отскока. Действуйте так, будто зона -40% еще возможна.';

  @override
  String get minus40ActionTitle => 'Немедленное действие';

  @override
  String get minus40ActionText =>
      'Используйте 30% оставшихся наличных для покупки TQQQ. Исключите сумму, уже использованную на -30%.';

  @override
  String get minus40BuyRuleTitle => 'Правило покупки';

  @override
  String get minus40BuyRuleText =>
      'Если осталось \$9 000, используйте только \$2 700. Главное — не использовать все сразу.';

  @override
  String get minus40HoldTitle => 'Правило удержания';

  @override
  String get minus40HoldText =>
      'Держите QLD и увеличивайте TQQQ только до плановой доли. Оставьте наличные на дальнейшее падение.';

  @override
  String get minus40AvoidTitle => 'Избегать';

  @override
  String get minus40AvoidText =>
      'Не продавайте из страха. И не покупайте на все наличные из жадности.';

  @override
  String get minus50ActionTitle => 'Немедленное действие';

  @override
  String get minus50ActionText =>
      'Используйте все оставшиеся наличные для покупки TQQQ. Это последняя плановая стадия вложения наличных.';

  @override
  String get minus50BuyRuleTitle => 'Правило покупки';

  @override
  String get minus50BuyRuleText =>
      'Ориентируйтесь только на реальные оставшиеся наличные после сумм, использованных на -30% и -40%.';

  @override
  String get minus50AfterTitle => 'После этого';

  @override
  String get minus50AfterText =>
      'Когда появятся новые наличные, регулярно накапливайте TQQQ или QLD и снижайте среднюю цену.';

  @override
  String get minus50AvoidTitle => 'Избегать';

  @override
  String get minus50AvoidText =>
      'Не сдавайтесь только из-за большой просадки. Не используйте долги или краткосрочные деньги на докупку.';

  @override
  String get alertNasdaq200Title => 'Оповещение 200-дневной Nasdaq 100';

  @override
  String get alertNasdaq200Subtitle =>
      'Уведомлять при пробое Nasdaq 100 ниже или выше 200-дневной средней';

  @override
  String get alertNasdaq200Breakdown =>
      'Nasdaq 100 пробил вниз 200-дневную скользящую среднюю';

  @override
  String get alertNasdaq200Breakout =>
      'Nasdaq 100 снова пробил вверх 200-дневную скользящую среднюю';

  @override
  String get alertPortfolioCashTitle => 'Оповещение о ребалансировке наличных';

  @override
  String get alertPortfolioCashSubtitle =>
      'Уведомлять, когда доля наличных после роста акций падает ниже 20%';

  @override
  String get alertPortfolioCashHigh =>
      'Доля наличных ниже 20%. Рассмотрите ребалансировку для восстановления наличных.';

  @override
  String get alertPortfolioCashLow =>
      'Доля наличных ниже 20%. Рассмотрите ребалансировку для восстановления наличных.';

  @override
  String get alertAnnouncementTitle => 'Уведомления об объявлениях';

  @override
  String get alertAnnouncementSubtitle =>
      'Получать объявления от QLD DIP ALERT как push-уведомления';

  @override
  String get alertDetailTitle => 'Детали уведомления';

  @override
  String get alertDetailOpenStrategy => 'Открыть стратегию';

  @override
  String get alertDetailRecovery =>
      'Зона падения улучшилась. Спокойно проверьте портфель и избегайте поспешных сделок.';

  @override
  String get alertDetailNewHigh =>
      'После установки зафиксирован новый максимум. Он станет новой базой для расчета будущего снижения.';

  @override
  String get alertDetailMarketOpen =>
      'Регулярная сессия США открылась. Проверяйте цены и сигналы только если планировали действовать сегодня.';

  @override
  String get alertDetailNasdaq200Breakdown =>
      'Nasdaq 100 опустился ниже 200-дневной средней. Это может указывать на ослабление тренда; проверьте риск и наличные.';

  @override
  String get alertDetailNasdaq200Breakout =>
      'Nasdaq 100 вернулся выше 200-дневной средней. Это может указывать на улучшение тренда, но следуйте стратегии.';

  @override
  String get alertDetailPortfolioCashHigh =>
      'Доля наличных ниже ориентира 20%. Обычно это означает, что акции выросли, а денежный резерв стал слишком мал. Рассмотрите частичную фиксацию позиции и ребалансировку к плановой доле наличных.';

  @override
  String get alertDetailPortfolioCashLow =>
      'Доля наличных ниже ориентира 20%. Обычно это означает, что акции выросли, а денежный резерв стал слишком мал. Рассмотрите частичную фиксацию позиции и ребалансировку к плановой доле наличных.';

  @override
  String get alertDetailOpenLink => 'Открыть ссылку';

  @override
  String get appUpdateTitle => 'Доступно обновление';

  @override
  String get appUpdateMessage =>
      'Доступна новая версия. Обновите приложение, чтобы использовать последние функции и исправления.';

  @override
  String get appUpdateLater => 'Позже';

  @override
  String get appUpdateNow => 'Обновить';
}
