// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get appTitle => 'Alerte QLD';

  @override
  String get noBuyZone => 'Zone sans achat';

  @override
  String get tapToViewStrategy => 'Voir la stratégie';

  @override
  String get buyNow => 'Acheter maintenant';

  @override
  String get buyingInProgress => 'Achat en cours';

  @override
  String get hold => 'Conserver';

  @override
  String get navHome => 'Accueil';

  @override
  String get navChart => 'Graphique';

  @override
  String get navExchange => 'Devises';

  @override
  String get navFearGreed => 'Peur';

  @override
  String get fearGreedTitle => 'Peur et Avidité';

  @override
  String get fearGreedSubtitle => 'Sentiment du marché américain CNN';

  @override
  String get fearGreedUnavailable =>
      'Impossible de charger les données de peur et avidité.';

  @override
  String get navAlert => 'Alertes';

  @override
  String get navStrategy => 'Stratégie';

  @override
  String get alertRecovery10 => 'QLD a récupéré 10 %';

  @override
  String get alertMarketOpen => 'Le marché américain a ouvert';

  @override
  String get alertNewHigh => 'Nouveau plus haut atteint';

  @override
  String get portfolio => 'Portefeuille';

  @override
  String get portfolioAssetInput => 'Actifs';

  @override
  String get portfolioClose => 'Fermer';

  @override
  String get portfolioQldShares => 'Quantité QLD';

  @override
  String get portfolioTqqqShares => 'Quantité TQQQ';

  @override
  String get portfolioQldAveragePrice => 'Prix moyen QLD';

  @override
  String get portfolioTqqqAveragePrice => 'Prix moyen TQQQ';

  @override
  String get portfolioCashUsd => 'Cash USD';

  @override
  String get portfolioTotal => 'Total';

  @override
  String get portfolioProfitLoss => 'Gain/perte';

  @override
  String get portfolioSharesUnit => 'actions';

  @override
  String get portfolioReturnRate => 'Rendement';

  @override
  String get portfolioAveragePriceShort => 'Prix moyen';

  @override
  String get portfolioPriceLoading => 'chargement du prix';

  @override
  String get portfolioToBreakeven => 'Pour revenir à l’équilibre';

  @override
  String get portfolioBreakevenCleared => 'Au-dessus du point d’équilibre';

  @override
  String get basePosition => 'Position de base';

  @override
  String get from10yHigh => 'vs plus haut 10 ans';

  @override
  String get holdQLDPlusCash => 'Conserver QLD + 30% cash';

  @override
  String get basePositionDescription =>
      '[ Strategy Guide ]\n\nThis strategy does not invest all assets into QLD at once.\n\nAt the beginning, only part of the assets is invested, while the rest is held in cash to prepare for major market declines.\n\nExample:\n- Invest only 70% of initial assets into QLD\n- Hold the remaining 30% in cash\n\nQLD is an ETF that tracks approximately 2x the daily movement of the Nasdaq-100 Index.\n\nTherefore, in the initial state:\n2x leverage × 70% investment = approximately 1.4x overall exposure.\n\nFor example:\n- Nasdaq +1%\n→ Total assets about +1.4%\n\nWhen a major decline occurs, the cash held is used step by step for additional buying.\n\nExample:\n- Additional buying around the QLD -40% zone\n\nThis allows more shares to be accumulated at lower prices, and when the market recovers, the average entry price can be significantly reduced.\n\nAs a result, this strategy may produce higher returns during recovery phases than a simple buy-and-hold strategy.\n\nThe core of this strategy is:\n- Reduce volatility with cash during rising markets\n- Use cash to buy more during major declines and lower the average cost.';

  @override
  String get buySignalMessage => 'Les signaux d’achat apparaîtront ici.';

  @override
  String get currentPrice => 'Prix actuel';

  @override
  String get tenYearHigh => 'Plus haut 10 ans';

  @override
  String get buyStrategy => 'Stratégie d’achat';

  @override
  String get noBuyZoneTitle => 'Zone sans achat';

  @override
  String get strategyOverview => 'Aperçu';

  @override
  String get corePrinciple => 'Principe clé';

  @override
  String get suggestedAllocation => 'Allocation suggérée';

  @override
  String get riskManagement => 'Gestion du risque';

  @override
  String get actionGuide => 'Guide d’action';

  @override
  String get marketStable =>
      'The Nasdaq market has historically maintained a long-term upward trend driven by technological innovation and global growth companies in the United States. Based on this growth potential, ProShares Ultra QQQ (QLD) is a leveraged ETF designed to track 2x the daily performance of the Nasdaq-100 Index, making it an efficient investment vehicle during long-term bullish market conditions.\n\nHowever, due to the nature of leveraged ETFs, volatility and downside risk can increase significantly during market downturns. Therefore, disciplined risk management is more important than simple buy-and-hold strategies. Maintaining approximately 30% of total assets in cash while gradually buying during sharp declines can help lower the average entry price and maximize long-term compounded returns.\n\nIn other words, the core of the QLD strategy is to utilize leverage efficiency during bull markets while maintaining sufficient cash reserves to respond flexibly during market corrections.';

  @override
  String get noPanicSignals =>
      'The Nasdaq market is not simply a collection of companies. It operates through a continuous rebalancing and replacement mechanism that maintains competitiveness over time. Innovative companies with strong growth and profitability are added to the index, while weaker companies gradually lose weight or are removed.\n\nThis structure continuously reallocates capital toward productive and high-growth businesses, strengthening the market’s long-term growth potential. Supported by technological innovation in the United States, the expansion of global platform companies, and ongoing monetary liquidity growth, the Nasdaq has become one of the primary markets absorbing global capital flows.\n\nIn other words, the Nasdaq is not just a market that rises over time, but a structural growth system driven by constant innovation and corporate evolution. Because of these characteristics, it is widely viewed as a market with strong long-term upside potential that benefits from both technological advancement and monetary expansion.';

  @override
  String get maintainBalanced =>
      'Maintaining balanced positions and sufficient cash reserves allows for flexible responses during future market corrections.';

  @override
  String get cashReserveRule => 'Always maintain at least 30% cash reserves.';

  @override
  String get cashPsychology =>
      'Holding cash provides psychological stability and enables consistent buying opportunities during future market downturns.';

  @override
  String get allocation1 => '• Maintain core QLD positions';

  @override
  String get allocation2 =>
      '• Secure at least 30% cash by taking profits when possible';

  @override
  String get allocation3 => '• Never chase short-term price surges';

  @override
  String get allocation4 => '• Prepare for future buying opportunities';

  @override
  String get risk1 =>
      'Even strong bull markets can reverse sharply at any time.';

  @override
  String get risk2 =>
      'Lack of cash reserves can reduce flexibility during market corrections.';

  @override
  String get guide1 => '✅ Stay disciplined';

  @override
  String get guide2 => '✅ Maintain strategic cash reserves';

  @override
  String get guide3 => '✅ Focus on long-term positioning';

  @override
  String get guide4 => '❌ Avoid emotional overbuying';

  @override
  String get minus20Title => 'Stratégie -20%';

  @override
  String get minus20Headline =>
      'Commencer des achats fractionnés récurrents de QLD';

  @override
  String get minus20OverviewTitle => 'Strategy Overview';

  @override
  String get minus20OverviewText =>
      'This zone represents approximately a 10% correction in QQQ.\n\nSince the decline is still relatively moderate, maintaining cash reserves remains important.';

  @override
  String get minus20AllocationTitle => 'Suggested Allocation';

  @override
  String get minus20AllocationText =>
      '• Start accumulating with very small positions or simply hold\n• Proceed with slow and gradual buying\n• Avoid aggressive early entries\n• Preserve cash for larger potential declines';

  @override
  String get minus20HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus20HistoryText =>
      '• Average recovery period: approximately 1–2 months\n• Nasdaq has historically rebounded frequently after -20% corrections\n• Psychological pressure is relatively lower compared to major crashes';

  @override
  String get minus20RiskTitle => 'Risk Warning';

  @override
  String get minus20RiskText =>
      'Further downside is still possible after a -20% decline.\n\nAggressive early entries may create liquidity risk during deeper corrections.';

  @override
  String get minus20GuideTitle => 'Action Guide';

  @override
  String get minus20GuideText =>
      '✅ Start slowly\n✅ Buying is not mandatory at this stage\n✅ Maintain sufficient cash reserves\n❌ Avoid emotional buying';

  @override
  String get minus30Title => 'Stratégie -30%';

  @override
  String get minus30Headline => 'Acheter TQQQ avec 10% du cash';

  @override
  String get minus30OverviewTitle => 'Strategy Overview';

  @override
  String get minus30OverviewText =>
      'This zone represents a high-opportunity accumulation phase.\n\nHistorically, Nasdaq corrections around -30% have often provided strong long-term buying opportunities.\n\nAlthough fear and volatility increase significantly at this stage, disciplined dollar-cost averaging can improve long-term returns.';

  @override
  String get minus30AllocationTitle => 'Suggested Allocation';

  @override
  String get minus30AllocationText =>
      '• Deploy approximately 10% of available cash\n• Continue gradual accumulation\n• Avoid deploying all capital too quickly\n• Maintain flexibility for deeper declines';

  @override
  String get minus30HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus30HistoryText =>
      '• Average recovery period ranges from approximately 6 months to over 1 year\n• Historically, strong rebounds often followed -30% corrections\n• Volatility and psychological pressure increase significantly in this zone';

  @override
  String get minus30RiskTitle => 'Risk Warning';

  @override
  String get minus30RiskText =>
      'Markets may remain highly volatile even after a -30% decline.\n\nOvercommitting capital without cash reserves can increase both psychological and financial risks.';

  @override
  String get minus30GuideTitle => 'Action Guide';

  @override
  String get minus30GuideText =>
      '✅ Maintain disciplined accumulation\n✅ Control emotions\n✅ Preserve remaining cash\n❌ Avoid panic buying and excessive leverage';

  @override
  String get minus40Title => 'Stratégie -40%';

  @override
  String get minus40Headline => 'Utiliser 30% cash - entrée TQQQ';

  @override
  String get minus40OverviewTitle => 'Strategy Overview';

  @override
  String get minus40OverviewText =>
      'The -40% zone is a period of extreme market fear, but it can also become an important long-term buying opportunity. Maintaining a planned strategy is more important than emotional reactions.';

  @override
  String get minus40AllocationTitle => 'Capital Allocation';

  @override
  String get minus40AllocationText =>
      'Avoid deploying all capital at once. Scale in gradually across multiple stages while preserving sufficient cash for potential further downside.';

  @override
  String get minus40HistoryTitle => 'Crash History';

  @override
  String get minus40HistoryText =>
      'Historically, markets have eventually recovered even after major crashes. Extreme fear zones have often created opportunities for long-term investors.';

  @override
  String get minus40RiskTitle => 'Psychological Risk';

  @override
  String get minus40RiskText =>
      'As declines deepen, fear and anxiety intensify. It is important to stay disciplined and avoid reacting emotionally to short-term volatility and news.';

  @override
  String get minus40GuideTitle => 'Survival Guide';

  @override
  String get minus40GuideText =>
      'Focus on long-term survival rather than predicting short-term rebounds. Avoid excessive leverage and emotional all-in positions while maintaining a consistent accumulation strategy.';

  @override
  String get minus50Title => 'Stratégie -50%';

  @override
  String get minus50Headline => 'Acheter TQQQ avec tout le cash restant';

  @override
  String get minus50OverviewTitle => 'Deploy Remaining Cash into TQQQ';

  @override
  String get minus50OverviewText =>
      'A -50% decline represents an extreme market fear environment. Most investors experience panic during this phase, and volatility can remain exceptionally high.';

  @override
  String get minus50AllocationTitle => 'Capital Allocation';

  @override
  String get minus50AllocationText =>
      'Deploy remaining cash into TQQQ. Continue lowering the average entry price through systematic recurring purchases afterward.';

  @override
  String get minus50HistoryTitle => 'After Major Crashes';

  @override
  String get minus50HistoryText =>
      'Historically, markets have recovered over time following major crashes. The Nasdaq has structurally maintained long-term growth. Extreme fear should be viewed as opportunity rather than panic.';

  @override
  String get minus50RiskTitle => 'Psychological Pressure';

  @override
  String get minus50RiskText =>
      'Rather than feeling psychological pressure, investors should recognize this phase as a potential deep-value buying opportunity.';

  @override
  String get minus50GuideTitle => 'Survival Strategy';

  @override
  String get minus50GuideText =>
      'Accumulate TQQQ aggressively while continuously lowering the average cost basis through systematic recurring purchases.';

  @override
  String get exchangeUsdKrw => 'Dollar/Won';

  @override
  String get exchangeUsdJpy => 'Dollar/Yen';

  @override
  String get exchangeEurUsd => 'Euro/Dollar';

  @override
  String get exchangeUsdRub => 'Dollar/Rouble';

  @override
  String get exchangeUsdTwd => 'Dollar/Dollar taïwanais';

  @override
  String get exchangeUsdCny => 'Dollar/Yuan';

  @override
  String get fearGreedExtremeFear => 'Peur extrême';

  @override
  String get fearGreedFear => 'Peur';

  @override
  String get fearGreedNeutral => 'Neutre';

  @override
  String get fearGreedGreed => 'Cupidité';

  @override
  String get fearGreedExtremeGreed => 'Cupidité extrême';

  @override
  String get fearGreedIndicatorsTitle => '7 indicateurs de peur et cupidité';

  @override
  String get fearGreedFaqTitle => 'Questions sur l’indice peur et cupidité';

  @override
  String get fearGreedWhatTitle => 'Qu’est-ce que l’indice CNN Fear & Greed ?';

  @override
  String get fearGreedWhatBody =>
      'L’indice mesure le sentiment du marché actions et aide à juger si les actions semblent correctement valorisées. Une peur excessive tend à faire baisser les prix, tandis qu’une cupidité excessive peut les pousser à la hausse.';

  @override
  String get fearGreedCalculatedTitle => 'Comment est-il calculé ?';

  @override
  String get fearGreedCalculatedBody =>
      'Il combine sept indicateurs : momentum du marché, force des prix, largeur du marché, options put/call, demande d’obligations à haut risque, volatilité et demande d’actifs refuges. Chaque indicateur a le même poids sur une échelle de 0 à 100.';

  @override
  String get fearGreedFrequencyTitle =>
      'À quelle fréquence est-il mis à jour ?';

  @override
  String get fearGreedFrequencyBody =>
      'Chaque composant et l’indice global sont mis à jour lorsque de nouvelles données de marché sont disponibles.';

  @override
  String get fearGreedUseTitle => 'Comment l’utiliser ?';

  @override
  String get fearGreedUseBody =>
      'Utilisez-le comme indicateur d’humeur du marché. Il aide à repérer les excès émotionnels, mais les décisions doivent aussi tenir compte du prix, des fondamentaux, du risque et de votre stratégie.';

  @override
  String get strategyAdLabel => 'Annonce';

  @override
  String get alertSettingsTitle => 'Paramètres d’alerte';

  @override
  String get alertHighTitle => 'Alerte nouveau plus haut';

  @override
  String get alertHighSubtitle =>
      'Prévenir quand un nouveau plus haut est atteint après installation';

  @override
  String get alertMarketOpenTitle => 'Alerte ouverture du marché';

  @override
  String get alertMarketOpenSubtitle =>
      'Prévenir une fois par jour à l’ouverture du marché régulier américain';

  @override
  String get alertStrategySettingTitle => 'Alerte stratégie';

  @override
  String get alertStrategySettingSubtitle =>
      'Prévenir lors des changements de zones -20 %, -30 %, -40 % et -50 %';

  @override
  String get noBuyHeadline => 'Ne pas acheter plus. Garder 30 % de liquidités.';

  @override
  String get noBuyActionTitle => 'Action immédiate';

  @override
  String get noBuyActionText =>
      'N’achetez pas de nouveaux QLD/TQQQ. Gardez la position QLD actuelle et protégez 30 % de liquidités.';

  @override
  String get noBuyCashTitle => 'Règle de liquidités';

  @override
  String get noBuyCashText =>
      'Les liquidités servent de réserve pour la prochaine zone de baisse. Ne les réduisez pas même si le marché monte.';

  @override
  String get noBuyAvoidTitle => 'À éviter';

  @override
  String get noBuyAvoidText =>
      'Ne poursuivez pas le prix parce qu’il monte. Attendez la zone de -20 %.';

  @override
  String get noBuyNextTitle => 'Étape suivante';

  @override
  String get noBuyNextText =>
      'À -20 %, préparez des achats fractionnés réguliers de QLD.';

  @override
  String get minus20ActionTitle => 'Action immédiate';

  @override
  String get minus20ActionText =>
      'Commencez de très petits achats fractionnés de QLD. N’investissez pas une grosse somme d’un coup.';

  @override
  String get minus20BuyRuleTitle => 'Règle d’achat';

  @override
  String get minus20BuyRuleText =>
      'Utilisez seulement une très petite partie des liquidités. Le but est de lancer le rythme, pas d’entrer fortement.';

  @override
  String get minus20CashTitle => 'Gestion des liquidités';

  @override
  String get minus20CashText =>
      'La majorité des liquidités doit rester disponible pour les zones -30 %, -40 % et -50 %.';

  @override
  String get minus20AvoidTitle => 'À éviter';

  @override
  String get minus20AvoidText =>
      'N’achetez pas TQQQ de façon agressive. La zone -20 % reste une phase initiale.';

  @override
  String get minus30ActionTitle => 'Action immédiate';

  @override
  String get minus30ActionText =>
      'Utilisez seulement 10 % des liquidités disponibles pour acheter TQQQ. Vérifiez le total avant l’ordre.';

  @override
  String get minus30BuyRuleTitle => 'Règle d’achat';

  @override
  String get minus30BuyRuleText =>
      'Avec \$10 000 de liquidités, utilisez seulement \$1 000 pour TQQQ et gardez les 90 % restants.';

  @override
  String get minus30AdditionalTitle => 'Action supplémentaire';

  @override
  String get minus30AdditionalText =>
      'L’accumulation de QLD peut continuer, mais attendez la prochaine zone pour racheter TQQQ.';

  @override
  String get minus30AvoidTitle => 'À éviter';

  @override
  String get minus30AvoidText =>
      'Ne dépensez pas trop de liquidités en anticipant un rebond. Agissez comme si la zone -40 % pouvait encore arriver.';

  @override
  String get minus40ActionTitle => 'Action immédiate';

  @override
  String get minus40ActionText =>
      'Utilisez 30 % des liquidités restantes pour acheter TQQQ. Excluez le montant déjà utilisé à -30 %.';

  @override
  String get minus40BuyRuleTitle => 'Règle d’achat';

  @override
  String get minus40BuyRuleText =>
      'S’il reste \$9 000, utilisez seulement \$2 700. L’essentiel est de ne pas tout utiliser d’un coup.';

  @override
  String get minus40HoldTitle => 'Règle de conservation';

  @override
  String get minus40HoldText =>
      'Gardez QLD et augmentez TQQQ seulement jusqu’au montant prévu. Gardez du cash pour une baisse supplémentaire.';

  @override
  String get minus40AvoidTitle => 'À éviter';

  @override
  String get minus40AvoidText =>
      'Ne vendez pas par peur. N’achetez pas non plus avec tout le cash par avidité.';

  @override
  String get minus50ActionTitle => 'Action immédiate';

  @override
  String get minus50ActionText =>
      'Utilisez toutes les liquidités restantes pour acheter TQQQ. C’est la dernière étape prévue de déploiement du cash.';

  @override
  String get minus50BuyRuleTitle => 'Règle d’achat';

  @override
  String get minus50BuyRuleText =>
      'Basez l’ordre uniquement sur le cash réellement restant après les achats à -30 % et -40 %.';

  @override
  String get minus50AfterTitle => 'Ensuite';

  @override
  String get minus50AfterText =>
      'Quand de nouvelles liquidités arrivent, accumulez régulièrement TQQQ ou QLD et concentrez-vous sur la baisse du prix moyen.';

  @override
  String get minus50AvoidTitle => 'À éviter';

  @override
  String get minus50AvoidText =>
      'N’abandonnez pas seulement parce que la perte est forte. N’utilisez ni dette ni argent de court terme pour racheter.';

  @override
  String get alertNasdaq200Title => 'Alerte moyenne 200 jours Nasdaq 100';

  @override
  String get alertNasdaq200Subtitle =>
      'Prévenir quand le Nasdaq 100 passe sous ou au-dessus de la moyenne 200 jours';

  @override
  String get alertNasdaq200Breakdown =>
      'Le Nasdaq 100 est passé sous sa moyenne mobile 200 jours';

  @override
  String get alertNasdaq200Breakout =>
      'Le Nasdaq 100 est repassé au-dessus de sa moyenne mobile 200 jours';

  @override
  String get alertPortfolioCashTitle => 'Alerte de rééquilibrage du cash';

  @override
  String get alertPortfolioCashSubtitle =>
      'Prévenir si le cash passe sous 20 % après une hausse';

  @override
  String get alertPortfolioCashHigh =>
      'Le cash est sous 20 %. Envisagez un rééquilibrage pour reconstituer du cash.';

  @override
  String get alertPortfolioCashLow =>
      'Le cash est sous 20 %. Envisagez un rééquilibrage pour reconstituer du cash.';

  @override
  String get alertAnnouncementTitle => 'Notifications d\'annonces';

  @override
  String get alertAnnouncementSubtitle =>
      'Recevoir les annonces envoyées par QLD DIP ALERT en notifications push';

  @override
  String get alertDetailTitle => 'Détail de l’alerte';

  @override
  String get alertDetailOpenStrategy => 'Voir la stratégie';

  @override
  String get alertDetailRecovery =>
      'La zone de baisse s’est améliorée. Vérifiez le portefeuille calmement et évitez les décisions impulsives.';

  @override
  String get alertDetailNewHigh =>
      'Un nouveau plus haut a été enregistré après installation. Il sert de nouvelle référence pour les futures baisses.';

  @override
  String get alertDetailMarketOpen =>
      'Le marché régulier américain a ouvert. Vérifiez les prix seulement si vous aviez prévu d’agir.';

  @override
  String get alertDetailNasdaq200Breakdown =>
      'Le Nasdaq 100 est passé sous sa moyenne 200 jours. La tendance peut s’affaiblir; vérifiez risque et liquidités.';

  @override
  String get alertDetailNasdaq200Breakout =>
      'Le Nasdaq 100 est repassé au-dessus de sa moyenne 200 jours. La tendance peut s’améliorer, mais suivez votre stratégie.';

  @override
  String get alertDetailPortfolioCashHigh =>
      'Le cash est sous le repère de 20 %. Cela signifie souvent que les actions ont monté et que la réserve de cash est trop faible. Envisagez d’alléger une partie de la position et de rééquilibrer vers le niveau de cash prévu.';

  @override
  String get alertDetailPortfolioCashLow =>
      'Le cash est sous le repère de 20 %. Cela signifie souvent que les actions ont monté et que la réserve de cash est trop faible. Envisagez d’alléger une partie de la position et de rééquilibrer vers le niveau de cash prévu.';

  @override
  String get alertDetailOpenLink => 'Ouvrir le lien';

  @override
  String get appUpdateTitle => 'Mise à jour disponible';

  @override
  String get appUpdateMessage =>
      'Une nouvelle version est disponible. Mettez à jour pour utiliser les dernières fonctions et corrections.';

  @override
  String get appUpdateLater => 'Plus tard';

  @override
  String get appUpdateNow => 'Mettre à jour';
}
