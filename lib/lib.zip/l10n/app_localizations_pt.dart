// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get appTitle => 'Alerta QLD';

  @override
  String get noBuyZone => 'Zona sem compra';

  @override
  String get tapToViewStrategy => 'Ver estratégia';

  @override
  String get buyNow => 'Comprar agora';

  @override
  String get buyingInProgress => 'Compra em andamento';

  @override
  String get hold => 'Manter';

  @override
  String get navHome => 'Início';

  @override
  String get navChart => 'Gráfico';

  @override
  String get navExchange => 'Câmbio';

  @override
  String get navFearGreed => 'Medo';

  @override
  String get fearGreedTitle => 'Medo e Ganância';

  @override
  String get fearGreedSubtitle => 'Sentimento do mercado dos EUA da CNN';

  @override
  String get fearGreedUnavailable =>
      'Não foi possível carregar os dados de medo e ganância.';

  @override
  String get navAlert => 'Alertas';

  @override
  String get navStrategy => 'Estratégia';

  @override
  String get alertRecovery10 => 'QLD recuperou 10%';

  @override
  String get alertMarketOpen => 'O mercado dos EUA abriu';

  @override
  String get alertNewHigh => 'Novo máximo atingido';

  @override
  String get portfolio => 'Carteira';

  @override
  String get portfolioAssetInput => 'Ativos';

  @override
  String get portfolioClose => 'Fechar';

  @override
  String get portfolioQldShares => 'Quantidade de QLD';

  @override
  String get portfolioTqqqShares => 'Quantidade de TQQQ';

  @override
  String get portfolioQldAveragePrice => 'Preço médio QLD';

  @override
  String get portfolioTqqqAveragePrice => 'Preço médio TQQQ';

  @override
  String get portfolioCashUsd => 'Caixa USD';

  @override
  String get portfolioTotal => 'Total';

  @override
  String get portfolioProfitLoss => 'Lucro/perda';

  @override
  String get portfolioSharesUnit => 'ações';

  @override
  String get portfolioReturnRate => 'Rentabilidade';

  @override
  String get portfolioAveragePriceShort => 'Preço médio';

  @override
  String get portfolioPriceLoading => 'carregando preço';

  @override
  String get portfolioToBreakeven => 'Para empatar';

  @override
  String get portfolioBreakevenCleared => 'Acima do ponto de equilíbrio';

  @override
  String get basePosition => 'Posição base';

  @override
  String get from10yHigh => 'vs máxima 10 anos';

  @override
  String get holdQLDPlusCash => 'Manter QLD + 30% caixa';

  @override
  String get basePositionDescription =>
      '[ Strategy Guide ]\n\nThis strategy does not invest all assets into QLD at once.\n\nAt the beginning, only part of the assets is invested, while the rest is held in cash to prepare for major market declines.\n\nExample:\n- Invest only 70% of initial assets into QLD\n- Hold the remaining 30% in cash\n\nQLD is an ETF that tracks approximately 2x the daily movement of the Nasdaq-100 Index.\n\nTherefore, in the initial state:\n2x leverage × 70% investment = approximately 1.4x overall exposure.\n\nFor example:\n- Nasdaq +1%\n→ Total assets about +1.4%\n\nWhen a major decline occurs, the cash held is used step by step for additional buying.\n\nExample:\n- Additional buying around the QLD -40% zone\n\nThis allows more shares to be accumulated at lower prices, and when the market recovers, the average entry price can be significantly reduced.\n\nAs a result, this strategy may produce higher returns during recovery phases than a simple buy-and-hold strategy.\n\nThe core of this strategy is:\n- Reduce volatility with cash during rising markets\n- Use cash to buy more during major declines and lower the average cost.';

  @override
  String get buySignalMessage => 'Os sinais de compra aparecerão aqui.';

  @override
  String get currentPrice => 'Preço atual';

  @override
  String get tenYearHigh => 'Máxima 10 anos';

  @override
  String get buyStrategy => 'Estratégia de compra';

  @override
  String get noBuyZoneTitle => 'Zona sem compra';

  @override
  String get strategyOverview => 'Visão geral';

  @override
  String get corePrinciple => 'Princípio central';

  @override
  String get suggestedAllocation => 'Alocação sugerida';

  @override
  String get riskManagement => 'Gestão de risco';

  @override
  String get actionGuide => 'Guia de ação';

  @override
  String get marketStable =>
      'The Nasdaq market has historically maintained a long-term upward trend driven by technological innovation and global growth companies in the United States. Based on this growth potential, ProShares Ultra QQQ (QLD) is a leveraged ETF designed to track 2x the daily performance of the Nasdaq-100 Index, making it an efficient investment vehicle during long-term bullish market conditions.\n\nHowever, due to the nature of leveraged ETFs, volatility and downside risk can increase significantly during market downturns. Therefore, disciplined risk management is more important than simple buy-and-hold strategies. Maintaining approximately 30% of total assets in cash while gradually buying during sharp declines can help lower the average entry price and maximize long-term compounded returns.\n\nIn other words, the core of the QLD strategy is to utilize leverage efficiency during bull markets while maintaining sufficient cash reserves to respond flexibly during market corrections.';

  @override
  String get noPanicSignals =>
      'The Nasdaq market is not simply a collection of companies. It operates through a continuous rebalancing and replacement mechanism that maintains competitiveness over time. Innovative companies with strong growth and profitability are added to the index, while weaker companies gradually lose weight or are removed.\n\nThis structure continuously reallocates capital toward productive and high-growth businesses, strengthening the market’s long-term growth potential. Supported by technological innovation in the United States, the expansion of global platform companies, and ongoing monetary liquidity growth, the Nasdaq has become one of the primary markets absorbing global capital flows.\n\nIn other words, the Nasdaq is not just a market that rises over time, but a structural growth system driven by constant innovation and corporate evolution. Because of these characteristics, it is widely viewed as a market with strong long-term upside potential that benefits from both technological advancement and monetary expansion.';

  @override
  String get maintainBalanced =>
      'Maintaining balanced positions and sufficient cash reserves allows for flexible responses during future market corrections.';

  @override
  String get cashReserveRule => 'Always maintain at least 30% cash reserves.';

  @override
  String get cashPsychology =>
      'Holding cash provides psychological stability and enables consistent buying opportunities during future market downturns.';

  @override
  String get allocation1 => '• Maintain core QLD positions';

  @override
  String get allocation2 =>
      '• Secure at least 30% cash by taking profits when possible';

  @override
  String get allocation3 => '• Never chase short-term price surges';

  @override
  String get allocation4 => '• Prepare for future buying opportunities';

  @override
  String get risk1 =>
      'Even strong bull markets can reverse sharply at any time.';

  @override
  String get risk2 =>
      'Lack of cash reserves can reduce flexibility during market corrections.';

  @override
  String get guide1 => '✅ Stay disciplined';

  @override
  String get guide2 => '✅ Maintain strategic cash reserves';

  @override
  String get guide3 => '✅ Focus on long-term positioning';

  @override
  String get guide4 => '❌ Avoid emotional overbuying';

  @override
  String get minus20Title => '-20% Estratégia';

  @override
  String get minus20Headline =>
      'Iniciar compras fracionadas recorrentes de QLD';

  @override
  String get minus20OverviewTitle => 'Strategy Overview';

  @override
  String get minus20OverviewText =>
      'This zone represents approximately a 10% correction in QQQ.\n\nSince the decline is still relatively moderate, maintaining cash reserves remains important.';

  @override
  String get minus20AllocationTitle => 'Suggested Allocation';

  @override
  String get minus20AllocationText =>
      '• Start accumulating with very small positions or simply hold\n• Proceed with slow and gradual buying\n• Avoid aggressive early entries\n• Preserve cash for larger potential declines';

  @override
  String get minus20HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus20HistoryText =>
      '• Average recovery period: approximately 1–2 months\n• Nasdaq has historically rebounded frequently after -20% corrections\n• Psychological pressure is relatively lower compared to major crashes';

  @override
  String get minus20RiskTitle => 'Risk Warning';

  @override
  String get minus20RiskText =>
      'Further downside is still possible after a -20% decline.\n\nAggressive early entries may create liquidity risk during deeper corrections.';

  @override
  String get minus20GuideTitle => 'Action Guide';

  @override
  String get minus20GuideText =>
      '✅ Start slowly\n✅ Buying is not mandatory at this stage\n✅ Maintain sufficient cash reserves\n❌ Avoid emotional buying';

  @override
  String get minus30Title => '-30% Estratégia';

  @override
  String get minus30Headline => 'Comprar TQQQ com 10% do caixa';

  @override
  String get minus30OverviewTitle => 'Strategy Overview';

  @override
  String get minus30OverviewText =>
      'This zone represents a high-opportunity accumulation phase.\n\nHistorically, Nasdaq corrections around -30% have often provided strong long-term buying opportunities.\n\nAlthough fear and volatility increase significantly at this stage, disciplined dollar-cost averaging can improve long-term returns.';

  @override
  String get minus30AllocationTitle => 'Suggested Allocation';

  @override
  String get minus30AllocationText =>
      '• Deploy approximately 10% of available cash\n• Continue gradual accumulation\n• Avoid deploying all capital too quickly\n• Maintain flexibility for deeper declines';

  @override
  String get minus30HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus30HistoryText =>
      '• Average recovery period ranges from approximately 6 months to over 1 year\n• Historically, strong rebounds often followed -30% corrections\n• Volatility and psychological pressure increase significantly in this zone';

  @override
  String get minus30RiskTitle => 'Risk Warning';

  @override
  String get minus30RiskText =>
      'Markets may remain highly volatile even after a -30% decline.\n\nOvercommitting capital without cash reserves can increase both psychological and financial risks.';

  @override
  String get minus30GuideTitle => 'Action Guide';

  @override
  String get minus30GuideText =>
      '✅ Maintain disciplined accumulation\n✅ Control emotions\n✅ Preserve remaining cash\n❌ Avoid panic buying and excessive leverage';

  @override
  String get minus40Title => '-40% Estratégia';

  @override
  String get minus40Headline => 'Usar 30% caixa - entrada TQQQ';

  @override
  String get minus40OverviewTitle => 'Strategy Overview';

  @override
  String get minus40OverviewText =>
      'The -40% zone is a period of extreme market fear, but it can also become an important long-term buying opportunity. Maintaining a planned strategy is more important than emotional reactions.';

  @override
  String get minus40AllocationTitle => 'Capital Allocation';

  @override
  String get minus40AllocationText =>
      'Avoid deploying all capital at once. Scale in gradually across multiple stages while preserving sufficient cash for potential further downside.';

  @override
  String get minus40HistoryTitle => 'Crash History';

  @override
  String get minus40HistoryText =>
      'Historically, markets have eventually recovered even after major crashes. Extreme fear zones have often created opportunities for long-term investors.';

  @override
  String get minus40RiskTitle => 'Psychological Risk';

  @override
  String get minus40RiskText =>
      'As declines deepen, fear and anxiety intensify. It is important to stay disciplined and avoid reacting emotionally to short-term volatility and news.';

  @override
  String get minus40GuideTitle => 'Survival Guide';

  @override
  String get minus40GuideText =>
      'Focus on long-term survival rather than predicting short-term rebounds. Avoid excessive leverage and emotional all-in positions while maintaining a consistent accumulation strategy.';

  @override
  String get minus50Title => '-50% Estratégia';

  @override
  String get minus50Headline => 'Comprar TQQQ com todo o caixa restante';

  @override
  String get minus50OverviewTitle => 'Deploy Remaining Cash into TQQQ';

  @override
  String get minus50OverviewText =>
      'A -50% decline represents an extreme market fear environment. Most investors experience panic during this phase, and volatility can remain exceptionally high.';

  @override
  String get minus50AllocationTitle => 'Capital Allocation';

  @override
  String get minus50AllocationText =>
      'Deploy remaining cash into TQQQ. Continue lowering the average entry price through systematic recurring purchases afterward.';

  @override
  String get minus50HistoryTitle => 'After Major Crashes';

  @override
  String get minus50HistoryText =>
      'Historically, markets have recovered over time following major crashes. The Nasdaq has structurally maintained long-term growth. Extreme fear should be viewed as opportunity rather than panic.';

  @override
  String get minus50RiskTitle => 'Psychological Pressure';

  @override
  String get minus50RiskText =>
      'Rather than feeling psychological pressure, investors should recognize this phase as a potential deep-value buying opportunity.';

  @override
  String get minus50GuideTitle => 'Survival Strategy';

  @override
  String get minus50GuideText =>
      'Accumulate TQQQ aggressively while continuously lowering the average cost basis through systematic recurring purchases.';

  @override
  String get exchangeUsdKrw => 'Dólar/Won';

  @override
  String get exchangeUsdJpy => 'Dólar/Iene';

  @override
  String get exchangeEurUsd => 'Euro/Dólar';

  @override
  String get exchangeUsdRub => 'Dólar/Rublo';

  @override
  String get exchangeUsdTwd => 'Dólar/Dólar taiwanês';

  @override
  String get exchangeUsdCny => 'Dólar/Yuan';

  @override
  String get fearGreedExtremeFear => 'Medo extremo';

  @override
  String get fearGreedFear => 'Medo';

  @override
  String get fearGreedNeutral => 'Neutro';

  @override
  String get fearGreedGreed => 'Ganância';

  @override
  String get fearGreedExtremeGreed => 'Ganância extrema';

  @override
  String get fearGreedIndicatorsTitle => '7 indicadores de medo e ganância';

  @override
  String get fearGreedFaqTitle => 'Perguntas sobre o índice de medo e ganância';

  @override
  String get fearGreedWhatTitle =>
      'O que é o índice de medo e ganância da CNN?';

  @override
  String get fearGreedWhatBody =>
      'O índice mede o sentimento do mercado acionário e se as ações podem estar justamente precificadas. Medo excessivo tende a pressionar preços para baixo, enquanto ganância excessiva pode elevá-los.';

  @override
  String get fearGreedCalculatedTitle => 'Como ele é calculado?';

  @override
  String get fearGreedCalculatedBody =>
      'Ele combina sete indicadores: momentum do mercado, força dos preços, amplitude, opções put/call, demanda por junk bonds, volatilidade e demanda por ativos de segurança. Todos têm peso igual em uma escala de 0 a 100.';

  @override
  String get fearGreedFrequencyTitle => 'Com que frequência é atualizado?';

  @override
  String get fearGreedFrequencyBody =>
      'Cada componente e o índice geral são atualizados quando novos dados de mercado ficam disponíveis.';

  @override
  String get fearGreedUseTitle => 'Como devo usar?';

  @override
  String get fearGreedUseBody =>
      'Use como uma leitura do humor do mercado. Ele ajuda a perceber extremos emocionais, mas as decisões devem considerar preço, fundamentos, controle de risco e sua própria estratégia.';

  @override
  String get strategyAdLabel => 'Anúncio';

  @override
  String get alertSettingsTitle => 'Configurações de alerta';

  @override
  String get alertHighTitle => 'Alerta de nova máxima';

  @override
  String get alertHighSubtitle =>
      'Avisar quando uma nova máxima for atingida após a instalação';

  @override
  String get alertMarketOpenTitle => 'Alerta de abertura';

  @override
  String get alertMarketOpenSubtitle =>
      'Avisar uma vez ao dia quando o mercado regular dos EUA abrir';

  @override
  String get alertStrategySettingTitle => 'Alerta de estratégia';

  @override
  String get alertStrategySettingSubtitle =>
      'Avisar mudanças nas zonas -20%, -30%, -40% e -50%';

  @override
  String get noBuyHeadline => 'Não comprar mais. Manter 30% em caixa.';

  @override
  String get noBuyActionTitle => 'Ação imediata';

  @override
  String get noBuyActionText =>
      'Não compre novos QLD/TQQQ. Mantenha a posição atual em QLD e proteja 30% em caixa.';

  @override
  String get noBuyCashTitle => 'Regra de caixa';

  @override
  String get noBuyCashText =>
      'O caixa é reserva para a próxima zona de queda. Não reduza mesmo se o mercado subir.';

  @override
  String get noBuyAvoidTitle => 'Evitar';

  @override
  String get noBuyAvoidText =>
      'Não persiga preço só porque está subindo. Espere até a zona de -20%.';

  @override
  String get noBuyNextTitle => 'Próximo passo';

  @override
  String get noBuyNextText =>
      'Ao chegar a -20%, prepare compras fracionadas recorrentes de QLD.';

  @override
  String get minus20ActionTitle => 'Ação imediata';

  @override
  String get minus20ActionText =>
      'Comece compras fracionadas muito pequenas de QLD. Não coloque muito dinheiro de uma vez.';

  @override
  String get minus20BuyRuleTitle => 'Regra de compra';

  @override
  String get minus20BuyRuleText =>
      'Use apenas uma pequena parte do caixa total. O objetivo é iniciar o ritmo, não uma grande entrada.';

  @override
  String get minus20CashTitle => 'Gestão de caixa';

  @override
  String get minus20CashText =>
      'A maior parte do caixa deve ficar disponível para as zonas -30%, -40% e -50%.';

  @override
  String get minus20AvoidTitle => 'Evitar';

  @override
  String get minus20AvoidText =>
      'Não compre TQQQ agressivamente. A zona -20% ainda é apenas o começo.';

  @override
  String get minus30ActionTitle => 'Ação imediata';

  @override
  String get minus30ActionText =>
      'Use apenas 10% do caixa disponível para comprar TQQQ. Verifique o caixa total antes da ordem.';

  @override
  String get minus30BuyRuleTitle => 'Regra de compra';

  @override
  String get minus30BuyRuleText =>
      'Se houver \$10.000 em caixa, use só \$1.000 em TQQQ e preserve os 90% restantes.';

  @override
  String get minus30AdditionalTitle => 'Ação adicional';

  @override
  String get minus30AdditionalText =>
      'A acumulação de QLD pode continuar, mas espere a próxima zona para comprar mais TQQQ.';

  @override
  String get minus30AvoidTitle => 'Evitar';

  @override
  String get minus30AvoidText =>
      'Não gaste muito caixa esperando recuperação. Aja como se a zona -40% ainda pudesse chegar.';

  @override
  String get minus40ActionTitle => 'Ação imediata';

  @override
  String get minus40ActionText =>
      'Use 30% do caixa restante para comprar TQQQ. Exclua o valor já usado em -30%.';

  @override
  String get minus40BuyRuleTitle => 'Regra de compra';

  @override
  String get minus40BuyRuleText =>
      'Se restarem \$9.000, use só \$2.700. O ponto central é não usar tudo de uma vez.';

  @override
  String get minus40HoldTitle => 'Regra de manutenção';

  @override
  String get minus40HoldText =>
      'Mantenha QLD e aumente TQQQ apenas até o valor planejado. Deixe caixa para nova queda.';

  @override
  String get minus40AvoidTitle => 'Evitar';

  @override
  String get minus40AvoidText =>
      'Não venda posições por medo. Também não compre com todo o caixa por ganância.';

  @override
  String get minus50ActionTitle => 'Ação imediata';

  @override
  String get minus50ActionText =>
      'Use todo o caixa restante para comprar TQQQ. Esta é a etapa final planejada de uso de caixa.';

  @override
  String get minus50BuyRuleTitle => 'Regra de compra';

  @override
  String get minus50BuyRuleText =>
      'Use como base apenas o caixa real restante, excluindo o que já foi usado em -30% e -40%.';

  @override
  String get minus50AfterTitle => 'Depois';

  @override
  String get minus50AfterText =>
      'Quando entrar novo caixa, acumule TQQQ ou QLD regularmente e foque em reduzir o preço médio.';

  @override
  String get minus50AvoidTitle => 'Evitar';

  @override
  String get minus50AvoidText =>
      'Não desista apenas por causa da perda. Não use dívida nem dinheiro de curto prazo para comprar mais.';

  @override
  String get alertNasdaq200Title => 'Alerta média 200 dias Nasdaq 100';

  @override
  String get alertNasdaq200Subtitle =>
      'Avisar quando o Nasdaq 100 romper abaixo ou acima da média de 200 dias';

  @override
  String get alertNasdaq200Breakdown =>
      'O Nasdaq 100 rompeu abaixo da média móvel de 200 dias';

  @override
  String get alertNasdaq200Breakout =>
      'O Nasdaq 100 voltou a romper acima da média móvel de 200 dias';

  @override
  String get alertPortfolioCashTitle => 'Alerta de rebalanceamento de caixa';

  @override
  String get alertPortfolioCashSubtitle =>
      'Avisar quando o caixa cair abaixo de 20% após altas';

  @override
  String get alertPortfolioCashHigh =>
      'O caixa está abaixo de 20%. Considere rebalancear para recompor caixa.';

  @override
  String get alertPortfolioCashLow =>
      'O caixa está abaixo de 20%. Considere rebalancear para recompor caixa.';

  @override
  String get alertAnnouncementTitle => 'Notificações de avisos';

  @override
  String get alertAnnouncementSubtitle =>
      'Receber avisos enviados pelo QLD DIP ALERT como notificações push';

  @override
  String get alertDetailTitle => 'Detalhes do alerta';

  @override
  String get alertDetailOpenStrategy => 'Ver estratégia';

  @override
  String get alertDetailRecovery =>
      'A zona de queda melhorou. Revise a carteira com calma e evite vender ou comprar por impulso.';

  @override
  String get alertDetailNewHigh =>
      'Uma nova máxima foi registrada após a instalação. Ela será a nova referência para calcular quedas futuras.';

  @override
  String get alertDetailMarketOpen =>
      'O mercado regular dos EUA abriu. Verifique preços e alertas apenas se planejava agir hoje.';

  @override
  String get alertDetailNasdaq200Breakdown =>
      'O Nasdaq 100 caiu abaixo da média móvel de 200 dias. Isso pode indicar tendência mais fraca; revise risco e caixa.';

  @override
  String get alertDetailNasdaq200Breakout =>
      'O Nasdaq 100 voltou acima da média móvel de 200 dias. Pode indicar melhora, mas siga sua estratégia.';

  @override
  String get alertDetailPortfolioCashHigh =>
      'O caixa está abaixo da referência de 20%. Isso geralmente significa que as ações subiram e a reserva de caixa ficou pequena. Considere vender parte da posição e rebalancear para o nível planejado de caixa.';

  @override
  String get alertDetailPortfolioCashLow =>
      'O caixa está abaixo da referência de 20%. Isso geralmente significa que as ações subiram e a reserva de caixa ficou pequena. Considere vender parte da posição e rebalancear para o nível planejado de caixa.';

  @override
  String get alertDetailOpenLink => 'Abrir link';

  @override
  String get appUpdateTitle => 'Atualização disponível';

  @override
  String get appUpdateMessage =>
      'Há uma nova versão disponível. Atualize para usar os recursos e correções mais recentes.';

  @override
  String get appUpdateLater => 'Depois';

  @override
  String get appUpdateNow => 'Atualizar';
}
