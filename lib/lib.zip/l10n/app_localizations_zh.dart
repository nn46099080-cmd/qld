// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get appTitle => 'QLD 提醒';

  @override
  String get noBuyZone => '禁止买入区间';

  @override
  String get tapToViewStrategy => '点击查看策略';

  @override
  String get buyNow => '立即买入';

  @override
  String get buyingInProgress => '买入进行中';

  @override
  String get hold => '持有';

  @override
  String get navHome => '首页';

  @override
  String get navChart => '图表';

  @override
  String get navExchange => '汇率';

  @override
  String get navFearGreed => '恐惧';

  @override
  String get fearGreedTitle => '恐惧与贪婪指数';

  @override
  String get fearGreedSubtitle => 'CNN 美国市场情绪';

  @override
  String get fearGreedUnavailable => '无法加载恐惧与贪婪数据。';

  @override
  String get navAlert => '提醒';

  @override
  String get navStrategy => '策略';

  @override
  String get alertRecovery10 => 'QLD 回升10%';

  @override
  String get alertMarketOpen => '美国股市已开盘';

  @override
  String get alertNewHigh => '创出新高';

  @override
  String get portfolio => '投资组合';

  @override
  String get portfolioAssetInput => '资产输入';

  @override
  String get portfolioClose => '关闭';

  @override
  String get portfolioQldShares => 'QLD 数量';

  @override
  String get portfolioTqqqShares => 'TQQQ 数量';

  @override
  String get portfolioQldAveragePrice => 'QLD 平均成本';

  @override
  String get portfolioTqqqAveragePrice => 'TQQQ 平均成本';

  @override
  String get portfolioCashUsd => '现金 USD';

  @override
  String get portfolioTotal => '总资产';

  @override
  String get portfolioProfitLoss => '浮动盈亏';

  @override
  String get portfolioSharesUnit => '股';

  @override
  String get portfolioReturnRate => '收益率';

  @override
  String get portfolioAveragePriceShort => '平均成本';

  @override
  String get portfolioPriceLoading => '价格加载中';

  @override
  String get portfolioToBreakeven => '回本还需';

  @override
  String get portfolioBreakevenCleared => '已高于成本';

  @override
  String get basePosition => '基础仓位';

  @override
  String get from10yHigh => '相对10年最高价';

  @override
  String get holdQLDPlusCash => '持有 QLD + 30% 现金';

  @override
  String get basePositionDescription =>
      '[ Strategy Guide ]\n\nThis strategy does not invest all assets into QLD at once.\n\nAt the beginning, only part of the assets is invested, while the rest is held in cash to prepare for major market declines.\n\nExample:\n- Invest only 70% of initial assets into QLD\n- Hold the remaining 30% in cash\n\nQLD is an ETF that tracks approximately 2x the daily movement of the Nasdaq-100 Index.\n\nTherefore, in the initial state:\n2x leverage × 70% investment = approximately 1.4x overall exposure.\n\nFor example:\n- Nasdaq +1%\n→ Total assets about +1.4%\n\nWhen a major decline occurs, the cash held is used step by step for additional buying.\n\nExample:\n- Additional buying around the QLD -40% zone\n\nThis allows more shares to be accumulated at lower prices, and when the market recovers, the average entry price can be significantly reduced.\n\nAs a result, this strategy may produce higher returns during recovery phases than a simple buy-and-hold strategy.\n\nThe core of this strategy is:\n- Reduce volatility with cash during rising markets\n- Use cash to buy more during major declines and lower the average cost.';

  @override
  String get buySignalMessage => '买入信号会自动显示在这里。';

  @override
  String get currentPrice => '当前价格';

  @override
  String get tenYearHigh => '10年最高价';

  @override
  String get buyStrategy => '买入策略';

  @override
  String get noBuyZoneTitle => '禁止买入区间';

  @override
  String get strategyOverview => '策略概览';

  @override
  String get corePrinciple => '核心原则';

  @override
  String get suggestedAllocation => '建议配置';

  @override
  String get riskManagement => '风险管理';

  @override
  String get actionGuide => '行动指南';

  @override
  String get marketStable =>
      'The Nasdaq market has historically maintained a long-term upward trend driven by technological innovation and global growth companies in the United States. Based on this growth potential, ProShares Ultra QQQ (QLD) is a leveraged ETF designed to track 2x the daily performance of the Nasdaq-100 Index, making it an efficient investment vehicle during long-term bullish market conditions.\n\nHowever, due to the nature of leveraged ETFs, volatility and downside risk can increase significantly during market downturns. Therefore, disciplined risk management is more important than simple buy-and-hold strategies. Maintaining approximately 30% of total assets in cash while gradually buying during sharp declines can help lower the average entry price and maximize long-term compounded returns.\n\nIn other words, the core of the QLD strategy is to utilize leverage efficiency during bull markets while maintaining sufficient cash reserves to respond flexibly during market corrections.';

  @override
  String get noPanicSignals =>
      'The Nasdaq market is not simply a collection of companies. It operates through a continuous rebalancing and replacement mechanism that maintains competitiveness over time. Innovative companies with strong growth and profitability are added to the index, while weaker companies gradually lose weight or are removed.\n\nThis structure continuously reallocates capital toward productive and high-growth businesses, strengthening the market’s long-term growth potential. Supported by technological innovation in the United States, the expansion of global platform companies, and ongoing monetary liquidity growth, the Nasdaq has become one of the primary markets absorbing global capital flows.\n\nIn other words, the Nasdaq is not just a market that rises over time, but a structural growth system driven by constant innovation and corporate evolution. Because of these characteristics, it is widely viewed as a market with strong long-term upside potential that benefits from both technological advancement and monetary expansion.';

  @override
  String get maintainBalanced =>
      'Maintaining balanced positions and sufficient cash reserves allows for flexible responses during future market corrections.';

  @override
  String get cashReserveRule => 'Always maintain at least 30% cash reserves.';

  @override
  String get cashPsychology =>
      'Holding cash provides psychological stability and enables consistent buying opportunities during future market downturns.';

  @override
  String get allocation1 => '• Maintain core QLD positions';

  @override
  String get allocation2 =>
      '• Secure at least 30% cash by taking profits when possible';

  @override
  String get allocation3 => '• Never chase short-term price surges';

  @override
  String get allocation4 => '• Prepare for future buying opportunities';

  @override
  String get risk1 =>
      'Even strong bull markets can reverse sharply at any time.';

  @override
  String get risk2 =>
      'Lack of cash reserves can reduce flexibility during market corrections.';

  @override
  String get guide1 => '✅ Stay disciplined';

  @override
  String get guide2 => '✅ Maintain strategic cash reserves';

  @override
  String get guide3 => '✅ Focus on long-term positioning';

  @override
  String get guide4 => '❌ Avoid emotional overbuying';

  @override
  String get minus20Title => '-20% 策略';

  @override
  String get minus20Headline => '开始少量定投 QLD';

  @override
  String get minus20OverviewTitle => 'Strategy Overview';

  @override
  String get minus20OverviewText =>
      'This zone represents approximately a 10% correction in QQQ.\n\nSince the decline is still relatively moderate, maintaining cash reserves remains important.';

  @override
  String get minus20AllocationTitle => 'Suggested Allocation';

  @override
  String get minus20AllocationText =>
      '• Start accumulating with very small positions or simply hold\n• Proceed with slow and gradual buying\n• Avoid aggressive early entries\n• Preserve cash for larger potential declines';

  @override
  String get minus20HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus20HistoryText =>
      '• Average recovery period: approximately 1–2 months\n• Nasdaq has historically rebounded frequently after -20% corrections\n• Psychological pressure is relatively lower compared to major crashes';

  @override
  String get minus20RiskTitle => 'Risk Warning';

  @override
  String get minus20RiskText =>
      'Further downside is still possible after a -20% decline.\n\nAggressive early entries may create liquidity risk during deeper corrections.';

  @override
  String get minus20GuideTitle => 'Action Guide';

  @override
  String get minus20GuideText =>
      '✅ Start slowly\n✅ Buying is not mandatory at this stage\n✅ Maintain sufficient cash reserves\n❌ Avoid emotional buying';

  @override
  String get minus30Title => '-30% 策略';

  @override
  String get minus30Headline => '用现金的10%买入 TQQQ';

  @override
  String get minus30OverviewTitle => 'Strategy Overview';

  @override
  String get minus30OverviewText =>
      'This zone represents a high-opportunity accumulation phase.\n\nHistorically, Nasdaq corrections around -30% have often provided strong long-term buying opportunities.\n\nAlthough fear and volatility increase significantly at this stage, disciplined dollar-cost averaging can improve long-term returns.';

  @override
  String get minus30AllocationTitle => 'Suggested Allocation';

  @override
  String get minus30AllocationText =>
      '• Deploy approximately 10% of available cash\n• Continue gradual accumulation\n• Avoid deploying all capital too quickly\n• Maintain flexibility for deeper declines';

  @override
  String get minus30HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus30HistoryText =>
      '• Average recovery period ranges from approximately 6 months to over 1 year\n• Historically, strong rebounds often followed -30% corrections\n• Volatility and psychological pressure increase significantly in this zone';

  @override
  String get minus30RiskTitle => 'Risk Warning';

  @override
  String get minus30RiskText =>
      'Markets may remain highly volatile even after a -30% decline.\n\nOvercommitting capital without cash reserves can increase both psychological and financial risks.';

  @override
  String get minus30GuideTitle => 'Action Guide';

  @override
  String get minus30GuideText =>
      '✅ Maintain disciplined accumulation\n✅ Control emotions\n✅ Preserve remaining cash\n❌ Avoid panic buying and excessive leverage';

  @override
  String get minus40Title => '-40% 策略';

  @override
  String get minus40Headline => 'Deploy 30% Cash – TQQQ Entry Zone';

  @override
  String get minus40OverviewTitle => 'Strategy Overview';

  @override
  String get minus40OverviewText =>
      'The -40% zone is a period of extreme market fear, but it can also become an important long-term buying opportunity. Maintaining a planned strategy is more important than emotional reactions.';

  @override
  String get minus40AllocationTitle => 'Capital Allocation';

  @override
  String get minus40AllocationText =>
      'Avoid deploying all capital at once. Scale in gradually across multiple stages while preserving sufficient cash for potential further downside.';

  @override
  String get minus40HistoryTitle => 'Crash History';

  @override
  String get minus40HistoryText =>
      'Historically, markets have eventually recovered even after major crashes. Extreme fear zones have often created opportunities for long-term investors.';

  @override
  String get minus40RiskTitle => 'Psychological Risk';

  @override
  String get minus40RiskText =>
      'As declines deepen, fear and anxiety intensify. It is important to stay disciplined and avoid reacting emotionally to short-term volatility and news.';

  @override
  String get minus40GuideTitle => 'Survival Guide';

  @override
  String get minus40GuideText =>
      'Focus on long-term survival rather than predicting short-term rebounds. Avoid excessive leverage and emotional all-in positions while maintaining a consistent accumulation strategy.';

  @override
  String get minus50Title => '-50% 策略';

  @override
  String get minus50Headline => '用全部剩余现金买入 TQQQ';

  @override
  String get minus50OverviewTitle => 'Deploy Remaining Cash into TQQQ';

  @override
  String get minus50OverviewText =>
      'A -50% decline represents an extreme market fear environment. Most investors experience panic during this phase, and volatility can remain exceptionally high.';

  @override
  String get minus50AllocationTitle => 'Capital Allocation';

  @override
  String get minus50AllocationText =>
      'Deploy remaining cash into TQQQ. Continue lowering the average entry price through systematic recurring purchases afterward.';

  @override
  String get minus50HistoryTitle => 'After Major Crashes';

  @override
  String get minus50HistoryText =>
      'Historically, markets have recovered over time following major crashes. The Nasdaq has structurally maintained long-term growth. Extreme fear should be viewed as opportunity rather than panic.';

  @override
  String get minus50RiskTitle => 'Psychological Pressure';

  @override
  String get minus50RiskText =>
      'Rather than feeling psychological pressure, investors should recognize this phase as a potential deep-value buying opportunity.';

  @override
  String get minus50GuideTitle => 'Survival Strategy';

  @override
  String get minus50GuideText =>
      'Accumulate TQQQ aggressively while continuously lowering the average cost basis through systematic recurring purchases.';

  @override
  String get exchangeUsdKrw => '美元/韩元';

  @override
  String get exchangeUsdJpy => '美元/日元';

  @override
  String get exchangeEurUsd => '欧元/美元';

  @override
  String get exchangeUsdRub => '美元/卢布';

  @override
  String get exchangeUsdTwd => '美元/新台币';

  @override
  String get exchangeUsdCny => '美元/人民币';

  @override
  String get fearGreedExtremeFear => '极度恐惧';

  @override
  String get fearGreedFear => '恐惧';

  @override
  String get fearGreedNeutral => '中性';

  @override
  String get fearGreedGreed => '贪婪';

  @override
  String get fearGreedExtremeGreed => '极度贪婪';

  @override
  String get fearGreedIndicatorsTitle => '7项恐惧与贪婪指标';

  @override
  String get fearGreedFaqTitle => '恐惧与贪婪指数说明';

  @override
  String get fearGreedWhatTitle => 'CNN恐惧与贪婪指数是什么？';

  @override
  String get fearGreedWhatBody =>
      '恐惧与贪婪指数用于衡量股票市场情绪，以及股票价格是否可能处于合理水平。过度恐惧往往压低股价，过度贪婪则可能推高股价。';

  @override
  String get fearGreedCalculatedTitle => '它是如何计算的？';

  @override
  String get fearGreedCalculatedBody =>
      '该指数结合七项市场指标：市场动能、股价强度、市场广度、看跌/看涨期权、垃圾债需求、市场波动率以及避险资产需求。每项指标权重相同，最终形成0到100分。';

  @override
  String get fearGreedFrequencyTitle => '多久更新一次？';

  @override
  String get fearGreedFrequencyBody => '每个组成指标和整体指数都会在新的市场数据可用时更新。';

  @override
  String get fearGreedUseTitle => '应该如何使用？';

  @override
  String get fearGreedUseBody =>
      '可将它作为观察市场情绪的辅助指标。它能帮助发现情绪极端，但实际决策仍应结合价格、基本面、风险管理和自己的策略。';

  @override
  String get strategyAdLabel => '广告';

  @override
  String get alertSettingsTitle => '通知设置';

  @override
  String get alertHighTitle => '新高提醒';

  @override
  String get alertHighSubtitle => '安装后创下新高时提醒';

  @override
  String get alertMarketOpenTitle => '开盘提醒';

  @override
  String get alertMarketOpenSubtitle => '美股常规交易开始时每天提醒一次';

  @override
  String get alertStrategySettingTitle => '策略提醒';

  @override
  String get alertStrategySettingSubtitle => '提醒 -20%、-30%、-40%、-50% 区间变化';

  @override
  String get noBuyHeadline => '禁止追加买入，保持30%现金';

  @override
  String get noBuyActionTitle => '立即行动';

  @override
  String get noBuyActionText => '不要新买QLD/TQQQ。维持现有QLD仓位，并保留30%现金。';

  @override
  String get noBuyCashTitle => '现金规则';

  @override
  String get noBuyCashText => '现金是为下一轮下跌区间准备的储备资金。即使市场上涨也不要减少。';

  @override
  String get noBuyAvoidTitle => '避免';

  @override
  String get noBuyAvoidText => '不要因为价格上涨就追买。等待-20%区间出现。';

  @override
  String get noBuyNextTitle => '下一步';

  @override
  String get noBuyNextText => '到达-20%后，准备开始小额分批定投QLD。';

  @override
  String get minus20ActionTitle => '立即行动';

  @override
  String get minus20ActionText => '以很小金额开始分批定投QLD。不要一次投入大额资金。';

  @override
  String get minus20BuyRuleTitle => '买入规则';

  @override
  String get minus20BuyRuleText => '只使用总现金中很小的一部分。重点不是大举进场，而是开始节奏。';

  @override
  String get minus20CashTitle => '现金管理';

  @override
  String get minus20CashText => '大部分现金必须保留，用于应对-30%、-40%、-50%区间。';

  @override
  String get minus20AvoidTitle => '避免';

  @override
  String get minus20AvoidText => '不要激进买入TQQQ。-20%仍只是初期区间。';

  @override
  String get minus30ActionTitle => '立即行动';

  @override
  String get minus30ActionText => '只使用可用现金的10%买入TQQQ。下单前先确认现金总额。';

  @override
  String get minus30BuyRuleTitle => '买入规则';

  @override
  String get minus30BuyRuleText =>
      '如果现金为\$10,000，只使用\$1,000买入TQQQ，并保留剩余90%的现金。';

  @override
  String get minus30AdditionalTitle => '追加行动';

  @override
  String get minus30AdditionalText => 'QLD定投可以继续，但TQQQ追加买入要等到下一个区间。';

  @override
  String get minus30AvoidTitle => '避免';

  @override
  String get minus30AvoidText => '不要因为确信反弹就大量使用现金。要按-40%区间仍可能到来的前提行动。';

  @override
  String get minus40ActionTitle => '立即行动';

  @override
  String get minus40ActionText => '使用剩余现金的30%买入TQQQ。计算时排除-30%已经使用的金额。';

  @override
  String get minus40BuyRuleTitle => '买入规则';

  @override
  String get minus40BuyRuleText => '如果剩余现金为\$9,000，只使用\$2,700。关键是不要一次用完。';

  @override
  String get minus40HoldTitle => '持有规则';

  @override
  String get minus40HoldText => '继续持有QLD，TQQQ只增加到计划比例。为进一步下跌保留现金。';

  @override
  String get minus40AvoidTitle => '避免';

  @override
  String get minus40AvoidText => '不要因恐惧卖出现有仓位，也不要因贪婪全额买入。';

  @override
  String get minus50ActionTitle => '立即行动';

  @override
  String get minus50ActionText => '使用所有剩余现金买入TQQQ。这是计划中的最后现金投入阶段。';

  @override
  String get minus50BuyRuleTitle => '买入规则';

  @override
  String get minus50BuyRuleText => '以排除-30%、-40%已使用金额后的实际剩余现金为基准。';

  @override
  String get minus50AfterTitle => '之后行动';

  @override
  String get minus50AfterText => '之后有新增现金时，定期累积TQQQ或QLD，专注降低平均成本。';

  @override
  String get minus50AvoidTitle => '避免';

  @override
  String get minus50AvoidText => '不要只因亏损较大就放弃。不要用债务或短期生活资金追加买入。';

  @override
  String get alertNasdaq200Title => '纳斯达克100 200日线提醒';

  @override
  String get alertNasdaq200Subtitle => '纳斯达克100跌破或突破200日线时提醒';

  @override
  String get alertNasdaq200Breakdown => '纳斯达克100跌破200日均线';

  @override
  String get alertNasdaq200Breakout => '纳斯达克100重新突破200日均线';

  @override
  String get alertPortfolioCashTitle => '现金再平衡提醒';

  @override
  String get alertPortfolioCashSubtitle => '当股价上涨等导致现金比例低于20%时提醒';

  @override
  String get alertPortfolioCashHigh => '现金比例低于20%。请考虑再平衡以补充现金。';

  @override
  String get alertPortfolioCashLow => '现金比例低于20%。请考虑再平衡以补充现金。';

  @override
  String get alertAnnouncementTitle => '公告通知';

  @override
  String get alertAnnouncementSubtitle => '接收 QLD DIP ALERT 发送的公告推送';

  @override
  String get alertDetailTitle => '提醒详情';

  @override
  String get alertDetailOpenStrategy => '查看策略';

  @override
  String get alertDetailRecovery => '下跌区间已改善。请冷静检查投资组合，避免匆忙卖出或冲动买入。';

  @override
  String get alertDetailNewHigh => '安装后记录了新的最高价。它将作为未来下跌率计算的新基准。';

  @override
  String get alertDetailMarketOpen => '美股常规交易已开始。只有今天计划行动时再检查价格和策略提醒。';

  @override
  String get alertDetailNasdaq200Breakdown =>
      '纳斯达克100跌破200日均线。长期趋势可能转弱，请检查风险和现金比例。';

  @override
  String get alertDetailNasdaq200Breakout =>
      '纳斯达克100重新站上200日均线。趋势可能改善，但仍应遵循计划策略。';

  @override
  String get alertDetailPortfolioCashHigh =>
      '现金比例低于20%参考线。这通常意味着股价上涨后持仓比例变大、现金缓冲变小。请考虑减持部分仓位，并再平衡到计划的现金比例。';

  @override
  String get alertDetailPortfolioCashLow =>
      '现金比例低于20%参考线。这通常意味着股价上涨后持仓比例变大、现金缓冲变小。请考虑减持部分仓位，并再平衡到计划的现金比例。';

  @override
  String get alertDetailOpenLink => '打开链接';

  @override
  String get appUpdateTitle => '有可用更新';

  @override
  String get appUpdateMessage => '有新版本可用。请更新以使用最新功能和修复。';

  @override
  String get appUpdateLater => '稍后';

  @override
  String get appUpdateNow => '更新';
}

/// The translations for Chinese, as used in Taiwan (`zh_TW`).
class AppLocalizationsZhTw extends AppLocalizationsZh {
  AppLocalizationsZhTw() : super('zh_TW');

  @override
  String get appTitle => 'QLD 提醒';

  @override
  String get noBuyZone => '禁止買入區間';

  @override
  String get tapToViewStrategy => '點擊查看策略';

  @override
  String get buyNow => '立即買入';

  @override
  String get buyingInProgress => '買入進行中';

  @override
  String get hold => '持有';

  @override
  String get navHome => '首頁';

  @override
  String get navChart => '圖表';

  @override
  String get navExchange => '匯率';

  @override
  String get navFearGreed => '恐懼';

  @override
  String get fearGreedTitle => '恐懼與貪婪指數';

  @override
  String get fearGreedSubtitle => 'CNN 美國市場情緒';

  @override
  String get fearGreedUnavailable => '無法載入恐懼與貪婪資料。';

  @override
  String get navAlert => '提醒';

  @override
  String get navStrategy => '策略';

  @override
  String get alertRecovery10 => 'QLD 回升10%';

  @override
  String get alertMarketOpen => '美國股市已開盤';

  @override
  String get alertNewHigh => '創下新高';

  @override
  String get portfolio => '投資組合';

  @override
  String get portfolioAssetInput => '資產輸入';

  @override
  String get portfolioClose => '關閉';

  @override
  String get portfolioQldShares => 'QLD 數量';

  @override
  String get portfolioTqqqShares => 'TQQQ 數量';

  @override
  String get portfolioQldAveragePrice => 'QLD 平均成本';

  @override
  String get portfolioTqqqAveragePrice => 'TQQQ 平均成本';

  @override
  String get portfolioCashUsd => '現金 USD';

  @override
  String get portfolioTotal => '總資產';

  @override
  String get portfolioProfitLoss => '浮動盈虧';

  @override
  String get portfolioSharesUnit => '股';

  @override
  String get portfolioReturnRate => '收益率';

  @override
  String get portfolioAveragePriceShort => '平均成本';

  @override
  String get portfolioPriceLoading => '價格載入中';

  @override
  String get portfolioToBreakeven => '回本還需';

  @override
  String get portfolioBreakevenCleared => '已高於成本';

  @override
  String get basePosition => '基礎倉位';

  @override
  String get from10yHigh => '相對10年最高價';

  @override
  String get holdQLDPlusCash => '持有 QLD + 30% 現金';

  @override
  String get basePositionDescription =>
      '[ Strategy Guide ]\n\nThis strategy does not invest all assets into QLD at once.\n\nAt the beginning, only part of the assets is invested, while the rest is held in cash to prepare for major market declines.\n\nExample:\n- Invest only 70% of initial assets into QLD\n- Hold the remaining 30% in cash\n\nQLD is an ETF that tracks approximately 2x the daily movement of the Nasdaq-100 Index.\n\nTherefore, in the initial state:\n2x leverage × 70% investment = approximately 1.4x overall exposure.\n\nFor example:\n- Nasdaq +1%\n→ Total assets about +1.4%\n\nWhen a major decline occurs, the cash held is used step by step for additional buying.\n\nExample:\n- Additional buying around the QLD -40% zone\n\nThis allows more shares to be accumulated at lower prices, and when the market recovers, the average entry price can be significantly reduced.\n\nAs a result, this strategy may produce higher returns during recovery phases than a simple buy-and-hold strategy.\n\nThe core of this strategy is:\n- Reduce volatility with cash during rising markets\n- Use cash to buy more during major declines and lower the average cost.';

  @override
  String get buySignalMessage => '買入信號會自動顯示在這裡。';

  @override
  String get currentPrice => '目前價格';

  @override
  String get tenYearHigh => '10年最高價';

  @override
  String get buyStrategy => '買入策略';

  @override
  String get noBuyZoneTitle => '禁止買入區間';

  @override
  String get strategyOverview => '策略概覽';

  @override
  String get corePrinciple => '核心原則';

  @override
  String get suggestedAllocation => '建議配置';

  @override
  String get riskManagement => '風險管理';

  @override
  String get actionGuide => '行動指南';

  @override
  String get marketStable =>
      'The Nasdaq market has historically maintained a long-term upward trend driven by technological innovation and global growth companies in the United States. Based on this growth potential, ProShares Ultra QQQ (QLD) is a leveraged ETF designed to track 2x the daily performance of the Nasdaq-100 Index, making it an efficient investment vehicle during long-term bullish market conditions.\n\nHowever, due to the nature of leveraged ETFs, volatility and downside risk can increase significantly during market downturns. Therefore, disciplined risk management is more important than simple buy-and-hold strategies. Maintaining approximately 30% of total assets in cash while gradually buying during sharp declines can help lower the average entry price and maximize long-term compounded returns.\n\nIn other words, the core of the QLD strategy is to utilize leverage efficiency during bull markets while maintaining sufficient cash reserves to respond flexibly during market corrections.';

  @override
  String get noPanicSignals =>
      'The Nasdaq market is not simply a collection of companies. It operates through a continuous rebalancing and replacement mechanism that maintains competitiveness over time. Innovative companies with strong growth and profitability are added to the index, while weaker companies gradually lose weight or are removed.\n\nThis structure continuously reallocates capital toward productive and high-growth businesses, strengthening the market’s long-term growth potential. Supported by technological innovation in the United States, the expansion of global platform companies, and ongoing monetary liquidity growth, the Nasdaq has become one of the primary markets absorbing global capital flows.\n\nIn other words, the Nasdaq is not just a market that rises over time, but a structural growth system driven by constant innovation and corporate evolution. Because of these characteristics, it is widely viewed as a market with strong long-term upside potential that benefits from both technological advancement and monetary expansion.';

  @override
  String get maintainBalanced =>
      'Maintaining balanced positions and sufficient cash reserves allows for flexible responses during future market corrections.';

  @override
  String get cashReserveRule => 'Always maintain at least 30% cash reserves.';

  @override
  String get cashPsychology =>
      'Holding cash provides psychological stability and enables consistent buying opportunities during future market downturns.';

  @override
  String get allocation1 => '• Maintain core QLD positions';

  @override
  String get allocation2 =>
      '• Secure at least 30% cash by taking profits when possible';

  @override
  String get allocation3 => '• Never chase short-term price surges';

  @override
  String get allocation4 => '• Prepare for future buying opportunities';

  @override
  String get risk1 =>
      'Even strong bull markets can reverse sharply at any time.';

  @override
  String get risk2 =>
      'Lack of cash reserves can reduce flexibility during market corrections.';

  @override
  String get guide1 => '✅ Stay disciplined';

  @override
  String get guide2 => '✅ Maintain strategic cash reserves';

  @override
  String get guide3 => '✅ Focus on long-term positioning';

  @override
  String get guide4 => '❌ Avoid emotional overbuying';

  @override
  String get minus20Title => '-20% 策略';

  @override
  String get minus20Headline => '開始少量定投 QLD';

  @override
  String get minus20OverviewTitle => 'Strategy Overview';

  @override
  String get minus20OverviewText =>
      'This zone represents approximately a 10% correction in QQQ.\n\nSince the decline is still relatively moderate, maintaining cash reserves remains important.';

  @override
  String get minus20AllocationTitle => 'Suggested Allocation';

  @override
  String get minus20AllocationText =>
      '• Start accumulating with very small positions or simply hold\n• Proceed with slow and gradual buying\n• Avoid aggressive early entries\n• Preserve cash for larger potential declines';

  @override
  String get minus20HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus20HistoryText =>
      '• Average recovery period: approximately 1–2 months\n• Nasdaq has historically rebounded frequently after -20% corrections\n• Psychological pressure is relatively lower compared to major crashes';

  @override
  String get minus20RiskTitle => 'Risk Warning';

  @override
  String get minus20RiskText =>
      'Further downside is still possible after a -20% decline.\n\nAggressive early entries may create liquidity risk during deeper corrections.';

  @override
  String get minus20GuideTitle => 'Action Guide';

  @override
  String get minus20GuideText =>
      '✅ Start slowly\n✅ Buying is not mandatory at this stage\n✅ Maintain sufficient cash reserves\n❌ Avoid emotional buying';

  @override
  String get minus30Title => '-30% 策略';

  @override
  String get minus30Headline => '用現金的10%買入 TQQQ';

  @override
  String get minus30OverviewTitle => 'Strategy Overview';

  @override
  String get minus30OverviewText =>
      'This zone represents a high-opportunity accumulation phase.\n\nHistorically, Nasdaq corrections around -30% have often provided strong long-term buying opportunities.\n\nAlthough fear and volatility increase significantly at this stage, disciplined dollar-cost averaging can improve long-term returns.';

  @override
  String get minus30AllocationTitle => 'Suggested Allocation';

  @override
  String get minus30AllocationText =>
      '• Deploy approximately 10% of available cash\n• Continue gradual accumulation\n• Avoid deploying all capital too quickly\n• Maintain flexibility for deeper declines';

  @override
  String get minus30HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus30HistoryText =>
      '• Average recovery period ranges from approximately 6 months to over 1 year\n• Historically, strong rebounds often followed -30% corrections\n• Volatility and psychological pressure increase significantly in this zone';

  @override
  String get minus30RiskTitle => 'Risk Warning';

  @override
  String get minus30RiskText =>
      'Markets may remain highly volatile even after a -30% decline.\n\nOvercommitting capital without cash reserves can increase both psychological and financial risks.';

  @override
  String get minus30GuideTitle => 'Action Guide';

  @override
  String get minus30GuideText =>
      '✅ Maintain disciplined accumulation\n✅ Control emotions\n✅ Preserve remaining cash\n❌ Avoid panic buying and excessive leverage';

  @override
  String get minus40Title => '-40% 策略';

  @override
  String get minus40Headline => 'Deploy 30% Cash – TQQQ Entry Zone';

  @override
  String get minus40OverviewTitle => 'Strategy Overview';

  @override
  String get minus40OverviewText =>
      'The -40% zone is a period of extreme market fear, but it can also become an important long-term buying opportunity. Maintaining a planned strategy is more important than emotional reactions.';

  @override
  String get minus40AllocationTitle => 'Capital Allocation';

  @override
  String get minus40AllocationText =>
      'Avoid deploying all capital at once. Scale in gradually across multiple stages while preserving sufficient cash for potential further downside.';

  @override
  String get minus40HistoryTitle => 'Crash History';

  @override
  String get minus40HistoryText =>
      'Historically, markets have eventually recovered even after major crashes. Extreme fear zones have often created opportunities for long-term investors.';

  @override
  String get minus40RiskTitle => 'Psychological Risk';

  @override
  String get minus40RiskText =>
      'As declines deepen, fear and anxiety intensify. It is important to stay disciplined and avoid reacting emotionally to short-term volatility and news.';

  @override
  String get minus40GuideTitle => 'Survival Guide';

  @override
  String get minus40GuideText =>
      'Focus on long-term survival rather than predicting short-term rebounds. Avoid excessive leverage and emotional all-in positions while maintaining a consistent accumulation strategy.';

  @override
  String get minus50Title => '-50% 策略';

  @override
  String get minus50Headline => '用全部剩餘現金買入 TQQQ';

  @override
  String get minus50OverviewTitle => 'Deploy Remaining Cash into TQQQ';

  @override
  String get minus50OverviewText =>
      'A -50% decline represents an extreme market fear environment. Most investors experience panic during this phase, and volatility can remain exceptionally high.';

  @override
  String get minus50AllocationTitle => 'Capital Allocation';

  @override
  String get minus50AllocationText =>
      'Deploy remaining cash into TQQQ. Continue lowering the average entry price through systematic recurring purchases afterward.';

  @override
  String get minus50HistoryTitle => 'After Major Crashes';

  @override
  String get minus50HistoryText =>
      'Historically, markets have recovered over time following major crashes. The Nasdaq has structurally maintained long-term growth. Extreme fear should be viewed as opportunity rather than panic.';

  @override
  String get minus50RiskTitle => 'Psychological Pressure';

  @override
  String get minus50RiskText =>
      'Rather than feeling psychological pressure, investors should recognize this phase as a potential deep-value buying opportunity.';

  @override
  String get minus50GuideTitle => 'Survival Strategy';

  @override
  String get minus50GuideText =>
      'Accumulate TQQQ aggressively while continuously lowering the average cost basis through systematic recurring purchases.';

  @override
  String get exchangeUsdKrw => '美元/韓元';

  @override
  String get exchangeUsdJpy => '美元/日圓';

  @override
  String get exchangeEurUsd => '歐元/美元';

  @override
  String get exchangeUsdRub => '美元/盧布';

  @override
  String get exchangeUsdTwd => '美元/新台幣';

  @override
  String get exchangeUsdCny => '美元/人民幣';

  @override
  String get fearGreedExtremeFear => '極度恐懼';

  @override
  String get fearGreedFear => '恐懼';

  @override
  String get fearGreedNeutral => '中性';

  @override
  String get fearGreedGreed => '貪婪';

  @override
  String get fearGreedExtremeGreed => '極度貪婪';

  @override
  String get fearGreedIndicatorsTitle => '7項恐懼與貪婪指標';

  @override
  String get fearGreedFaqTitle => '恐懼與貪婪指數說明';

  @override
  String get fearGreedWhatTitle => 'CNN恐懼與貪婪指數是什麼？';

  @override
  String get fearGreedWhatBody =>
      '恐懼與貪婪指數用來衡量股票市場情緒，以及股價是否可能處於合理水準。過度恐懼往往壓低股價，過度貪婪則可能推升股價。';

  @override
  String get fearGreedCalculatedTitle => '它如何計算？';

  @override
  String get fearGreedCalculatedBody =>
      '該指數結合七項市場指標：市場動能、股價強度、市場廣度、賣權/買權、垃圾債需求、市場波動率與避險資產需求。每項指標權重相同，形成0到100分。';

  @override
  String get fearGreedFrequencyTitle => '多久更新一次？';

  @override
  String get fearGreedFrequencyBody => '每個組成指標與整體指數都會在新的市場資料可用時更新。';

  @override
  String get fearGreedUseTitle => '應該如何使用？';

  @override
  String get fearGreedUseBody =>
      '可作為觀察市場情緒的輔助指標。它能幫助辨識情緒極端，但實際決策仍應搭配價格、基本面、風險管理與自己的策略。';

  @override
  String get strategyAdLabel => '廣告';

  @override
  String get alertSettingsTitle => '通知設定';

  @override
  String get alertHighTitle => '新高提醒';

  @override
  String get alertHighSubtitle => '安装后创下新高时提醒';

  @override
  String get alertMarketOpenTitle => '開盤提醒';

  @override
  String get alertMarketOpenSubtitle => '美股常规交易开始时每天提醒一次';

  @override
  String get alertStrategySettingTitle => '策略提醒';

  @override
  String get alertStrategySettingSubtitle => '提醒 -20%、-30%、-40%、-50% 区间变化';

  @override
  String get noBuyHeadline => '禁止追加買入，保持30%現金';

  @override
  String get noBuyActionTitle => '立即行动';

  @override
  String get noBuyActionText => '不要新买QLD/TQQQ。维持现有QLD仓位，并保留30%现金。';

  @override
  String get noBuyCashTitle => '现金规则';

  @override
  String get noBuyCashText => '现金是为下一轮下跌区间准备的储备资金。即使市场上涨也不要减少。';

  @override
  String get noBuyAvoidTitle => '避免';

  @override
  String get noBuyAvoidText => '不要因为价格上涨就追买。等待-20%区间出现。';

  @override
  String get noBuyNextTitle => '下一步';

  @override
  String get noBuyNextText => '到达-20%后，准备开始小额分批定投QLD。';

  @override
  String get minus20ActionTitle => '立即行动';

  @override
  String get minus20ActionText => '以很小金额开始分批定投QLD。不要一次投入大额资金。';

  @override
  String get minus20BuyRuleTitle => '买入规则';

  @override
  String get minus20BuyRuleText => '只使用总现金中很小的一部分。重点不是大举进场，而是开始节奏。';

  @override
  String get minus20CashTitle => '现金管理';

  @override
  String get minus20CashText => '大部分现金必须保留，用于应对-30%、-40%、-50%区间。';

  @override
  String get minus20AvoidTitle => '避免';

  @override
  String get minus20AvoidText => '不要激进买入TQQQ。-20%仍只是初期区间。';

  @override
  String get minus30ActionTitle => '立即行动';

  @override
  String get minus30ActionText => '只使用可用现金的10%买入TQQQ。下单前先确认现金总额。';

  @override
  String get minus30BuyRuleTitle => '买入规则';

  @override
  String get minus30BuyRuleText =>
      '如果現金為\$10,000，只使用\$1,000買入TQQQ，並保留剩餘90%的現金。';

  @override
  String get minus30AdditionalTitle => '追加行动';

  @override
  String get minus30AdditionalText => 'QLD定投可以继续，但TQQQ追加买入要等到下一个区间。';

  @override
  String get minus30AvoidTitle => '避免';

  @override
  String get minus30AvoidText => '不要因为确信反弹就大量使用现金。要按-40%区间仍可能到来的前提行动。';

  @override
  String get minus40ActionTitle => '立即行动';

  @override
  String get minus40ActionText => '使用剩余现金的30%买入TQQQ。计算时排除-30%已经使用的金额。';

  @override
  String get minus40BuyRuleTitle => '买入规则';

  @override
  String get minus40BuyRuleText => '如果剩餘現金為\$9,000，只使用\$2,700。關鍵是不要一次用完。';

  @override
  String get minus40HoldTitle => '持有规则';

  @override
  String get minus40HoldText => '继续持有QLD，TQQQ只增加到计划比例。为进一步下跌保留现金。';

  @override
  String get minus40AvoidTitle => '避免';

  @override
  String get minus40AvoidText => '不要因恐惧卖出现有仓位，也不要因贪婪全额买入。';

  @override
  String get minus50ActionTitle => '立即行动';

  @override
  String get minus50ActionText => '使用所有剩余现金买入TQQQ。这是计划中的最后现金投入阶段。';

  @override
  String get minus50BuyRuleTitle => '买入规则';

  @override
  String get minus50BuyRuleText => '以排除-30%、-40%已使用金额后的实际剩余现金为基准。';

  @override
  String get minus50AfterTitle => '之后行动';

  @override
  String get minus50AfterText => '之后有新增现金时，定期累积TQQQ或QLD，专注降低平均成本。';

  @override
  String get minus50AvoidTitle => '避免';

  @override
  String get minus50AvoidText => '不要只因亏损较大就放弃。不要用债务或短期生活资金追加买入。';

  @override
  String get alertNasdaq200Title => '納斯達克100 200日線提醒';

  @override
  String get alertNasdaq200Subtitle => '納斯達克100跌破或突破200日線時提醒';

  @override
  String get alertNasdaq200Breakdown => '納斯達克100跌破200日均線';

  @override
  String get alertNasdaq200Breakout => '納斯達克100重新突破200日均線';

  @override
  String get alertPortfolioCashTitle => '現金再平衡提醒';

  @override
  String get alertPortfolioCashSubtitle => '當股價上漲等導致現金比例低於20%時提醒';

  @override
  String get alertPortfolioCashHigh => '現金比例低於20%。請考慮再平衡以補充現金。';

  @override
  String get alertPortfolioCashLow => '現金比例低於20%。請考慮再平衡以補充現金。';

  @override
  String get alertAnnouncementTitle => '公告通知';

  @override
  String get alertAnnouncementSubtitle => '接收 QLD DIP ALERT 傳送的公告推播';

  @override
  String get alertDetailTitle => '提醒詳情';

  @override
  String get alertDetailOpenStrategy => '查看策略';

  @override
  String get alertDetailRecovery => '下跌區間已改善。請冷靜檢查投資組合，避免匆忙賣出或衝動買入。';

  @override
  String get alertDetailNewHigh => '安裝後記錄了新的最高價。它將作為未來下跌率計算的新基準。';

  @override
  String get alertDetailMarketOpen => '美股常規交易已開始。只有今天計畫行動時再檢查價格和策略提醒。';

  @override
  String get alertDetailNasdaq200Breakdown =>
      '納斯達克100跌破200日均線。長期趨勢可能轉弱，請檢查風險和現金比例。';

  @override
  String get alertDetailNasdaq200Breakout =>
      '納斯達克100重新站上200日均線。趨勢可能改善，但仍應遵循計畫策略。';

  @override
  String get alertDetailPortfolioCashHigh =>
      '現金比例低於20%參考線。這通常代表股價上漲後持倉比例變大、現金緩衝變小。請考慮減持部分部位，並再平衡到計畫的現金比例。';

  @override
  String get alertDetailPortfolioCashLow =>
      '現金比例低於20%參考線。這通常代表股價上漲後持倉比例變大、現金緩衝變小。請考慮減持部分部位，並再平衡到計畫的現金比例。';

  @override
  String get alertDetailOpenLink => '開啟連結';

  @override
  String get appUpdateTitle => '有可用更新';

  @override
  String get appUpdateMessage => '有新版本可用。請更新以使用最新功能與修正。';

  @override
  String get appUpdateLater => '稍後';

  @override
  String get appUpdateNow => '更新';
}
