// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for German (`de`).
class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get appTitle => 'QLD Alarm';

  @override
  String get noBuyZone => 'Keine-Kauf-Zone';

  @override
  String get tapToViewStrategy => 'Strategie anzeigen';

  @override
  String get buyNow => 'Jetzt kaufen';

  @override
  String get buyingInProgress => 'Kauf läuft';

  @override
  String get hold => 'Halten';

  @override
  String get navHome => 'Home';

  @override
  String get navChart => 'Chart';

  @override
  String get navExchange => 'FX';

  @override
  String get navFearGreed => 'Angst';

  @override
  String get fearGreedTitle => 'Angst und Gier';

  @override
  String get fearGreedSubtitle => 'CNN US-Marktsentiment';

  @override
  String get fearGreedUnavailable =>
      'Angst-und-Gier-Daten konnten nicht geladen werden.';

  @override
  String get navAlert => 'Alarm';

  @override
  String get navStrategy => 'Strategie';

  @override
  String get alertRecovery10 => 'QLD hat sich um 10 % erholt';

  @override
  String get alertMarketOpen => 'Der US-Markt ist geöffnet';

  @override
  String get alertNewHigh => 'Neues Hoch erreicht';

  @override
  String get portfolio => 'Portfolio';

  @override
  String get portfolioAssetInput => 'Vermögen';

  @override
  String get portfolioClose => 'Schließen';

  @override
  String get portfolioQldShares => 'QLD Stückzahl';

  @override
  String get portfolioTqqqShares => 'TQQQ Stückzahl';

  @override
  String get portfolioQldAveragePrice => 'QLD Durchschnittspreis';

  @override
  String get portfolioTqqqAveragePrice => 'TQQQ Durchschnittspreis';

  @override
  String get portfolioCashUsd => 'Cash USD';

  @override
  String get portfolioTotal => 'Gesamt';

  @override
  String get portfolioProfitLoss => 'Gewinn/Verlust';

  @override
  String get portfolioSharesUnit => 'Anteile';

  @override
  String get portfolioReturnRate => 'Rendite';

  @override
  String get portfolioAveragePriceShort => 'Durchschnittspreis';

  @override
  String get portfolioPriceLoading => 'Preis wird geladen';

  @override
  String get portfolioToBreakeven => 'Bis Break-even';

  @override
  String get portfolioBreakevenCleared => 'Über Break-even';

  @override
  String get basePosition => 'Basisposition';

  @override
  String get from10yHigh => 'vs 10J-Hoch';

  @override
  String get holdQLDPlusCash => 'QLD + 30% Cash halten';

  @override
  String get basePositionDescription =>
      '[ Strategy Guide ]\n\nThis strategy does not invest all assets into QLD at once.\n\nAt the beginning, only part of the assets is invested, while the rest is held in cash to prepare for major market declines.\n\nExample:\n- Invest only 70% of initial assets into QLD\n- Hold the remaining 30% in cash\n\nQLD is an ETF that tracks approximately 2x the daily movement of the Nasdaq-100 Index.\n\nTherefore, in the initial state:\n2x leverage × 70% investment = approximately 1.4x overall exposure.\n\nFor example:\n- Nasdaq +1%\n→ Total assets about +1.4%\n\nWhen a major decline occurs, the cash held is used step by step for additional buying.\n\nExample:\n- Additional buying around the QLD -40% zone\n\nThis allows more shares to be accumulated at lower prices, and when the market recovers, the average entry price can be significantly reduced.\n\nAs a result, this strategy may produce higher returns during recovery phases than a simple buy-and-hold strategy.\n\nThe core of this strategy is:\n- Reduce volatility with cash during rising markets\n- Use cash to buy more during major declines and lower the average cost.';

  @override
  String get buySignalMessage => 'Kaufsignale erscheinen hier.';

  @override
  String get currentPrice => 'Aktueller Preis';

  @override
  String get tenYearHigh => '10J-Hoch';

  @override
  String get buyStrategy => 'Kaufstrategie';

  @override
  String get noBuyZoneTitle => 'Keine-Kauf-Zone';

  @override
  String get strategyOverview => 'Überblick';

  @override
  String get corePrinciple => 'Kernprinzip';

  @override
  String get suggestedAllocation => 'Empfohlene Allokation';

  @override
  String get riskManagement => 'Risikomanagement';

  @override
  String get actionGuide => 'Handlungsleitfaden';

  @override
  String get marketStable =>
      'The Nasdaq market has historically maintained a long-term upward trend driven by technological innovation and global growth companies in the United States. Based on this growth potential, ProShares Ultra QQQ (QLD) is a leveraged ETF designed to track 2x the daily performance of the Nasdaq-100 Index, making it an efficient investment vehicle during long-term bullish market conditions.\n\nHowever, due to the nature of leveraged ETFs, volatility and downside risk can increase significantly during market downturns. Therefore, disciplined risk management is more important than simple buy-and-hold strategies. Maintaining approximately 30% of total assets in cash while gradually buying during sharp declines can help lower the average entry price and maximize long-term compounded returns.\n\nIn other words, the core of the QLD strategy is to utilize leverage efficiency during bull markets while maintaining sufficient cash reserves to respond flexibly during market corrections.';

  @override
  String get noPanicSignals =>
      'The Nasdaq market is not simply a collection of companies. It operates through a continuous rebalancing and replacement mechanism that maintains competitiveness over time. Innovative companies with strong growth and profitability are added to the index, while weaker companies gradually lose weight or are removed.\n\nThis structure continuously reallocates capital toward productive and high-growth businesses, strengthening the market’s long-term growth potential. Supported by technological innovation in the United States, the expansion of global platform companies, and ongoing monetary liquidity growth, the Nasdaq has become one of the primary markets absorbing global capital flows.\n\nIn other words, the Nasdaq is not just a market that rises over time, but a structural growth system driven by constant innovation and corporate evolution. Because of these characteristics, it is widely viewed as a market with strong long-term upside potential that benefits from both technological advancement and monetary expansion.';

  @override
  String get maintainBalanced =>
      'Maintaining balanced positions and sufficient cash reserves allows for flexible responses during future market corrections.';

  @override
  String get cashReserveRule => 'Always maintain at least 30% cash reserves.';

  @override
  String get cashPsychology =>
      'Holding cash provides psychological stability and enables consistent buying opportunities during future market downturns.';

  @override
  String get allocation1 => '• Maintain core QLD positions';

  @override
  String get allocation2 =>
      '• Secure at least 30% cash by taking profits when possible';

  @override
  String get allocation3 => '• Never chase short-term price surges';

  @override
  String get allocation4 => '• Prepare for future buying opportunities';

  @override
  String get risk1 =>
      'Even strong bull markets can reverse sharply at any time.';

  @override
  String get risk2 =>
      'Lack of cash reserves can reduce flexibility during market corrections.';

  @override
  String get guide1 => '✅ Stay disciplined';

  @override
  String get guide2 => '✅ Maintain strategic cash reserves';

  @override
  String get guide3 => '✅ Focus on long-term positioning';

  @override
  String get guide4 => '❌ Avoid emotional overbuying';

  @override
  String get minus20Title => '-20% Strategie';

  @override
  String get minus20Headline => 'Mit fraktionalen QLD-Sparplan-Käufen beginnen';

  @override
  String get minus20OverviewTitle => 'Strategy Overview';

  @override
  String get minus20OverviewText =>
      'This zone represents approximately a 10% correction in QQQ.\n\nSince the decline is still relatively moderate, maintaining cash reserves remains important.';

  @override
  String get minus20AllocationTitle => 'Suggested Allocation';

  @override
  String get minus20AllocationText =>
      '• Start accumulating with very small positions or simply hold\n• Proceed with slow and gradual buying\n• Avoid aggressive early entries\n• Preserve cash for larger potential declines';

  @override
  String get minus20HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus20HistoryText =>
      '• Average recovery period: approximately 1–2 months\n• Nasdaq has historically rebounded frequently after -20% corrections\n• Psychological pressure is relatively lower compared to major crashes';

  @override
  String get minus20RiskTitle => 'Risk Warning';

  @override
  String get minus20RiskText =>
      'Further downside is still possible after a -20% decline.\n\nAggressive early entries may create liquidity risk during deeper corrections.';

  @override
  String get minus20GuideTitle => 'Action Guide';

  @override
  String get minus20GuideText =>
      '✅ Start slowly\n✅ Buying is not mandatory at this stage\n✅ Maintain sufficient cash reserves\n❌ Avoid emotional buying';

  @override
  String get minus30Title => '-30% Strategie';

  @override
  String get minus30Headline => 'TQQQ mit 10% Cash kaufen';

  @override
  String get minus30OverviewTitle => 'Strategy Overview';

  @override
  String get minus30OverviewText =>
      'This zone represents a high-opportunity accumulation phase.\n\nHistorically, Nasdaq corrections around -30% have often provided strong long-term buying opportunities.\n\nAlthough fear and volatility increase significantly at this stage, disciplined dollar-cost averaging can improve long-term returns.';

  @override
  String get minus30AllocationTitle => 'Suggested Allocation';

  @override
  String get minus30AllocationText =>
      '• Deploy approximately 10% of available cash\n• Continue gradual accumulation\n• Avoid deploying all capital too quickly\n• Maintain flexibility for deeper declines';

  @override
  String get minus30HistoryTitle => 'Historical Recovery Data';

  @override
  String get minus30HistoryText =>
      '• Average recovery period ranges from approximately 6 months to over 1 year\n• Historically, strong rebounds often followed -30% corrections\n• Volatility and psychological pressure increase significantly in this zone';

  @override
  String get minus30RiskTitle => 'Risk Warning';

  @override
  String get minus30RiskText =>
      'Markets may remain highly volatile even after a -30% decline.\n\nOvercommitting capital without cash reserves can increase both psychological and financial risks.';

  @override
  String get minus30GuideTitle => 'Action Guide';

  @override
  String get minus30GuideText =>
      '✅ Maintain disciplined accumulation\n✅ Control emotions\n✅ Preserve remaining cash\n❌ Avoid panic buying and excessive leverage';

  @override
  String get minus40Title => '-40% Strategie';

  @override
  String get minus40Headline => '30% Cash einsetzen - TQQQ Einstieg';

  @override
  String get minus40OverviewTitle => 'Strategy Overview';

  @override
  String get minus40OverviewText =>
      'The -40% zone is a period of extreme market fear, but it can also become an important long-term buying opportunity. Maintaining a planned strategy is more important than emotional reactions.';

  @override
  String get minus40AllocationTitle => 'Capital Allocation';

  @override
  String get minus40AllocationText =>
      'Avoid deploying all capital at once. Scale in gradually across multiple stages while preserving sufficient cash for potential further downside.';

  @override
  String get minus40HistoryTitle => 'Crash History';

  @override
  String get minus40HistoryText =>
      'Historically, markets have eventually recovered even after major crashes. Extreme fear zones have often created opportunities for long-term investors.';

  @override
  String get minus40RiskTitle => 'Psychological Risk';

  @override
  String get minus40RiskText =>
      'As declines deepen, fear and anxiety intensify. It is important to stay disciplined and avoid reacting emotionally to short-term volatility and news.';

  @override
  String get minus40GuideTitle => 'Survival Guide';

  @override
  String get minus40GuideText =>
      'Focus on long-term survival rather than predicting short-term rebounds. Avoid excessive leverage and emotional all-in positions while maintaining a consistent accumulation strategy.';

  @override
  String get minus50Title => '-50% Strategie';

  @override
  String get minus50Headline => 'TQQQ mit allem restlichen Cash kaufen';

  @override
  String get minus50OverviewTitle => 'Deploy Remaining Cash into TQQQ';

  @override
  String get minus50OverviewText =>
      'A -50% decline represents an extreme market fear environment. Most investors experience panic during this phase, and volatility can remain exceptionally high.';

  @override
  String get minus50AllocationTitle => 'Capital Allocation';

  @override
  String get minus50AllocationText =>
      'Deploy remaining cash into TQQQ. Continue lowering the average entry price through systematic recurring purchases afterward.';

  @override
  String get minus50HistoryTitle => 'After Major Crashes';

  @override
  String get minus50HistoryText =>
      'Historically, markets have recovered over time following major crashes. The Nasdaq has structurally maintained long-term growth. Extreme fear should be viewed as opportunity rather than panic.';

  @override
  String get minus50RiskTitle => 'Psychological Pressure';

  @override
  String get minus50RiskText =>
      'Rather than feeling psychological pressure, investors should recognize this phase as a potential deep-value buying opportunity.';

  @override
  String get minus50GuideTitle => 'Survival Strategy';

  @override
  String get minus50GuideText =>
      'Accumulate TQQQ aggressively while continuously lowering the average cost basis through systematic recurring purchases.';

  @override
  String get exchangeUsdKrw => 'Dollar/Won';

  @override
  String get exchangeUsdJpy => 'Dollar/Yen';

  @override
  String get exchangeEurUsd => 'Euro/Dollar';

  @override
  String get exchangeUsdRub => 'Dollar/Rubel';

  @override
  String get exchangeUsdTwd => 'Dollar/Taiwan-Dollar';

  @override
  String get exchangeUsdCny => 'Dollar/Yuan';

  @override
  String get fearGreedExtremeFear => 'Extreme Angst';

  @override
  String get fearGreedFear => 'Angst';

  @override
  String get fearGreedNeutral => 'Neutral';

  @override
  String get fearGreedGreed => 'Gier';

  @override
  String get fearGreedExtremeGreed => 'Extreme Gier';

  @override
  String get fearGreedIndicatorsTitle => '7 Angst-und-Gier-Indikatoren';

  @override
  String get fearGreedFaqTitle => 'Fragen zum Angst-und-Gier-Index';

  @override
  String get fearGreedWhatTitle => 'Was ist der CNN Fear & Greed Index?';

  @override
  String get fearGreedWhatBody =>
      'Der Index misst die Stimmung am Aktienmarkt und ob Aktien fair bewertet sein könnten. Übermäßige Angst drückt Kurse oft nach unten, während übermäßige Gier Kurse nach oben treiben kann.';

  @override
  String get fearGreedCalculatedTitle => 'Wie wird er berechnet?';

  @override
  String get fearGreedCalculatedBody =>
      'Er kombiniert sieben Indikatoren: Marktmomentum, Kursstärke, Marktbreite, Put/Call-Optionen, Nachfrage nach Hochzinsanleihen, Volatilität und Nachfrage nach sicheren Häfen. Alle Indikatoren fließen gleichgewichtet in eine Skala von 0 bis 100 ein.';

  @override
  String get fearGreedFrequencyTitle => 'Wie oft wird er aktualisiert?';

  @override
  String get fearGreedFrequencyBody =>
      'Jede Komponente und der Gesamtindex werden aktualisiert, sobald neue Marktdaten verfügbar sind.';

  @override
  String get fearGreedUseTitle => 'Wie sollte ich ihn nutzen?';

  @override
  String get fearGreedUseBody =>
      'Nutzen Sie ihn als Stimmungsindikator. Er hilft, emotionale Extreme zu erkennen, sollte aber mit Kursen, Fundamentaldaten, Risikokontrolle und der eigenen Strategie kombiniert werden.';

  @override
  String get strategyAdLabel => 'Anzeige';

  @override
  String get alertSettingsTitle => 'Benachrichtigungseinstellungen';

  @override
  String get alertHighTitle => 'Neues-Hoch-Alarm';

  @override
  String get alertHighSubtitle =>
      'Benachrichtigen, wenn nach der Installation ein neues Hoch erreicht wird';

  @override
  String get alertMarketOpenTitle => 'Markteröffnung-Alarm';

  @override
  String get alertMarketOpenSubtitle =>
      'Einmal täglich benachrichtigen, wenn der reguläre US-Markt öffnet';

  @override
  String get alertStrategySettingTitle => 'Strategie-Alarm';

  @override
  String get alertStrategySettingSubtitle =>
      'Bei Änderungen der Zonen -20 %, -30 %, -40 % und -50 % benachrichtigen';

  @override
  String get noBuyHeadline => 'Keine Zusatzkäufe. 30 % Cash halten.';

  @override
  String get noBuyActionTitle => 'Sofortige Aktion';

  @override
  String get noBuyActionText =>
      'Keine neuen QLD/TQQQ-Käufe. Bestehende QLD-Position halten und 30 % Cash schützen.';

  @override
  String get noBuyCashTitle => 'Cash-Regel';

  @override
  String get noBuyCashText =>
      'Cash ist Reservekapital für die nächste Rückgangszone. Auch bei steigenden Märkten nicht reduzieren.';

  @override
  String get noBuyAvoidTitle => 'Vermeiden';

  @override
  String get noBuyAvoidText =>
      'Kaufen Sie nicht hinterher, nur weil der Preis steigt. Warten Sie auf die -20 %-Zone.';

  @override
  String get noBuyNextTitle => 'Nächster Schritt';

  @override
  String get noBuyNextText =>
      'Bei -20 % auf kleine regelmäßige QLD-Teilkaufe vorbereiten.';

  @override
  String get minus20ActionTitle => 'Sofortige Aktion';

  @override
  String get minus20ActionText =>
      'Sehr kleine regelmäßige QLD-Teilkaufe starten. Keinen großen Betrag auf einmal einsetzen.';

  @override
  String get minus20BuyRuleTitle => 'Kaufregel';

  @override
  String get minus20BuyRuleText =>
      'Nur einen winzigen Teil des Cashbestands nutzen. Ziel ist der Rhythmus, nicht ein großer Einstieg.';

  @override
  String get minus20CashTitle => 'Cash-Management';

  @override
  String get minus20CashText =>
      'Der größte Teil des Cashs muss für -30 %, -40 % und -50 % verfügbar bleiben.';

  @override
  String get minus20AvoidTitle => 'Vermeiden';

  @override
  String get minus20AvoidText =>
      'TQQQ nicht aggressiv kaufen. -20 % ist noch eine frühe Phase.';

  @override
  String get minus30ActionTitle => 'Sofortige Aktion';

  @override
  String get minus30ActionText =>
      'Nur 10 % des verfügbaren Cashs für TQQQ verwenden. Vor der Order den Cashbestand prüfen.';

  @override
  String get minus30BuyRuleTitle => 'Kaufregel';

  @override
  String get minus30BuyRuleText =>
      'Bei \$10.000 Cash nur \$1.000 für TQQQ nutzen und die restlichen 90 % behalten.';

  @override
  String get minus30AdditionalTitle => 'Zusätzliche Aktion';

  @override
  String get minus30AdditionalText =>
      'QLD kann weiter gesammelt werden, zusätzliche TQQQ-Käufe warten bis zur nächsten Zone.';

  @override
  String get minus30AvoidTitle => 'Vermeiden';

  @override
  String get minus30AvoidText =>
      'Nicht zu viel Cash ausgeben, nur weil Sie eine Erholung erwarten. Handeln Sie so, als könne -40 % noch kommen.';

  @override
  String get minus40ActionTitle => 'Sofortige Aktion';

  @override
  String get minus40ActionText =>
      '30 % des restlichen Cashs für TQQQ verwenden. Beträge aus der -30 %-Zone abziehen.';

  @override
  String get minus40BuyRuleTitle => 'Kaufregel';

  @override
  String get minus40BuyRuleText =>
      'Bei \$9.000 Restcash nur \$2.700 nutzen. Nicht alles auf einmal verwenden.';

  @override
  String get minus40HoldTitle => 'Halte-Regel';

  @override
  String get minus40HoldText =>
      'QLD halten und TQQQ nur bis zur geplanten Höhe erhöhen. Cash für weiteren Rückgang behalten.';

  @override
  String get minus40AvoidTitle => 'Vermeiden';

  @override
  String get minus40AvoidText =>
      'Nicht aus Angst verkaufen. Nicht aus Gier mit allem Cash kaufen.';

  @override
  String get minus50ActionTitle => 'Sofortige Aktion';

  @override
  String get minus50ActionText =>
      'Das gesamte verbleibende Cash für TQQQ verwenden. Dies ist die letzte geplante Cash-Einsatzstufe.';

  @override
  String get minus50BuyRuleTitle => 'Kaufregel';

  @override
  String get minus50BuyRuleText =>
      'Nur das tatsächlich verbleibende Cash nach -30 % und -40 % als Basis nehmen.';

  @override
  String get minus50AfterTitle => 'Danach';

  @override
  String get minus50AfterText =>
      'Bei neuem Cash regelmäßig TQQQ oder QLD sammeln und den Durchschnittspreis senken.';

  @override
  String get minus50AvoidTitle => 'Vermeiden';

  @override
  String get minus50AvoidText =>
      'Nicht wegen hoher Verluste aufgeben. Keine Schulden oder kurzfristigen Lebenshaltungsmittel für Nachkäufe nutzen.';

  @override
  String get alertNasdaq200Title => 'Nasdaq 100 200-Tage-Alarm';

  @override
  String get alertNasdaq200Subtitle =>
      'Benachrichtigen, wenn der Nasdaq 100 die 200-Tage-Linie unter- oder überschreitet';

  @override
  String get alertNasdaq200Breakdown =>
      'Der Nasdaq 100 ist unter die 200-Tage-Linie gefallen';

  @override
  String get alertNasdaq200Breakout =>
      'Der Nasdaq 100 ist wieder über die 200-Tage-Linie gestiegen';

  @override
  String get alertPortfolioCashTitle => 'Cash-Rebalancing-Alarm';

  @override
  String get alertPortfolioCashSubtitle =>
      'Benachrichtigen, wenn Cash nach Kursanstiegen unter 20 % fällt';

  @override
  String get alertPortfolioCashHigh =>
      'Die Cashquote liegt unter 20 %. Rebalancing zum Wiederaufbau von Cash prüfen.';

  @override
  String get alertPortfolioCashLow =>
      'Die Cashquote liegt unter 20 %. Rebalancing zum Wiederaufbau von Cash prüfen.';

  @override
  String get alertAnnouncementTitle => 'Ankündigungsbenachrichtigungen';

  @override
  String get alertAnnouncementSubtitle =>
      'Ankündigungen von QLD DIP ALERT als Push-Benachrichtigungen erhalten';

  @override
  String get alertDetailTitle => 'Alarmdetails';

  @override
  String get alertDetailOpenStrategy => 'Strategie öffnen';

  @override
  String get alertDetailRecovery =>
      'Die Rückgangszone hat sich verbessert. Prüfen Sie das Portfolio ruhig und vermeiden Sie impulsive Käufe oder Verkäufe.';

  @override
  String get alertDetailNewHigh =>
      'Nach der Installation wurde ein neues Hoch gespeichert. Es dient als neue Basis für künftige Rückgangsberechnungen.';

  @override
  String get alertDetailMarketOpen =>
      'Der reguläre US-Markt ist geöffnet. Prüfen Sie Preise nur, wenn Sie heute handeln wollten.';

  @override
  String get alertDetailNasdaq200Breakdown =>
      'Der Nasdaq 100 fiel unter die 200-Tage-Linie. Das kann auf schwächeren Trend hindeuten; prüfen Sie Risiko und Cash.';

  @override
  String get alertDetailNasdaq200Breakout =>
      'Der Nasdaq 100 stieg wieder über die 200-Tage-Linie. Das kann auf Verbesserung hindeuten, dennoch Strategie einhalten.';

  @override
  String get alertDetailPortfolioCashHigh =>
      'Die Cashquote liegt unter dem 20-%-Richtwert. Das bedeutet oft, dass Aktien gestiegen sind und der Cash-Puffer zu klein wurde. Prüfen Sie, ob Sie einen Teil der Position reduzieren und auf die geplante Cashquote rebalancieren.';

  @override
  String get alertDetailPortfolioCashLow =>
      'Die Cashquote liegt unter dem 20-%-Richtwert. Das bedeutet oft, dass Aktien gestiegen sind und der Cash-Puffer zu klein wurde. Prüfen Sie, ob Sie einen Teil der Position reduzieren und auf die geplante Cashquote rebalancieren.';

  @override
  String get alertDetailOpenLink => 'Link öffnen';

  @override
  String get appUpdateTitle => 'Update verfügbar';

  @override
  String get appUpdateMessage =>
      'Eine neue Version ist verfügbar. Aktualisieren Sie, um die neuesten Funktionen und Korrekturen zu nutzen.';

  @override
  String get appUpdateLater => 'Später';

  @override
  String get appUpdateNow => 'Aktualisieren';
}
