import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'l10n/app_localizations.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

const AndroidNotificationChannel _qldAlertChannel =
    AndroidNotificationChannel(
  'qld_alerts',
  'QLD Alerts',
  description: 'QLD buy zone and Firebase push alerts',
  importance: Importance.high,
);

const _announcementTopic = 'qld_alerts';

const List<String> _alertTopicLanguages = [
  'en',
  'ko',
  'ja',
  'es',
  'pt',
  'ru',
  'zh',
  'zh_TW',
  'fr',
  'de',
];

final FlutterLocalNotificationsPlugin _localNotifications =
    FlutterLocalNotificationsPlugin();
final GlobalKey<NavigatorState> appNavigatorKey =
    GlobalKey<NavigatorState>();

const _announcementAlertType = 'announcement';
const _tradingViewInstallAlertType = 'tradingViewInstall';
const _tradingViewInstallUrl =
    'https://play.google.com/store/apps/details?id=com.tradingview.tradingviewapp&utm_source=chatgpt.com';
const _currentAppVersionCode = 20;
const _androidPackageName = 'com.qldalert.app';

const _yahooProxyBaseUrl =
    'https://billowing-band-06cd.nn46099080.workers.dev/';
const _appConfigUrl =
    'https://billowing-band-06cd.rska2.workers.dev/app-config';

Uri _chartProxyUri(String symbol) =>
    Uri.parse(_yahooProxyBaseUrl).replace(
      queryParameters: {'symbol': symbol},
    );

Uri _dailyChartProxyUri(String symbol) =>
    Uri.parse(_yahooProxyBaseUrl).replace(
      queryParameters: {
        'symbol': symbol,
        'dailyOnly': '1',
      },
    );

Uri _quoteProxyUri(String symbol) =>
    Uri.parse(_yahooProxyBaseUrl).replace(
      path: '/quote',
      queryParameters: {'symbol': symbol},
    );

/// All market data must go through Cloudflare Worker (never Yahoo directly).
Future<Map<String, dynamic>?> _fetchChartFromWorker(
  String symbol,
) async {
  return _fetchChartFromWorkerUri(_chartProxyUri(symbol), symbol);
}

Future<Map<String, dynamic>?> _fetchDailyChartFromWorker(
  String symbol,
) async {
  return _fetchChartFromWorkerUri(_dailyChartProxyUri(symbol), symbol);
}

Future<Map<String, dynamic>?> _fetchChartFromWorkerUri(
  Uri uri,
  String symbol,
) async {
  try {
    final response = await http
        .get(uri)
        .timeout(const Duration(seconds: 8));

    if (response.statusCode != 200) {
      debugPrint(
        'Market data server returned ${response.statusCode} ($symbol)',
      );
      return null;
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final results = data['chart']?['result'] as List?;

    if (results == null || results.isEmpty) {
      debugPrint('Market data response empty ($symbol)');
      return null;
    }

    return results[0] as Map<String, dynamic>;
  } catch (error) {
    debugPrint('Market data network unavailable ($symbol)');
    return null;
  }
}

class FinnhubQuote {
  const FinnhubQuote({
    required this.currentPrice,
    required this.previousClose,
  });

  final double currentPrice;
  final double previousClose;
}

class QldMiniCandle {
  const QldMiniCandle({
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.ma200,
  });

  final double open;
  final double high;
  final double low;
  final double close;
  final double? ma200;
}

List<QldMiniCandle> _qldMiniCandlesWithRealtimeClose(
  List<QldMiniCandle> candles,
  double price,
) {
  if (candles.isEmpty || price <= 0) return candles;

  final nextCandles = List<QldMiniCandle>.of(candles);
  final last = nextCandles.last;
  nextCandles[nextCandles.length - 1] = QldMiniCandle(
    open: last.open,
    high: math.max(last.high, price),
    low: math.min(last.low, price),
    close: price,
    ma200: last.ma200,
  );
  return nextCandles;
}

class _QldMiniCandlePainter extends CustomPainter {
  const _QldMiniCandlePainter({
    required this.candles,
    required this.minY,
    required this.maxY,
  });

  final List<QldMiniCandle> candles;
  final double minY;
  final double maxY;

  @override
  void paint(Canvas canvas, Size size) {
    if (candles.isEmpty || maxY <= minY || size.width <= 0 || size.height <= 0) {
      return;
    }

    final range = maxY - minY;
    final candleWidth = math.max(1.2, (size.width / candles.length) * 0.46);
    final wickPaint = Paint()
      ..strokeWidth = 1
      ..strokeCap = StrokeCap.round;
    final bodyPaint = Paint();

    double xForIndex(int index) {
      if (candles.length == 1) return size.width / 2;
      return (index / (candles.length - 1)) * size.width;
    }

    double yForPrice(double value) {
      return size.height - ((value - minY) / range) * size.height;
    }

    void drawPriceLabel(
      String text,
      Offset anchor, {
      required Color color,
      bool alignRight = true,
    }) {
      final textPainter = TextPainter(
        text: TextSpan(
          text: text,
          style: TextStyle(
            color: color,
            fontSize: 9,
            fontWeight: FontWeight.w800,
          ),
        ),
        textDirection: ui.TextDirection.ltr,
      )..layout();
      final dx = alignRight ? anchor.dx - textPainter.width : anchor.dx;
      final dy = (anchor.dy - textPainter.height / 2)
          .clamp(4.0, size.height - textPainter.height - 4)
          .toDouble();
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(
          dx - 4,
          dy - 2,
          textPainter.width + 8,
          textPainter.height + 4,
        ),
        const Radius.circular(4),
      );
      canvas.drawRRect(
        rect,
        Paint()..color = const Color(0xCC101722),
      );
      textPainter.paint(canvas, Offset(dx, dy));
    }

    final axisPaint = Paint()
      ..color = Colors.white.withOpacity(0.08)
      ..strokeWidth = 1;
    final axisValues = <double>[
      maxY,
      minY + range / 2,
      minY,
    ];

    for (final value in axisValues) {
      final y = yForPrice(value).clamp(0.0, size.height).toDouble();
      canvas.drawLine(Offset(0, y), Offset(size.width, y), axisPaint);
    }

    var lowestPrice = double.infinity;
    var lowestIndex = 0;

    for (int i = 0; i < candles.length; i++) {
      final candle = candles[i];
      if (candle.low < lowestPrice) {
        lowestPrice = candle.low;
        lowestIndex = i;
      }
      final isUp = candle.close >= candle.open;
      final color =
          isUp ? _cyan.withOpacity(0.72) : Colors.redAccent.withOpacity(0.78);
      final x = xForIndex(i);
      final highY = yForPrice(candle.high).clamp(0.0, size.height).toDouble();
      final lowY = yForPrice(candle.low).clamp(0.0, size.height).toDouble();
      final openY = yForPrice(candle.open).clamp(0.0, size.height).toDouble();
      final closeY =
          yForPrice(candle.close).clamp(0.0, size.height).toDouble();
      final top = math.min(openY, closeY);
      final bottom = math.max(openY, closeY);

      wickPaint.color = color.withOpacity(0.72);
      canvas.drawLine(Offset(x, highY), Offset(x, lowY), wickPaint);

      bodyPaint.color = color;
      final bodyRect = RRect.fromRectAndRadius(
        Rect.fromLTRB(
          x - candleWidth / 2,
          top,
          x + candleWidth / 2,
          math.max(bottom, top + 1.4),
        ),
        const Radius.circular(1.8),
      );
      canvas.drawRRect(bodyRect, bodyPaint);
    }

    for (final value in axisValues) {
      final y = yForPrice(value).clamp(0.0, size.height).toDouble();
      drawPriceLabel(
        '\$${value.toStringAsFixed(2)}',
        Offset(size.width - 5, y),
        color: Colors.white54,
      );
    }

    if (lowestPrice.isFinite) {
      final lowX = xForIndex(lowestIndex).clamp(8.0, size.width - 8).toDouble();
      final lowY = yForPrice(lowestPrice).clamp(0.0, size.height).toDouble();
      canvas.drawCircle(
        Offset(lowX, lowY),
        2.8,
        Paint()..color = Colors.white.withOpacity(0.9),
      );
      drawPriceLabel(
        '\$${lowestPrice.toStringAsFixed(2)}',
        Offset(
          math.min(lowX + 8, size.width - 6),
          lowY - 13,
        ),
        color: Colors.white,
        alignRight: lowX > size.width - 68,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _QldMiniCandlePainter oldDelegate) {
    return oldDelegate.candles != candles ||
        oldDelegate.minY != minY ||
        oldDelegate.maxY != maxY;
  }
}

double _numberToDouble(dynamic value) {
  if (value is num) return value.toDouble();
  return double.tryParse(value?.toString() ?? '') ?? 0;
}

Future<FinnhubQuote?> fetchQuote(String symbol) async {
  try {
    final response = await http.get(_quoteProxyUri(symbol)).timeout(
          const Duration(seconds: 8),
        );

    if (response.statusCode != 200) {
      debugPrint(
        'Worker quote failed ($symbol): HTTP ${response.statusCode}',
      );
      return null;
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final responseSymbol = data['symbol']?.toString().toUpperCase() ?? '';
    final requestedSymbol = symbol.toUpperCase();
    final currentPrice = _numberToDouble(data['currentPrice'] ?? data['c']);
    final previousClose = _numberToDouble(data['previousClose'] ?? data['pc']);

    if (responseSymbol.isNotEmpty && responseSymbol != requestedSymbol) {
      debugPrint(
        'Worker quote symbol mismatch: requested $symbol, got $responseSymbol',
      );
      return null;
    }

    if (currentPrice <= 0) {
      debugPrint(
        'Worker quote invalid ($symbol): current=$currentPrice, body=${response.body}',
      );
      return null;
    }

    debugPrint(
      'Worker quote ok ($symbol): current=$currentPrice previousClose=$previousClose cache=${response.headers['x-cache']}',
    );

    return FinnhubQuote(
      currentPrice: currentPrice,
      previousClose: previousClose,
    );
  } catch (error) {
    debugPrint('Worker quote unavailable ($symbol): $error');
    return null;
  }
}

Future<String> savedLanguageCode() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('selectedLanguage') ?? 'en';
}

String alertTopicLanguageCode(String code) {
  final normalized = code.replaceAll('-', '_');
  if (normalized == 'zh_TW' || normalized.toLowerCase() == 'zh_hant') {
    return 'zh_TW';
  }
  if (normalized.startsWith('zh')) return 'zh';
  if (_alertTopicLanguages.contains(normalized)) return normalized;

  final baseCode = normalized.split('_').first;
  return _alertTopicLanguages.contains(baseCode) ? baseCode : 'en';
}

String alertTopicForLanguage(String code) =>
    '${_announcementTopic}_${alertTopicLanguageCode(code)}';

Future<void> syncAlertLanguageTopic(String languageCode) async {
  if (kIsWeb) return;

  final messaging = FirebaseMessaging.instance;
  final nextTopic = alertTopicForLanguage(languageCode);

  // Keep the shared topic for Firebase Console announcements.
  // Market alerts use language-specific topics to show the right language
  // while the app is closed.
  await messaging.subscribeToTopic(_announcementTopic);

  for (final code in _alertTopicLanguages) {
    final topic = alertTopicForLanguage(code);
    if (topic == nextTopic) continue;
    await messaging.unsubscribeFromTopic(topic);
  }

  await messaging.subscribeToTopic(nextTopic);
}

String localeLanguageCode(Locale locale) {
  if (locale.languageCode == 'zh' &&
      locale.scriptCode?.toLowerCase() == 'hant') {
    return 'zh_TW';
  }
  if (locale.languageCode == 'zh' && locale.countryCode == 'TW') {
    return 'zh_TW';
  }
  return locale.languageCode;
}

String localizedProfitTargetSettingTitle(Locale locale) {
  switch (localeLanguageCode(locale)) {
    case 'ko':
      return '수익률 달성 알림';
    case 'ja':
      return '利益率達成アラート';
    case 'es':
      return 'Alerta de rentabilidad';
    case 'pt':
      return 'Alerta de rentabilidade';
    case 'ru':
      return 'Уведомление о доходности';
    case 'zh':
      return '收益率达成提醒';
    case 'zh_TW':
      return '收益率達成提醒';
    case 'fr':
      return 'Alerte de rendement';
    case 'de':
      return 'Rendite-Zielalarm';
    default:
      return 'Profit Target Alert';
  }
}

String localizedProfitTargetSettingSubtitle(Locale locale) {
  switch (localeLanguageCode(locale)) {
    case 'ko':
      return '평균단가 대비 50%, 100%, 200%, 300% 달성 시 알림';
    case 'ja':
      return '平均取得単価比で50%、100%、200%、300%達成時に通知';
    case 'es':
      return 'Aviso al alcanzar 50%, 100%, 200% y 300% sobre el precio medio';
    case 'pt':
      return 'Aviso aos 50%, 100%, 200% e 300% sobre o preço médio';
    case 'ru':
      return 'Оповещение при 50%, 100%, 200% и 300% от средней цены';
    case 'zh':
      return '相对平均成本达到50%、100%、200%、300%时提醒';
    case 'zh_TW':
      return '相對平均成本達到50%、100%、200%、300%時提醒';
    case 'fr':
      return 'Alerte à 50%, 100%, 200% et 300% par rapport au prix moyen';
    case 'de':
      return 'Alarm bei 50%, 100%, 200% und 300% über dem Durchschnittspreis';
    default:
      return 'Notify at 50%, 100%, 200%, and 300% above your average price';
  }
}

String localizedProfitTargetMessage(
  Locale locale,
  String symbol,
  int target,
) {
  switch (localeLanguageCode(locale)) {
    case 'ko':
      return '$symbol 수익률 $target% 달성';
    case 'ja':
      return '$symbol 利益率$target%達成';
    case 'es':
      return '$symbol alcanzó $target% de rentabilidad';
    case 'pt':
      return '$symbol atingiu $target% de rentabilidade';
    case 'ru':
      return '$symbol достиг доходности $target%';
    case 'zh':
      return '$symbol 收益率达到$target%';
    case 'zh_TW':
      return '$symbol 收益率達到$target%';
    case 'fr':
      return '$symbol a atteint $target% de rendement';
    case 'de':
      return '$symbol hat $target% Rendite erreicht';
    default:
      return '$symbol profit reached $target%';
  }
}

String localizedProfitTargetDetail(
  Locale locale,
  String symbol,
  int target,
) {
  switch (localeLanguageCode(locale)) {
    case 'ko':
      return '$symbol가 입력한 평균단가 대비 $target% 수익률을 달성했습니다. 급하게 전량 매도하기보다 목표 비중과 현금 비중을 함께 확인하세요.';
    case 'ja':
      return '$symbolは入力した平均取得単価に対して$target%の利益率に達しました。急いで全売却せず、目標比率と現金比率を確認してください。';
    case 'es':
      return '$symbol alcanzó una rentabilidad del $target% frente a tu precio medio. Revisa tu asignación objetivo y el efectivo antes de vender con prisa.';
    case 'pt':
      return '$symbol atingiu $target% de rentabilidade sobre o seu preço médio. Revise a alocação-alvo e o caixa antes de vender com pressa.';
    case 'ru':
      return '$symbol достиг доходности $target% к вашей средней цене. Проверьте целевую долю и кэш перед поспешной продажей.';
    case 'zh':
      return '$symbol 相对你输入的平均成本已达到 $target% 收益率。不要急于全部卖出，先检查目标配置和现金比例。';
    case 'zh_TW':
      return '$symbol 相對你輸入的平均成本已達到 $target% 收益率。不要急著全部賣出，先檢查目標配置和現金比例。';
    case 'fr':
      return '$symbol a atteint $target% de rendement par rapport à votre prix moyen. Vérifiez votre allocation cible et votre cash avant de vendre trop vite.';
    case 'de':
      return '$symbol hat gegenüber deinem Durchschnittspreis $target% Rendite erreicht. Prüfe Zielgewichtung und Cash-Anteil, bevor du überhastet verkaufst.';
    default:
      return '$symbol reached a $target% gain from your average price. Check your target allocation and cash level before making a rushed sell decision.';
  }
}

String localizedPriceRefreshStatus(
  Locale locale, {
  required bool isRefreshing,
  required bool isCached,
}) {
  final code = localeLanguageCode(locale);

  if (isRefreshing) {
    switch (code) {
      case 'ko':
        return '업데이트 중...';
      case 'ja':
        return '更新中...';
      case 'es':
        return 'Actualizando...';
      case 'pt':
        return 'Atualizando...';
      case 'ru':
        return 'Обновление...';
      case 'zh':
        return '正在更新...';
      case 'zh_TW':
        return '正在更新...';
      case 'fr':
        return 'Mise à jour...';
      case 'de':
        return 'Aktualisierung...';
      default:
        return 'Updating...';
    }
  }

  if (isCached) {
    switch (code) {
      case 'ko':
        return '최근 저장 가격';
      case 'ja':
        return '最近保存した価格';
      case 'es':
        return 'Precio guardado reciente';
      case 'pt':
        return 'Preço salvo recente';
      case 'ru':
        return 'Последняя сохраненная цена';
      case 'zh':
        return '最近保存价格';
      case 'zh_TW':
        return '最近儲存價格';
      case 'fr':
        return 'Prix enregistré récent';
      case 'de':
        return 'Zuletzt gespeicherter Preis';
      default:
        return 'Recent saved price';
    }
  }

  switch (code) {
    case 'ko':
      return '방금 갱신됨';
    case 'ja':
      return '今更新されました';
    case 'es':
      return 'Actualizado ahora';
    case 'pt':
      return 'Atualizado agora';
    case 'ru':
      return 'Только что обновлено';
    case 'zh':
      return '刚刚更新';
    case 'zh_TW':
      return '剛剛更新';
    case 'fr':
      return 'Mis à jour maintenant';
    case 'de':
      return 'Gerade aktualisiert';
    default:
      return 'Just updated';
  }
}

String localizedMarketStatusText(
  Locale locale, {
  required bool isPreMarket,
  required bool isRegularMarket,
  required bool isAfterHours,
}) {
  switch (localeLanguageCode(locale)) {
    case 'ko':
      if (isPreMarket) return '장전';
      if (isRegularMarket) return '실시간';
      if (isAfterHours) return '시간외';
      return '휴장';
    case 'ja':
      if (isPreMarket) return '寄前';
      if (isRegularMarket) return 'ライブ';
      if (isAfterHours) return '時間外';
      return '休場';
    case 'zh':
      if (isPreMarket) return '盘前';
      if (isRegularMarket) return '实时';
      if (isAfterHours) return '盘后';
      return '休市';
    case 'zh_TW':
      if (isPreMarket) return '盤前';
      if (isRegularMarket) return '即時';
      if (isAfterHours) return '盤後';
      return '休市';
    default:
      if (isPreMarket) return 'PRE';
      if (isRegularMarket) return 'LIVE';
      if (isAfterHours) return 'POST';
      return 'CLOSED';
  }
}

String localizedRemoteValue(
  Map<String, dynamic> data,
  String key,
  String languageCode,
  String fallback,
) {
  final normalizedCode = languageCode.replaceAll('-', '_');
  final baseCode = normalizedCode.split('_').first;
  final camelCode = normalizedCode
      .split('_')
      .map(
        (part) => part.isEmpty
            ? part
            : '${part[0].toUpperCase()}${part.substring(1)}',
      )
      .join();
  final lowerCode = normalizedCode.toLowerCase();
  final aliases = <String>{
    normalizedCode,
    lowerCode,
    baseCode,
    if (normalizedCode == 'zh_TW') ...[
      'zh-Hant',
      'zh_Hant',
      'zhHant',
      'tw',
      'traditional',
    ],
    if (normalizedCode == 'zh') ...[
      'zh_CN',
      'zh-CN',
      'zh_Hans',
      'zhHans',
      'cn',
      'simplified',
    ],
  };

  final candidates = <String>[
    for (final code in aliases) ...[
      '${key}_$code',
      '${key}-$code',
      '${key}${code.toUpperCase()}',
    ],
    '${key}$camelCode',
    '${key}_${baseCode.toUpperCase()}',
    key,
  ];

  for (final candidate in candidates) {
    final value = data[candidate]?.toString();
    if (value != null && value.trim().isNotEmpty) {
      return value.trim();
    }
  }

  return fallback;
}

Future<AlertHistoryItem> alertItemFromRemoteMessageLocalized(
  RemoteMessage message,
) async {
  final languageCode = await savedLanguageCode();
  final data = message.data;
  final fallbackTitle = message.notification?.title ??
      data['title']?.toString() ??
      'QLD Alert';
  final fallbackBody =
      message.notification?.body ?? data['body']?.toString() ?? '';

  final title = localizedRemoteValue(
    data,
    'title',
    languageCode,
    fallbackTitle,
  );
  final body = localizedRemoteValue(
    data,
    'body',
    languageCode,
    fallbackBody,
  );
  final detail = localizedRemoteValue(
    data,
    'detail',
    languageCode,
    body.isEmpty ? title : body,
  );
  final link = localizedRemoteValue(
    data,
    'link',
    languageCode,
    data['url']?.toString() ?? '',
  );
  final type = data['type']?.toString() ?? _announcementAlertType;

  return AlertHistoryItem(
    message: title,
    detail: detail,
    link: link,
    type: type,
    createdAt: DateTime.now(),
  );
}

bool isAnnouncementAlertType(String type) {
  return type == _announcementAlertType ||
      type == 'notice' ||
      type == 'announcement' ||
      type == 'push';
}

AlertHistoryItem tradingViewInstallAlertItem() {
  return AlertHistoryItem(
    message: 'Install TradingView',
    detail:
        'Install TradingView to open charts directly from this app.',
    link: _tradingViewInstallUrl,
    type: _tradingViewInstallAlertType,
    createdAt: DateTime(2026, 1, 1),
  );
}

List<AlertHistoryItem> sortAlertHistoryItems(
  Iterable<AlertHistoryItem> source, {
  int limit = 50,
}) {
  final announcements = <AlertHistoryItem>[];
  final others = <AlertHistoryItem>[];

  for (final item in source) {
    if (item.message.isEmpty) continue;

    if (item.type == _tradingViewInstallAlertType) {
      continue;
    } else if (isAnnouncementAlertType(item.type)) {
      if (announcements.isEmpty) {
        announcements.add(item);
      }
    } else {
      others.add(item);
    }
  }

  return [
    tradingViewInstallAlertItem(),
    ...announcements,
    ...others,
  ].take(limit).toList();
}

Future<bool> alertTypeEnabledFromPrefs(String type) async {
  final prefs = await SharedPreferences.getInstance();

  if (isAnnouncementAlertType(type)) {
    return prefs.getBool('announcementAlertEnabled') ?? true;
  }

  if (type == 'high') {
    return prefs.getBool('highAlertEnabled') ?? true;
  }

  if (type == 'marketOpen') {
    return prefs.getBool('marketOpenAlertEnabled') ?? true;
  }

  if (type == 'minus20' ||
      type == 'minus30' ||
      type == 'minus40' ||
      type == 'minus50' ||
      type == 'recovery20' ||
      type == 'recovery30' ||
      type == 'recovery40' ||
      type == 'recovery50') {
    return prefs.getBool('strategyAlertEnabled') ?? true;
  }

  if (type == 'nasdaq200Breakdown' ||
      type == 'nasdaq200Breakout' ||
      type == 'nasdaq200Recovery') {
    return prefs.getBool('nasdaq200AlertEnabled') ?? true;
  }

  if (type == 'portfolioCashHigh' || type == 'portfolioCashLow') {
    return prefs.getBool('portfolioCashAlertEnabled') ?? true;
  }

  if (type.startsWith('profitTarget')) {
    return prefs.getBool('profitTargetAlertEnabled') ?? true;
  }

  return true;
}

Uri? alertLinkUri(AlertHistoryItem item, String detail) {
  final candidates = [
    item.link,
    item.detail,
    item.message,
    detail,
  ];
  final linkPattern = RegExp(
    r'(https?://[^\s<>)\]]+|www\.[^\s<>)\]]+)',
    caseSensitive: false,
  );

  for (final source in candidates) {
    final raw = source.trim();
    final match = linkPattern.firstMatch(raw);
    final value = (match?.group(0) ?? raw)
        .trim()
        .replaceAll(RegExp(r'[.,，。!！?？)\]}]+$'), '');

    if (value.isEmpty) continue;

    final hasScheme = value.startsWith('http://') || value.startsWith('https://');
    final looksLikePlainDomain = !value.contains(RegExp(r'\s')) &&
        value.contains('.') &&
        !hasScheme;
    final normalized = value.startsWith('www.') || looksLikePlainDomain
        ? 'https://$value'
        : value;
    final uri = Uri.tryParse(normalized);

    if (uri != null &&
        uri.hasScheme &&
        (uri.scheme == 'http' || uri.scheme == 'https')) {
      return uri;
    }
  }

  return null;
}

Future<void> saveAlertHistoryItemToPrefs(AlertHistoryItem item) async {
  final prefs = await SharedPreferences.getInstance();
  final savedItems = prefs.getStringList('alertHistory') ?? [];
  final savedHistory = savedItems
      .map(AlertHistoryItem.fromJson)
      .where(
        (savedItem) => !isAnnouncementAlertType(item.type) ||
            !isAnnouncementAlertType(savedItem.type),
      );
  final nextItems = sortAlertHistoryItems([
    item,
    ...savedHistory,
  ]);
  final nextUnread = (prefs.getInt(_unreadAlertCountKey) ?? 0) + 1;

  await prefs.setStringList(
    'alertHistory',
    nextItems.map((item) => jsonEncode(item.toJson())).toList(),
  );
  await prefs.setInt(_unreadAlertCountKey, nextUnread);
}

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(
  RemoteMessage message,
) async {
  ui.DartPluginRegistrant.ensureInitialized();
  await Firebase.initializeApp();
  await initializeLocalNotifications();

  final item = await alertItemFromRemoteMessageLocalized(message);
  await saveAlertHistoryItemToPrefs(item);

  if (await alertTypeEnabledFromPrefs(item.type)) {
    await showLocalAlertNotification(
      item.message,
      detail: item.detail,
      link: item.link,
      type: item.type,
    );
  }
}

Future<void> initializeLocalNotifications() async {
  if (kIsWeb) return;

  const androidSettings = AndroidInitializationSettings(
    '@mipmap/ic_launcher',
  );
  const initSettings = InitializationSettings(
    android: androidSettings,
  );

  await _localNotifications.initialize(
    initSettings,
    onDidReceiveNotificationResponse: (response) {
      final payload = response.payload;
      if (payload == null || payload.isEmpty) return;

      try {
        final item = AlertHistoryItem.fromJson(payload);
        appNavigatorKey.currentState?.push(
          MaterialPageRoute(
            builder: (_) => AlertDetailPage(item: item),
          ),
        );
      } catch (_) {}
    },
  );

  final androidPlugin =
      _localNotifications.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  await androidPlugin?.createNotificationChannel(_qldAlertChannel);
  await androidPlugin?.requestNotificationsPermission();
}

Future<void> showPushNotification(RemoteMessage message) async {
  if (kIsWeb) return;

  final item = await alertItemFromRemoteMessageLocalized(message);

  if (!await alertTypeEnabledFromPrefs(item.type)) {
    return;
  }

  await _localNotifications.show(
    DateTime.now().millisecondsSinceEpoch.remainder(1 << 31),
    item.message,
    item.detail,
    NotificationDetails(
      android: AndroidNotificationDetails(
        _qldAlertChannel.id,
        _qldAlertChannel.name,
        channelDescription: _qldAlertChannel.description,
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
    ),
    payload: jsonEncode(item.toJson()),
  );
}

Future<void> showLocalAlertNotification(
  String message, {
  String detail = '',
  String link = '',
  String type = 'info',
}) async {
  if (kIsWeb) return;

  final payload = jsonEncode(
    AlertHistoryItem(
      message: message,
      detail: detail,
      link: link,
      type: type,
      createdAt: DateTime.now(),
    ).toJson(),
  );

  await _localNotifications.show(
    DateTime.now().millisecondsSinceEpoch.remainder(1 << 31),
    'QLD Alert',
    message,
    NotificationDetails(
      android: AndroidNotificationDetails(
        _qldAlertChannel.id,
        _qldAlertChannel.name,
        channelDescription: _qldAlertChannel.description,
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
    ),
    payload: payload,
  );
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (!kIsWeb) {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(
      firebaseMessagingBackgroundHandler,
    );
    await initializeLocalNotifications();
    await MobileAds.instance.initialize();
  }

  runApp(const QLDAlertApp());
}

class QLDAlertApp extends StatefulWidget {
  const QLDAlertApp({super.key});

  @override
  State<QLDAlertApp> createState() => _QLDAlertAppState();
}

class _QLDAlertAppState extends State<QLDAlertApp> {
  Locale _locale = const Locale('en');

  Locale _localeFromCode(String code) {
    final parts = code.split('_');

    if (parts.length >= 2) {
      return Locale(parts[0], parts[1]);
    }

    return Locale(code);
  }

  @override
  void initState() {
    super.initState();
    loadSavedLanguage();
  }

  Future<void> loadSavedLanguage() async {
    final prefs = await SharedPreferences.getInstance();

    final savedLanguage =
        prefs.getString('selectedLanguage') ?? 'en';

    if (!mounted) return;

    setState(() {
      _locale = _localeFromCode(savedLanguage);
    });
  }

  Future<void> changeLanguage(String code) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      'selectedLanguage',
      code,
    );
    unawaited(syncAlertLanguageTopic(code));

    if (!mounted) return;

    setState(() {
      _locale = _localeFromCode(code);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
  debugShowCheckedModeBanner: false,

  locale: _locale,

  onGenerateTitle: (context) =>
      AppLocalizations.of(context)!.appTitle,

  localizationsDelegates: const [
    AppLocalizations.delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ],

  supportedLocales: AppLocalizations.supportedLocales,

  builder: (context, child) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(
        textScaler: TextScaler.noScaling,
      ),
      child: child ?? const SizedBox.shrink(),
    );
  },

  theme: ThemeData.dark().copyWith(
    scaffoldBackgroundColor: const Color(0xFF0D1117),
  ),

  navigatorKey: appNavigatorKey,

  home: HomePage(
    onLanguageChanged: changeLanguage,
    ),
);
  }
}
class HomePage extends StatefulWidget {
  final Function(String) onLanguageChanged;

  const HomePage({
    super.key,
    required this.onLanguageChanged,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

enum _UsMarketSession { pre, regular, afterHours, closed }

class _UsMarketCalendar {
  const _UsMarketCalendar({
    required this.closedDates,
    required this.earlyCloseDates,
  });

  final Set<String> closedDates;
  final Set<String> earlyCloseDates;
}

class AlertHistoryItem {
  const AlertHistoryItem({
    required this.message,
    this.detail = '',
    this.link = '',
    required this.type,
    required this.createdAt,
  });

  final String message;
  final String detail;
  final String link;
  final String type;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'message': message,
        'detail': detail,
        'link': link,
        'type': type,
        'createdAt': createdAt.toIso8601String(),
      };

  static AlertHistoryItem fromJson(String source) {
    final data = jsonDecode(source) as Map<String, dynamic>;

    return AlertHistoryItem(
      message: data['message'] as String? ?? '',
      detail: data['detail'] as String? ?? '',
      link: data['link'] as String? ?? '',
      type: data['type'] as String? ?? 'info',
      createdAt: DateTime.tryParse(data['createdAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }
}

class AppUpdateInfo {
  const AppUpdateInfo({
    required this.latestVersionCode,
    required this.title,
    required this.message,
    required this.updateUrl,
    this.forceUpdate = false,
  });

  final int latestVersionCode;
  final String title;
  final String message;
  final String updateUrl;
  final bool forceUpdate;
}

class LatestAnnouncementInfo {
  const LatestAnnouncementInfo({
    required this.id,
    required this.item,
  });

  final String id;
  final AlertHistoryItem item;
}

Future<AppUpdateInfo?> fetchAppUpdateInfo() async {
  try {
    final response = await http
        .get(Uri.parse(_appConfigUrl))
        .timeout(const Duration(seconds: 5));

    if (response.statusCode != 200) return null;

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final latestVersionCode = int.tryParse(
          '${data['latestVersionCode'] ?? data['androidVersionCode'] ?? ''}',
        ) ??
        0;

    if (latestVersionCode <= _currentAppVersionCode) return null;

    final languageCode = await savedLanguageCode();
    final fallbackTitle = data['title']?.toString() ?? '';
    final fallbackMessage = data['message']?.toString() ?? '';
    final updateUrl = data['updateUrl']?.toString().trim();

    return AppUpdateInfo(
      latestVersionCode: latestVersionCode,
      title: localizedRemoteValue(
        data,
        'title',
        languageCode,
        fallbackTitle,
      ),
      message: localizedRemoteValue(
        data,
        'message',
        languageCode,
        fallbackMessage,
      ),
      updateUrl: updateUrl == null || updateUrl.isEmpty
          ? 'market://details?id=$_androidPackageName'
          : updateUrl,
      forceUpdate: data['forceUpdate'] == true ||
          data['forceUpdate']?.toString().toLowerCase() == 'true',
    );
  } catch (_) {
    return null;
  }
}

Future<LatestAnnouncementInfo?> fetchLatestAnnouncementInfo() async {
  try {
    final response = await http
        .get(Uri.parse(_appConfigUrl))
        .timeout(const Duration(seconds: 5));

    if (response.statusCode != 200) return null;

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final rawAnnouncement = data['announcement'] ??
        data['latestAnnouncement'] ??
        data['notice'] ??
        data['latestNotice'];
    final hasTopLevelAnnouncementFields =
        data.containsKey('announcementTitle') ||
        data.containsKey('announcementMessage') ||
        data.containsKey('noticeTitle') ||
        data.containsKey('noticeMessage');

    if (rawAnnouncement == null && !hasTopLevelAnnouncementFields) {
      return null;
    }

    final source = rawAnnouncement is Map
        ? Map<String, dynamic>.from(rawAnnouncement)
        : data;
    final enabledValue =
        source['enabled'] ?? source['announcementEnabled'] ?? source['noticeEnabled'];

    if (enabledValue == false ||
        enabledValue?.toString().toLowerCase() == 'false') {
      return null;
    }

    final languageCode = await savedLanguageCode();
    final fallbackTitle = source['title']?.toString() ??
        source['noticeTitle']?.toString() ??
        source['announcementTitle']?.toString() ??
        '';
    final fallbackDetail = source['detail']?.toString() ??
        source['body']?.toString() ??
        source['content']?.toString() ??
        source['message']?.toString() ??
        source['noticeMessage']?.toString() ??
        source['announcementMessage']?.toString() ??
        '';
    final title = [
      localizedRemoteValue(source, 'title', languageCode, ''),
      localizedRemoteValue(source, 'announcementTitle', languageCode, ''),
      localizedRemoteValue(source, 'noticeTitle', languageCode, ''),
      fallbackTitle,
    ].map((value) => value.trim()).firstWhere(
          (value) => value.isNotEmpty,
          orElse: () => '',
        );
    final detail = [
      localizedRemoteValue(source, 'message', languageCode, ''),
      localizedRemoteValue(source, 'detail', languageCode, ''),
      localizedRemoteValue(source, 'body', languageCode, ''),
      localizedRemoteValue(source, 'content', languageCode, ''),
      localizedRemoteValue(source, 'announcementMessage', languageCode, ''),
      localizedRemoteValue(source, 'noticeMessage', languageCode, ''),
      fallbackDetail,
    ].map((value) => value.trim()).firstWhere(
          (value) => value.isNotEmpty,
          orElse: () => '',
        );
    final link = (source['link'] ??
            source['url'] ??
            source['noticeUrl'] ??
            source['announcementUrl'] ??
            '')
        .toString()
        .trim();
    final message = title.isNotEmpty ? title : detail;

    if (message.isEmpty) return null;

    final rawId = (source['id'] ??
            source['noticeId'] ??
            source['announcementId'] ??
            source['version'] ??
            source['updatedAt'] ??
            '')
        .toString()
        .trim();
    final id = rawId.isNotEmpty
        ? rawId
        : base64Url.encode(utf8.encode('$message|$detail|$link'));

    return LatestAnnouncementInfo(
      id: id,
      item: AlertHistoryItem(
        message: message,
        detail: detail,
        link: link,
        type: _announcementAlertType,
        createdAt: DateTime.now(),
      ),
    );
  } catch (_) {
    return null;
  }
}

class FearGreedData {
  const FearGreedData({
    required this.score,
    required this.rating,
    this.updatedAt,
  });

  final double score;
  final String rating;
  final DateTime? updatedAt;
}

const _fearGreedCacheKey = 'fearGreedDataCache';

Future<void> saveCachedFearGreedData(FearGreedData data) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString(
    _fearGreedCacheKey,
    jsonEncode({
      'score': data.score,
      'rating': data.rating,
      'updatedAt': data.updatedAt?.toIso8601String(),
    }),
  );
}

Future<FearGreedData?> loadCachedFearGreedData() async {
  final prefs = await SharedPreferences.getInstance();
  final source = prefs.getString(_fearGreedCacheKey);
  if (source == null || source.isEmpty) return null;

  try {
    final data = jsonDecode(source) as Map<String, dynamic>;
    final score = double.tryParse('${data['score']}');
    if (score == null) return null;

    return FearGreedData(
      score: score,
      rating: '${data['rating'] ?? fearGreedRatingForScore(score)}',
      updatedAt: DateTime.tryParse('${data['updatedAt'] ?? ''}'),
    );
  } catch (_) {
    return null;
  }
}

const _fearGreedZoneBounds = [0.0, 25.0, 45.0, 55.0, 75.0, 100.0];

int fearGreedSegmentForScore(double score) {
  if (score <= 25) return 0;
  if (score <= 45) return 1;
  if (score <= 55) return 2;
  if (score <= 75) return 3;
  return 4;
}

String fearGreedRatingForScore(double score) {
  if (score <= 25) return 'Extreme Fear';
  if (score <= 45) return 'Fear';
  if (score <= 55) return 'Neutral';
  if (score <= 75) return 'Greed';
  return 'Extreme Greed';
}

double? findFearGreedScore(dynamic value) {
  if (value is Map) {
    if (value.containsKey('score')) {
      return double.tryParse('${value['score']}');
    }

    for (final child in value.values) {
      final found = findFearGreedScore(child);
      if (found != null) return found;
    }
  }

  if (value is List) {
    for (final child in value) {
      final found = findFearGreedScore(child);
      if (found != null) return found;
    }
  }

  return null;
}

FearGreedData parseFearGreedData(Map<String, dynamic> json) {
  final now = json['fear_and_greed'];

  if (now is Map<String, dynamic>) {
    final score = double.tryParse('${now['score']}') ?? 0;
    final rating = '${now['rating'] ?? fearGreedRatingForScore(score)}';
    final timestamp = int.tryParse('${now['timestamp'] ?? ''}');

    return FearGreedData(
      score: score,
      rating: rating,
      updatedAt: timestamp == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(
              timestamp < 10000000000 ? timestamp * 1000 : timestamp,
            ),
    );
  }

  final score = findFearGreedScore(json) ?? 0;

  return FearGreedData(
    score: score,
    rating: fearGreedRatingForScore(score),
  );
}

List<String> splitCsvLine(String line) {
  final cells = <String>[];
  final buffer = StringBuffer();
  var inQuotes = false;

  for (var i = 0; i < line.length; i++) {
    final char = line[i];

    if (char == '"') {
      final isEscapedQuote =
          inQuotes && i + 1 < line.length && line[i + 1] == '"';
      if (isEscapedQuote) {
        buffer.write('"');
        i++;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char == ',' && !inQuotes) {
      cells.add(buffer.toString().trim());
      buffer.clear();
      continue;
    }

    buffer.write(char);
  }

  cells.add(buffer.toString().trim());
  return cells;
}

FearGreedData parseFearGreedCsv(String source) {
  final lines = const LineSplitter()
      .convert(source)
      .map((line) => line.trim())
      .where((line) => line.isNotEmpty)
      .toList();

  if (lines.length < 2) {
    throw const FormatException('Fear & Greed CSV is empty');
  }

  final headers = splitCsvLine(lines.first)
      .map((cell) => cell.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
      .toList();
  final dateIndex = headers.indexWhere((header) => header == 'date');
  final scoreIndex = headers.indexWhere(
    (header) =>
        header == 'score' ||
        header == 'feargreed' ||
        header == 'fearandgreed' ||
        header == 'feargreedscore',
  );
  final ratingIndex = headers.indexWhere(
    (header) => header == 'rating' || header == 'classification',
  );

  if (scoreIndex < 0) {
    throw const FormatException('Fear & Greed score column not found');
  }

  for (final line in lines.skip(1).toList().reversed) {
    final cells = splitCsvLine(line);
    if (scoreIndex >= cells.length) continue;

    final score = double.tryParse(cells[scoreIndex]);
    if (score == null) continue;

    final rating = ratingIndex >= 0 && ratingIndex < cells.length
        ? cells[ratingIndex]
        : '';
    final date = dateIndex >= 0 && dateIndex < cells.length
        ? DateTime.tryParse(cells[dateIndex])
        : null;

    return FearGreedData(
      score: score,
      rating: rating.isEmpty ? fearGreedRatingForScore(score) : rating,
      updatedAt: date,
    );
  }

  throw const FormatException('Fear & Greed CSV has no score');
}

Color fearGreedColorForScore(double score) {
  if (score <= 25) return Colors.redAccent;
  if (score <= 45) return Colors.orangeAccent;
  if (score < 55) return Colors.amberAccent;
  if (score < 75) return Colors.lightGreenAccent;
  return _cyan;
}

Future<FearGreedData> fetchFearGreedData() async {
  final now = DateTime.now().toUtc();
  final today = DateFormat('yyyy-MM-dd').format(now);
  final yesterday = DateFormat('yyyy-MM-dd').format(
    now.subtract(const Duration(days: 1)),
  );
  final uris = [
    Uri.parse(
      'https://production.dataviz.cnn.io/index/fearandgreed/graphdata',
    ),
    Uri.parse(
      'https://production.dataviz.cnn.io/index/fearandgreed/graphdata/$today',
    ),
    Uri.parse(
      'https://production.dataviz.cnn.io/index/fearandgreed/graphdata/$yesterday',
    ),
  ];
  const headers = {
    'Accept': 'application/json,text/plain,*/*',
    'Accept-Language': 'en-US,en;q=0.9',
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Origin': 'https://www.cnn.com',
    'Referer': 'https://www.cnn.com/markets/fear-and-greed',
  };

  Object? lastError;

  for (final uri in uris) {
    try {
      final response = await http
          .get(
            uri,
            headers: headers,
          )
          .timeout(
            const Duration(seconds: 8),
          );

      if (response.statusCode != 200 || response.body.trim().isEmpty) {
        lastError = 'CNN returned ${response.statusCode}';
        continue;
      }

      return parseFearGreedData(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
    } catch (error) {
      lastError = error;
    }
  }

  try {
    final response = await http
        .get(
          Uri.parse(
            'https://raw.githubusercontent.com/whit3rabbit/fear-greed-data/main/fear-greed.csv',
          ),
          headers: const {
            'Accept': 'text/csv,text/plain,*/*',
            'User-Agent': 'Mozilla/5.0 QLDDipAlert/1.0',
          },
        )
        .timeout(
          const Duration(seconds: 8),
        );

    if (response.statusCode == 200 && response.body.trim().isNotEmpty) {
      return parseFearGreedCsv(response.body);
    }

    lastError = 'GitHub returned ${response.statusCode}';
  } catch (error) {
    lastError = error;
  }

  throw Exception('CNN Fear & Greed unavailable: $lastError');
}

const _appBg = Color(0xFF04111F);
const _cardBg = Color(0xE6111D2C);
const _cardLine = Color(0xFF26384D);
const _cyan = Color(0xFF34DDB8);
const _blue = Color(0xFF48A8FF);
const _purple = Color(0xFF7650F4);
ScrollController? _activeHomeScrollController;

enum NavTab {
  chart,
  exchange,
  fearGreed,
  alert,
  strategy,
}

const _unreadAlertCountKey = 'unreadAlertCount';
final ValueNotifier<int> alertBadgeCount = ValueNotifier<int>(0);

Future<void> loadAlertBadgeCount() async {
  final prefs = await SharedPreferences.getInstance();
  alertBadgeCount.value = prefs.getInt(_unreadAlertCountKey) ?? 0;
}

Future<void> incrementAlertBadgeCount() async {
  final prefs = await SharedPreferences.getInstance();
  final nextCount = (prefs.getInt(_unreadAlertCountKey) ?? 0) + 1;

  await prefs.setInt(_unreadAlertCountKey, nextCount);
  alertBadgeCount.value = nextCount;
}

Future<void> clearAlertBadgeCount() async {
  final prefs = await SharedPreferences.getInstance();

  await prefs.setInt(_unreadAlertCountKey, 0);
  alertBadgeCount.value = 0;
}

Widget buildLanguageMenuButton(
  BuildContext context, {
  double iconSize = 22,
}) {
  return PopupMenuButton<String>(
    padding: EdgeInsets.zero,
    icon: Icon(
      Icons.language,
      color: Colors.white,
      size: iconSize,
    ),
    onSelected: (value) {
      context
          .findAncestorStateOfType<_QLDAlertAppState>()
          ?.changeLanguage(value);
    },
    itemBuilder: (context) => const [
      PopupMenuItem(
        value: 'en',
        child: Text('English'),
      ),
      PopupMenuItem(
        value: 'ko',
        child: Text('한국어'),
      ),
      PopupMenuItem(
        value: 'ja',
        child: Text('日本語'),
      ),
      PopupMenuItem(
        value: 'es',
        child: Text('Español'),
      ),
      PopupMenuItem(
        value: 'pt',
        child: Text('Português'),
      ),
      PopupMenuItem(
        value: 'ru',
        child: Text('Русский'),
      ),
      PopupMenuItem(
        value: 'zh',
        child: Text('简体中文'),
      ),
      PopupMenuItem(
        value: 'zh_TW',
        child: Text('繁體中文'),
      ),
      PopupMenuItem(
        value: 'fr',
        child: Text('Français'),
      ),
      PopupMenuItem(
        value: 'de',
        child: Text('Deutsch'),
      ),
    ],
  );
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  double qldPrice = 0;
  double tqqqPrice = 0;
  double basePrice = 0;
  double allTimeHigh = 0;
  String lastHighAlertDate = '';
  String fcmToken = '';

  double qldShares = 0;
  double tqqqShares = 0;
  double cashAmount = 0;
  double qldAveragePrice = 0;
  double tqqqAveragePrice = 0;

  final qldController = TextEditingController();
  final tqqqController = TextEditingController();
  final cashController = TextEditingController();
  final qldAverageController = TextEditingController();
  final tqqqAverageController = TextEditingController();
  final homeScrollController = ScrollController();

  bool showPortfolioInput = false;

  String latestDate = '';
  String highDate = '';

  bool isLoading = true;
  bool isRefreshingPrice = false;
  bool isUsingCachedPrice = false;

  bool isPreMarket = false;
  bool isRegularMarket = false;
  bool isPriceUp = true;
  List<AlertHistoryItem> alertHistory = [];
  List<QldMiniCandle> qldMiniCandles = [];
  FearGreedData? homeFearGreedData;

  late AnimationController _blinkController;
  late Animation<double> _blinkAnimation;

  Timer? priceTimer;
  Timer? yahooHistoryTimer;
  Timer? nasdaq200Timer;
  DateTime? lastHighDateRefreshAt;
  final Map<int, _UsMarketCalendar> _usMarketCalendarCache = {};

  bool _isNewYorkDst(DateTime utcNow) {
    final year = utcNow.year;
    final dstStartDay = _nthWeekdayOfMonthUtc(
      year,
      3,
      DateTime.sunday,
      2,
    );
    final dstEndDay = _nthWeekdayOfMonthUtc(
      year,
      11,
      DateTime.sunday,
      1,
    );

    final dstStartUtc = DateTime.utc(year, 3, dstStartDay, 7);
    final dstEndUtc = DateTime.utc(year, 11, dstEndDay, 6);

    return !utcNow.isBefore(dstStartUtc) && utcNow.isBefore(dstEndUtc);
  }

  int _newYorkUtcOffsetHours(DateTime utcNow) =>
      _isNewYorkDst(utcNow) ? -4 : -5;

  DateTime _toNewYorkTime(DateTime utcNow) =>
      utcNow.add(Duration(hours: _newYorkUtcOffsetHours(utcNow)));

  int _nthWeekdayOfMonthUtc(
    int year,
    int month,
    int weekday,
    int n,
  ) {
    final first = DateTime.utc(year, month, 1);
    final delta = (weekday - first.weekday + 7) % 7;
    return 1 + delta + (n - 1) * 7;
  }

  _UsMarketSession _usMarketSessionFromUtc(DateTime utcNow) {
    final ny = _toNewYorkTime(utcNow);
    final nyDate = ny.toString().substring(0, 10);

    final isWeekday = ny.weekday >= DateTime.monday &&
        ny.weekday <= DateTime.friday;
    if (!isWeekday || _isUsMarketClosedDate(nyDate)) {
      return _UsMarketSession.closed;
    }

    final minutes = ny.hour * 60 + ny.minute;

    const preStart = 4 * 60;
    const regularStart = 9 * 60 + 30;
    final regularEnd = _usMarketCloseMinute(ny);
    const afterHoursEnd = 20 * 60;

    if (minutes >= preStart && minutes < regularStart) {
      return _UsMarketSession.pre;
    }

    if (minutes >= regularStart && minutes < regularEnd) {
      return _UsMarketSession.regular;
    }

    if (minutes >= regularEnd && minutes < afterHoursEnd) {
      return _UsMarketSession.afterHours;
    }

    return _UsMarketSession.closed;
  }

  bool _isUsMarketClosedDate(String nyDate) {
    final year = int.tryParse(nyDate.substring(0, 4));
    if (year == null) return false;

    return _usMarketCalendar(year).closedDates.contains(nyDate);
  }

  int _usMarketCloseMinute(DateTime ny) {
    final nyDate = ny.toString().substring(0, 10);
    return _usMarketCalendar(ny.year).earlyCloseDates.contains(nyDate)
        ? 13 * 60
        : 16 * 60;
  }

  _UsMarketCalendar _usMarketCalendar(int year) {
    final cached = _usMarketCalendarCache[year];
    if (cached != null) return cached;

    final closedDates = <String>{};
    final earlyCloseDates = <String>{};

    _addObservedFixedHoliday(
      closedDates,
      year,
      1,
      1,
      skipSaturdayObserved: true,
    );
    closedDates.add(
      _dateString(year, 1, _nthWeekdayOfMonthUtc(year, 1, DateTime.monday, 3)),
    );
    closedDates.add(
      _dateString(year, 2, _nthWeekdayOfMonthUtc(year, 2, DateTime.monday, 3)),
    );

    final easter = _easterSunday(year);
    final goodFriday = easter.subtract(const Duration(days: 2));
    closedDates.add(
      _dateString(goodFriday.year, goodFriday.month, goodFriday.day),
    );

    closedDates.add(
      _dateString(
        year,
        5,
        _lastWeekdayOfMonthUtc(year, 5, DateTime.monday),
      ),
    );
    _addObservedFixedHoliday(closedDates, year, 6, 19);
    _addObservedFixedHoliday(closedDates, year, 7, 4);
    closedDates.add(
      _dateString(year, 9, _nthWeekdayOfMonthUtc(year, 9, DateTime.monday, 1)),
    );
    closedDates.add(
      _dateString(
        year,
        11,
        _nthWeekdayOfMonthUtc(year, 11, DateTime.thursday, 4),
      ),
    );
    _addObservedFixedHoliday(closedDates, year, 12, 25);

    final thanksgivingDay =
        _nthWeekdayOfMonthUtc(year, 11, DateTime.thursday, 4);
    final dayAfterThanksgiving =
        DateTime.utc(year, 11, thanksgivingDay).add(const Duration(days: 1));
    earlyCloseDates.add(
      _dateString(
        dayAfterThanksgiving.year,
        dayAfterThanksgiving.month,
        dayAfterThanksgiving.day,
      ),
    );

    earlyCloseDates.add(_previousTradingDate(year, 7, 4, closedDates));

    final christmasEve = DateTime.utc(year, 12, 24);
    final christmasEveString =
        _dateString(christmasEve.year, christmasEve.month, christmasEve.day);
    if (christmasEve.weekday >= DateTime.monday &&
        christmasEve.weekday <= DateTime.friday &&
        !closedDates.contains(christmasEveString)) {
      earlyCloseDates.add(christmasEveString);
    }

    final calendar = _UsMarketCalendar(
      closedDates: closedDates,
      earlyCloseDates: earlyCloseDates,
    );
    _usMarketCalendarCache[year] = calendar;
    return calendar;
  }

  String _dateString(int year, int month, int day) =>
      "$year-${month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}";

  int _lastWeekdayOfMonthUtc(int year, int month, int weekday) {
    final last = DateTime.utc(year, month + 1, 0);
    final delta = (last.weekday - weekday + 7) % 7;
    return last.day - delta;
  }

  DateTime _easterSunday(int year) {
    final a = year % 19;
    final b = year ~/ 100;
    final c = year % 100;
    final d = b ~/ 4;
    final e = b % 4;
    final f = (b + 8) ~/ 25;
    final g = (b - f + 1) ~/ 3;
    final h = (19 * a + b - d - g + 15) % 30;
    final i = c ~/ 4;
    final k = c % 4;
    final l = (32 + 2 * e + 2 * i - h - k) % 7;
    final m = (a + 11 * h + 22 * l) ~/ 451;
    final month = (h + l - 7 * m + 114) ~/ 31;
    final day = ((h + l - 7 * m + 114) % 31) + 1;

    return DateTime.utc(year, month, day);
  }

  void _addObservedFixedHoliday(
    Set<String> dates,
    int year,
    int month,
    int day, {
    bool skipSaturdayObserved = false,
  }) {
    final date = DateTime.utc(year, month, day);

    if (date.weekday == DateTime.sunday) {
      final observed = date.add(const Duration(days: 1));
      dates.add(_dateString(observed.year, observed.month, observed.day));
      return;
    }

    if (date.weekday == DateTime.saturday) {
      if (skipSaturdayObserved) return;

      final observed = date.subtract(const Duration(days: 1));
      dates.add(_dateString(observed.year, observed.month, observed.day));
      return;
    }

    dates.add(_dateString(year, month, day));
  }

  String _previousTradingDate(
    int year,
    int month,
    int day,
    Set<String> closedDates,
  ) {
    var current =
        DateTime.utc(year, month, day).subtract(const Duration(days: 1));

    while (current.weekday == DateTime.saturday ||
        current.weekday == DateTime.sunday ||
        closedDates.contains(
          _dateString(current.year, current.month, current.day),
        )) {
      current = current.subtract(const Duration(days: 1));
    }

    return _dateString(current.year, current.month, current.day);
  }

  bool touchedMinus20 = false;
  bool touchedMinus30 = false;
  bool touchedMinus40 = false;
  bool touchedMinus50 = false;
  int activeDropZone = 0;
  bool dropAlertInitialized = false;
  String lastMarketOpenAlertDate = '';
  bool marketOpenAlertInitialized = false;
  bool highAlertEnabled = true;
  bool marketOpenAlertEnabled = true;
  bool strategyAlertEnabled = true;
  bool nasdaq200AlertEnabled = true;
  bool portfolioCashAlertEnabled = true;
  bool profitTargetAlertEnabled = true;
  bool announcementAlertEnabled = true;
  int nasdaq200State = 0;
  int portfolioCashState = 0;
  int qldProfitTargetState = 0;
  int tqqqProfitTargetState = 0;
  bool updateDialogShown = false;

  @override
  void initState() {
  super.initState();
  _activeHomeScrollController = homeScrollController;

  if (!kIsWeb) {
    FirebaseMessaging.instance.setAutoInitEnabled(true);
    FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    savedLanguageCode().then(syncAlertLanguageTopic);

    FirebaseMessaging.instance.getToken().then((token) {
      setState(() {
        fcmToken = token ?? '';
      });

      debugPrint('FCM TOKEN: $token');
    });

    FirebaseMessaging.onMessage.listen((message) async {
      final item = await alertItemFromRemoteMessageLocalized(message);
      showAndSaveRemoteAlert(item);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) async {
      final item = await alertItemFromRemoteMessageLocalized(message);
      unawaited(
        addAlertHistory(
          item.message,
          item.type,
          detail: item.detail,
          link: item.link,
        ),
      );
      appNavigatorKey.currentState?.push(
        MaterialPageRoute(
          builder: (_) => AlertDetailPage(item: item),
        ),
      );
    });

    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message == null) return;

      alertItemFromRemoteMessageLocalized(message).then((item) {
        unawaited(
          addAlertHistory(
            item.message,
            item.type,
            detail: item.detail,
            link: item.link,
          ),
        );
        appNavigatorKey.currentState?.push(
          MaterialPageRoute(
            builder: (_) => AlertDetailPage(item: item),
          ),
        );
      });
    });
  }

  _blinkController = AnimationController(
  
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _blinkAnimation = Tween<double>(
      begin: 0.4,
      end: 1.0,
    ).animate(_blinkController);

    loadPortfolio();
    loadAlertHistory();
    loadAlertBadgeCount();
    loadLastHighAlertDate();
    loadLastMarketOpenAlertDate();
    loadStoredAllTimeHigh();
    loadAlertSettings();
    loadCachedPrices();
    fetchHomeFearGreed();
    _fetchLatestAnnouncement();

    fetchCurrentPrices();
    fetchQldHistoricalReference();
    evaluateNasdaq200DayAlert();

    priceTimer = Timer.periodic(
      const Duration(seconds: 15),
      (timer) {
        fetchCurrentPrices();
      },
    );
    yahooHistoryTimer = Timer.periodic(
      const Duration(hours: 1),
      (timer) {
        fetchQldHistoricalReference();
      },
    );
    nasdaq200Timer = Timer.periodic(
      const Duration(hours: 1),
      (timer) {
        evaluateNasdaq200DayAlert();
      },
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkForAppUpdate();
    });
  }

  Future<void> checkForAppUpdate() async {
    if (updateDialogShown || !mounted) return;

    final info = await fetchAppUpdateInfo();
    if (info == null || !mounted || updateDialogShown) return;

    updateDialogShown = true;
    final l10n = AppLocalizations.of(context)!;
    final updateUri = Uri.tryParse(info.updateUrl);

    showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF151B24),
          title: Text(
            info.title.isEmpty ? l10n.appUpdateTitle : info.title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            info.message.isEmpty ? l10n.appUpdateMessage : info.message,
            style: const TextStyle(
              color: Colors.white70,
              height: 1.45,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(l10n.appUpdateLater),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _blue,
                foregroundColor: Colors.white,
              ),
              onPressed: updateUri == null
                  ? null
                  : () {
                      launchUrl(
                        updateUri!,
                        mode: LaunchMode.externalApplication,
                      );
                    },
              child: Text(l10n.appUpdateNow),
            ),
          ],
        );
      },
    );
  }

  Future<void> loadPortfolio() async {
    final prefs = await SharedPreferences.getInstance();

    qldShares = prefs.getDouble('qldShares') ?? 0;
    tqqqShares = prefs.getDouble('tqqqShares') ?? 0;
    cashAmount = prefs.getDouble('cashAmount') ?? 0;
    qldAveragePrice = prefs.getDouble('qldAveragePrice') ?? 0;
    tqqqAveragePrice = prefs.getDouble('tqqqAveragePrice') ?? 0;

    qldController.text = qldShares.toStringAsFixed(0);
    tqqqController.text = tqqqShares.toStringAsFixed(0);
    cashController.text = cashAmount.toStringAsFixed(0);
    qldAverageController.text =
        qldAveragePrice > 0 ? qldAveragePrice.toStringAsFixed(2) : '';
    tqqqAverageController.text =
        tqqqAveragePrice > 0 ? tqqqAveragePrice.toStringAsFixed(2) : '';

    setState(() {});
  }

  Future<void> savePortfolio() async {
    final prefs = await SharedPreferences.getInstance();

    final previousQldAveragePrice = qldAveragePrice;
    final previousTqqqAveragePrice = tqqqAveragePrice;

    qldShares = double.tryParse(qldController.text) ?? 0;

    tqqqShares = double.tryParse(tqqqController.text) ?? 0;

    cashAmount = double.tryParse(cashController.text) ?? 0;
    qldAveragePrice = double.tryParse(qldAverageController.text) ?? 0;
    tqqqAveragePrice = double.tryParse(tqqqAverageController.text) ?? 0;
    final averagePriceChanged =
        previousQldAveragePrice != qldAveragePrice ||
        previousTqqqAveragePrice != tqqqAveragePrice;

    await prefs.setDouble(
      'qldShares',
      qldShares,
    );

    await prefs.setDouble(
      'tqqqShares',
      tqqqShares,
    );

    await prefs.setDouble(
      'cashAmount',
      cashAmount,
    );
    await prefs.setDouble(
      'qldAveragePrice',
      qldAveragePrice,
    );
    await prefs.setDouble(
      'tqqqAveragePrice',
      tqqqAveragePrice,
    );
    await prefs.setBool('portfolioCashAlertInitialized', false);
    if (averagePriceChanged) {
      await prefs.setBool('profitTargetAlertInitialized', false);
    }

    setState(() {});
    await evaluatePortfolioCashAlert();
    await evaluateProfitTargetAlert();
  }

  Future<void> loadAlertHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final savedItems = prefs.getStringList('alertHistory') ?? [];

    alertHistory = sortAlertHistoryItems(
      savedItems.map(AlertHistoryItem.fromJson),
    );

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> loadLastHighAlertDate() async {
    final prefs = await SharedPreferences.getInstance();
    final savedDate = prefs.getString('lastHighAlertDate') ?? '';

    if (!mounted) return;

    setState(() {
      lastHighAlertDate = savedDate;
    });
  }

  Future<void> loadLastMarketOpenAlertDate() async {
    final prefs = await SharedPreferences.getInstance();
    final savedDate = prefs.getString('lastMarketOpenAlertDate') ?? '';
    final initialized =
        prefs.getBool('marketOpenAlertInitialized') ?? false;

    if (!mounted) return;

    setState(() {
      lastMarketOpenAlertDate = savedDate;
      marketOpenAlertInitialized = initialized;
    });
  }

  Future<void> loadStoredAllTimeHigh() async {
    final prefs = await SharedPreferences.getInstance();
    final savedHigh = prefs.getDouble('storedAllTimeHigh') ?? 0;

    if (!mounted || savedHigh <= 0) return;

    setState(() {
      allTimeHigh = savedHigh;
    });
  }

  Future<void> loadCachedPrices() async {
    final prefs = await SharedPreferences.getInstance();
    final cachedQldPrice = prefs.getDouble('lastQldPrice') ?? 0;
    final cachedTqqqPrice = prefs.getDouble('lastTqqqPrice') ?? 0;
    final cachedIsPriceUp = prefs.getBool('lastIsPriceUp') ?? isPriceUp;
    final cachedDate = prefs.getString('lastPriceDate') ?? '';

    if (!mounted || (cachedQldPrice <= 0 && cachedTqqqPrice <= 0)) return;

    setState(() {
      if (cachedQldPrice > 0) qldPrice = cachedQldPrice;
      if (cachedTqqqPrice > 0) tqqqPrice = cachedTqqqPrice;
      isPriceUp = cachedIsPriceUp;
      if (cachedDate.isNotEmpty) latestDate = cachedDate;
      isLoading = false;
      isRefreshingPrice = true;
      isUsingCachedPrice = true;
    });
  }

  Future<void> saveCachedPrices({
    required double qld,
    required double tqqq,
    required bool priceUp,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final nowDate = DateTime.now().toString().substring(0, 10);

    if (qld > 0) {
      await prefs.setDouble('lastQldPrice', qld);
    }
    if (tqqq > 0) {
      await prefs.setDouble('lastTqqqPrice', tqqq);
    }
    await prefs.setBool('lastIsPriceUp', priceUp);
    await prefs.setString('lastPriceDate', nowDate);
  }

  Future<void> loadAlertSettings() async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    setState(() {
      highAlertEnabled = prefs.getBool('highAlertEnabled') ?? true;
      marketOpenAlertEnabled =
          prefs.getBool('marketOpenAlertEnabled') ?? true;
      strategyAlertEnabled =
          prefs.getBool('strategyAlertEnabled') ?? true;
      nasdaq200AlertEnabled =
          prefs.getBool('nasdaq200AlertEnabled') ?? true;
      portfolioCashAlertEnabled =
          prefs.getBool('portfolioCashAlertEnabled') ?? true;
      profitTargetAlertEnabled =
          prefs.getBool('profitTargetAlertEnabled') ?? true;
      announcementAlertEnabled =
          prefs.getBool('announcementAlertEnabled') ?? true;
      nasdaq200State = prefs.getInt('nasdaq200State') ?? 0;
      portfolioCashState = prefs.getInt('portfolioCashState') ?? 0;
      qldProfitTargetState =
          prefs.getInt('qldProfitTargetState') ?? 0;
      tqqqProfitTargetState =
          prefs.getInt('tqqqProfitTargetState') ?? 0;
    });
  }

  Future<void> fetchHomeFearGreed() async {
    try {
      final nextData = await fetchFearGreedData();
      await saveCachedFearGreedData(nextData);

      if (!mounted) return;

      setState(() {
        homeFearGreedData = nextData;
      });
    } catch (_) {
      final cachedData = await loadCachedFearGreedData();
      if (!mounted) return;

      setState(() {
        homeFearGreedData = cachedData;
      });
    }
  }

  Future<void> saveAlertSetting(
    String key,
    bool value,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  Future<void> addAlertHistory(
    String message,
    String type, {
    String detail = '',
    String link = '',
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final nextItems = sortAlertHistoryItems([
      AlertHistoryItem(
        message: message,
        detail: detail,
        link: link,
        type: type,
        createdAt: DateTime.now(),
      ),
      ...alertHistory.where(
        (item) => !isAnnouncementAlertType(type) ||
            !isAnnouncementAlertType(item.type),
      ),
    ]);

    await prefs.setStringList(
      'alertHistory',
      nextItems.map((item) => jsonEncode(item.toJson())).toList(),
    );

    if (!mounted) return;

    setState(() {
      alertHistory = nextItems;
    });

    await incrementAlertBadgeCount();
  }

  Future<void> _fetchLatestAnnouncement() async {
    final info = await fetchLatestAnnouncementInfo();
    if (info == null) return;

    final prefs = await SharedPreferences.getInstance();
    final savedId = prefs.getString('latestAnnouncementId') ?? '';

    if (savedId == info.id) return;

    final savedItems = prefs.getStringList('alertHistory') ?? [];
    final filteredItems = savedItems.where((source) {
      try {
        return !isAnnouncementAlertType(
          AlertHistoryItem.fromJson(source).type,
        );
      } catch (_) {
        return true;
      }
    }).toList();
    final nextItems = [
      jsonEncode(info.item.toJson()),
      ...filteredItems,
    ].take(50).toList();

    await prefs.setStringList('alertHistory', nextItems);
    await prefs.setString('latestAnnouncementId', info.id);

    if (!mounted) return;

    setState(() {
      alertHistory = sortAlertHistoryItems([
        info.item,
        ...alertHistory.where(
          (item) => !isAnnouncementAlertType(item.type),
        ),
      ]);
    });

    await incrementAlertBadgeCount();
  }

  void showAndSaveRemoteAlert(AlertHistoryItem item) {
    if (!isAlertTypeEnabled(item.type)) {
      unawaited(
        addAlertHistory(
          item.message,
          item.type,
          detail: item.detail,
          link: item.link,
        ),
      );
      return;
    }

    showAndSaveAlert(
      item.message,
      isAnnouncementAlertType(item.type) ? Colors.amberAccent : _cyan,
      item.type,
      detail: item.detail,
      link: item.link,
    );
  }

  bool isAlertTypeEnabled(String type) {
    if (isAnnouncementAlertType(type)) return announcementAlertEnabled;
    if (type == 'high') return highAlertEnabled;
    if (type == 'marketOpen') return marketOpenAlertEnabled;
    if (type == 'minus20' ||
        type == 'minus30' ||
        type == 'minus40' ||
        type == 'minus50' ||
        type == 'recovery20' ||
        type == 'recovery30' ||
        type == 'recovery40' ||
        type == 'recovery50') {
      return strategyAlertEnabled;
    }
    if (type == 'nasdaq200Breakdown' ||
        type == 'nasdaq200Breakout' ||
        type == 'nasdaq200Recovery') {
      return nasdaq200AlertEnabled;
    }
    if (type == 'portfolioCashHigh' || type == 'portfolioCashLow') {
      return portfolioCashAlertEnabled;
    }
    if (type.startsWith('profitTarget')) {
      return profitTargetAlertEnabled;
    }
    return true;
  }

  void showAndSaveAlert(
    String message,
    Color color,
    String type, {
    String? detail,
    String link = '',
  }) {
    Future.microtask(() {
      if (!mounted) return;

      final alertDetail = detail ?? localizedAlertDetailForType(
        AppLocalizations.of(context)!,
        type,
        message,
      );

      unawaited(
        showLocalAlertNotification(
          message,
          detail: alertDetail,
          link: link,
          type: type,
        ),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: color,
          content: Text(
            message,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      );

      addAlertHistory(message, type, detail: alertDetail, link: link);
    });
  }

  void showZoneAlert(
    String title,
    Color color,
    String type,
  ) {
    showAndSaveAlert(
      title,
      color,
      type,
    );
  }

  Widget buildAlertSettingTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return GestureDetector(
      onTap: showMa200InfoSheet,
      behavior: HitTestBehavior.opaque,
      child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: value ? _blue : Colors.white38,
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            activeColor: _blue,
            onChanged: onChanged,
          ),
        ],
      ),
    ),
  );
}

  void showAlertSettingsSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0D1724),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final l10n = AppLocalizations.of(context)!;

            void updateSetting(
              String key,
              bool value,
              ValueChanged<bool> apply,
            ) {
              setState(() {
                apply(value);
              });

              setSheetState(() {});
              saveAlertSetting(key, value);
            }

            return SafeArea(
              top: false,
              child: DraggableScrollableSheet(
                expand: false,
                initialChildSize: 0.72,
                minChildSize: 0.42,
                maxChildSize: 0.92,
                builder: (context, scrollController) {
                  return SingleChildScrollView(
                    controller: scrollController,
                    padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                    child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      l10n.alertSettingsTitle,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    buildAlertSettingTile(
                      icon: Icons.trending_up_rounded,
                      title: l10n.alertHighTitle,
                      subtitle: l10n.alertHighSubtitle,
                      value: highAlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'highAlertEnabled',
                          value,
                          (next) => highAlertEnabled = next,
                        );
                      },
                    ),
                    buildAlertSettingTile(
                      icon: Icons.schedule_rounded,
                      title: l10n.alertMarketOpenTitle,
                      subtitle: l10n.alertMarketOpenSubtitle,
                      value: marketOpenAlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'marketOpenAlertEnabled',
                          value,
                          (next) => marketOpenAlertEnabled = next,
                        );
                      },
                    ),
                    buildAlertSettingTile(
                      icon: Icons.rule_rounded,
                      title: l10n.alertStrategySettingTitle,
                      subtitle: l10n.alertStrategySettingSubtitle,
                      value: strategyAlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'strategyAlertEnabled',
                          value,
                          (next) => strategyAlertEnabled = next,
                        );
                      },
                    ),
                    buildAlertSettingTile(
                      icon: Icons.show_chart_rounded,
                      title: l10n.alertNasdaq200Title,
                      subtitle: l10n.alertNasdaq200Subtitle,
                      value: nasdaq200AlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'nasdaq200AlertEnabled',
                          value,
                          (next) => nasdaq200AlertEnabled = next,
                        );
                      },
                    ),
                    buildAlertSettingTile(
                      icon: Icons.account_balance_wallet_outlined,
                      title: l10n.alertPortfolioCashTitle,
                      subtitle: l10n.alertPortfolioCashSubtitle,
                      value: portfolioCashAlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'portfolioCashAlertEnabled',
                          value,
                          (next) => portfolioCashAlertEnabled = next,
                        );
                      },
                    ),
                    buildAlertSettingTile(
                      icon: Icons.emoji_events_outlined,
                      title: localizedProfitTargetSettingTitle(
                        Localizations.localeOf(context),
                      ),
                      subtitle: localizedProfitTargetSettingSubtitle(
                        Localizations.localeOf(context),
                      ),
                      value: profitTargetAlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'profitTargetAlertEnabled',
                          value,
                          (next) => profitTargetAlertEnabled = next,
                        );
                      },
                    ),
                    buildAlertSettingTile(
                      icon: Icons.campaign_outlined,
                      title: l10n.alertAnnouncementTitle,
                      subtitle: l10n.alertAnnouncementSubtitle,
                      value: announcementAlertEnabled,
                      onChanged: (value) {
                        updateSetting(
                          'announcementAlertEnabled',
                          value,
                          (next) => announcementAlertEnabled = next,
                        );
                      },
                    ),
                  ],
                ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }

  int dropZoneForPercent(double dropPercent) {
    if (dropPercent <= -50) return 50;
    if (dropPercent <= -40) return 40;
    if (dropPercent <= -30) return 30;
    if (dropPercent <= -20) return 20;
    return 0;
  }

  void evaluateDropAlerts(double dropPercent) {
    final nextZone = dropZoneForPercent(dropPercent);

    if (!dropAlertInitialized) {
      activeDropZone = nextZone;
      dropAlertInitialized = true;
      return;
    }

    if (nextZone == activeDropZone) return;

    if (!strategyAlertEnabled) {
      activeDropZone = nextZone;
      return;
    }

    if (nextZone > activeDropZone) {
      if (activeDropZone < 20 && nextZone >= 20) {
        touchedMinus20 = true;
        showZoneAlert(
          AppLocalizations.of(context)!.minus20Headline,
          Colors.green,
          'minus20',
        );
      }

      if (activeDropZone < 30 && nextZone >= 30) {
        touchedMinus30 = true;
        showZoneAlert(
          AppLocalizations.of(context)!.minus30Headline,
          Colors.orange,
          'minus30',
        );
      }

      if (activeDropZone < 40 && nextZone >= 40) {
        touchedMinus40 = true;
        showZoneAlert(
          AppLocalizations.of(context)!.minus40Headline,
          Colors.red,
          'minus40',
        );
      }

      if (activeDropZone < 50 && nextZone >= 50) {
        touchedMinus50 = true;
        showZoneAlert(
          AppLocalizations.of(context)!.minus50Headline,
          Colors.purple,
          'minus50',
        );
      }
    } else {
      if (activeDropZone >= 50 && nextZone < 50) {
        showZoneAlert(
          AppLocalizations.of(context)!.alertRecovery10,
          Colors.purple,
          'recovery50',
        );
      }

      if (activeDropZone >= 40 && nextZone < 40) {
        showZoneAlert(
          AppLocalizations.of(context)!.alertRecovery10,
          Colors.red,
          'recovery40',
        );
      }

      if (activeDropZone >= 30 && nextZone < 30) {
        showZoneAlert(
          AppLocalizations.of(context)!.alertRecovery10,
          Colors.orange,
          'recovery30',
        );
      }

      if (activeDropZone >= 20 && nextZone < 20) {
        showZoneAlert(
          AppLocalizations.of(context)!.alertRecovery10,
          Colors.green,
          'recovery20',
        );
      }
    }

    activeDropZone = nextZone;
  }

  Future<void> evaluateMarketOpenAlert(
    _UsMarketSession session,
    SharedPreferences prefs,
  ) async {
    if (!marketOpenAlertEnabled) return;

    final nyDate = _toNewYorkTime(DateTime.now().toUtc())
        .toString()
        .substring(0, 10);
    final initialized =
        prefs.getBool('marketOpenAlertInitialized') ??
        marketOpenAlertInitialized;

    if (!initialized) {
      marketOpenAlertInitialized = true;
      await prefs.setBool('marketOpenAlertInitialized', true);

      if (session == _UsMarketSession.regular) {
        lastMarketOpenAlertDate = nyDate;
        await prefs.setString('lastMarketOpenAlertDate', nyDate);
      }

      return;
    }

    if (session != _UsMarketSession.regular) return;

    final savedDate =
        prefs.getString('lastMarketOpenAlertDate') ??
        lastMarketOpenAlertDate;

    if (savedDate == nyDate) return;

    lastMarketOpenAlertDate = nyDate;
    await prefs.setString('lastMarketOpenAlertDate', nyDate);

    showZoneAlert(
      AppLocalizations.of(context)!.alertMarketOpen,
      _blue,
      'marketOpen',
    );
  }

  Future<void> evaluateNasdaq200DayAlert() async {
    final result = await _fetchDailyChartFromWorker('^NDX');
    if (result == null) return;

    final indicators = result['indicators'] as Map<String, dynamic>?;
    final quotes = indicators?['quote'] as List?;
    if (quotes == null || quotes.isEmpty) return;

    final quote = quotes.first as Map<String, dynamic>?;
    if (quote == null) return;

    final closes = quote['close'] as List?;
    if (closes == null) return;

    final validCloses = closes
        .where((value) => value != null)
        .map((value) => (value as num).toDouble())
        .toList();

    if (validCloses.length < 200) return;

    final latest = validCloses.last;
    final last200 = validCloses.sublist(validCloses.length - 200);
    final ma200 =
        last200.reduce((sum, value) => sum + value) / last200.length;
    final nextState = latest >= ma200 ? 1 : -1;

    final prefs = await SharedPreferences.getInstance();
    final savedState = prefs.getInt('nasdaq200State') ?? nasdaq200State;

    if (savedState == 0) {
      nasdaq200State = nextState;
      await prefs.setInt('nasdaq200State', nextState);
      return;
    }

    if (savedState == nextState) return;

    nasdaq200State = nextState;
    await prefs.setInt('nasdaq200State', nextState);

    if (!nasdaq200AlertEnabled) return;

    final l10n = AppLocalizations.of(context)!;
    final message = nextState < 0
        ? l10n.alertNasdaq200Breakdown
        : l10n.alertNasdaq200Breakout;

    showZoneAlert(
      message,
      nextState < 0 ? Colors.redAccent : _cyan,
      nextState < 0 ? 'nasdaq200Breakdown' : 'nasdaq200Breakout',
    );
  }

  Future<void> evaluatePortfolioCashAlert() async {
    final hasQldPosition = qldShares > 0;
    final hasTqqqPosition = tqqqShares > 0;

    if ((hasQldPosition && qldPrice <= 0) ||
        (hasTqqqPosition && tqqqPrice <= 0)) {
      return;
    }

    final qldValue = qldShares * qldPrice;
    final tqqqValue = tqqqShares * tqqqPrice;
    final stockValue = qldValue + tqqqValue;
    final totalAsset = qldValue + tqqqValue + cashAmount;

    if (totalAsset <= 0 || stockValue <= 0) return;

    final cashPercent = (cashAmount / totalAsset) * 100;
    final nextState = cashPercent <= 20 ? -1 : 0;

    final prefs = await SharedPreferences.getInstance();
    final savedState =
        prefs.getInt('portfolioCashState') ?? portfolioCashState;
    final initialized =
        prefs.getBool('portfolioCashAlertInitialized') ?? false;

    if (!initialized) {
      portfolioCashState = nextState;
      await prefs.setInt('portfolioCashState', nextState);
      await prefs.setBool('portfolioCashAlertInitialized', true);
      return;
    }

    if (savedState == nextState) return;

    portfolioCashState = nextState;
    await prefs.setInt('portfolioCashState', nextState);

    if (nextState == 0 || !portfolioCashAlertEnabled) return;

    final l10n = AppLocalizations.of(context)!;
    showZoneAlert(
      l10n.alertPortfolioCashLow,
      Colors.orangeAccent,
      'portfolioCashLow',
    );
  }

  int profitTargetMilestone(
    double currentPrice,
    double averagePrice,
  ) {
    if (currentPrice <= 0 || averagePrice <= 0) return 0;

    final profitPercent =
        ((currentPrice - averagePrice) / averagePrice) * 100;

    if (profitPercent >= 300) return 300;
    if (profitPercent >= 200) return 200;
    if (profitPercent >= 100) return 100;
    if (profitPercent >= 50) return 50;
    return 0;
  }

  Future<void> evaluateProfitTargetAlert() async {
    if ((qldAveragePrice > 0 && qldPrice <= 0) ||
        (tqqqAveragePrice > 0 && tqqqPrice <= 0)) {
      return;
    }

    final qldTarget =
        profitTargetMilestone(qldPrice, qldAveragePrice);
    final tqqqTarget =
        profitTargetMilestone(tqqqPrice, tqqqAveragePrice);

    if (qldAveragePrice <= 0 && tqqqAveragePrice <= 0) return;

    final prefs = await SharedPreferences.getInstance();
    final initialized =
        prefs.getBool('profitTargetAlertInitialized') ?? false;
    final savedQldTarget =
        prefs.getInt('qldProfitTargetState') ?? qldProfitTargetState;
    final savedTqqqTarget =
        prefs.getInt('tqqqProfitTargetState') ?? tqqqProfitTargetState;

    if (!initialized) {
      qldProfitTargetState = qldTarget;
      tqqqProfitTargetState = tqqqTarget;
      await prefs.setInt('qldProfitTargetState', qldTarget);
      await prefs.setInt('tqqqProfitTargetState', tqqqTarget);
      await prefs.setBool('profitTargetAlertInitialized', true);
      return;
    }

    final nextQldSavedTarget = math.max(savedQldTarget, qldTarget);
    final nextTqqqSavedTarget = math.max(savedTqqqTarget, tqqqTarget);

    qldProfitTargetState = nextQldSavedTarget;
    tqqqProfitTargetState = nextTqqqSavedTarget;
    await prefs.setInt('qldProfitTargetState', nextQldSavedTarget);
    await prefs.setInt('tqqqProfitTargetState', nextTqqqSavedTarget);

    if (!profitTargetAlertEnabled || !mounted) return;

    final locale = Localizations.localeOf(context);

    if (qldTarget > savedQldTarget) {
      showAndSaveAlert(
        localizedProfitTargetMessage(locale, 'QLD', qldTarget),
        Colors.lightGreenAccent,
        'profitTargetQld$qldTarget',
        detail: localizedProfitTargetDetail(locale, 'QLD', qldTarget),
      );
    }

    if (tqqqTarget > savedTqqqTarget) {
      showAndSaveAlert(
        localizedProfitTargetMessage(locale, 'TQQQ', tqqqTarget),
        Colors.lightGreenAccent,
        'profitTargetTqqq$tqqqTarget',
        detail: localizedProfitTargetDetail(locale, 'TQQQ', tqqqTarget),
      );
    }
  }

  @override
  void dispose() {
    _blinkController.dispose();
    priceTimer?.cancel();
    yahooHistoryTimer?.cancel();
    nasdaq200Timer?.cancel();

    qldController.dispose();
    tqqqController.dispose();
    cashController.dispose();
    qldAverageController.dispose();
    tqqqAverageController.dispose();
    homeScrollController.dispose();
    if (_activeHomeScrollController == homeScrollController) {
      _activeHomeScrollController = null;
    }

    super.dispose();
  }

  Future<void> fetchCurrentPrices() async {
    final session = _usMarketSessionFromUtc(DateTime.now().toUtc());
    final prefs = await SharedPreferences.getInstance();

    if (mounted) {
      setState(() {
        isRefreshingPrice = true;
      });
    }

    await evaluateMarketOpenAlert(session, prefs);

    final results = await Future.wait([
      fetchQuote('QLD'),
      fetchQuote('TQQQ'),
    ]);
    final qldQuote = results[0];
    final tqqqQuote = results[1];

    if (!mounted) return;

    var nextQldPrice = qldPrice;
    var nextTqqqPrice = tqqqPrice;
    var nextIsPriceUp = isPriceUp;

    if (qldQuote != null) {
      nextQldPrice = qldQuote.currentPrice;
      nextIsPriceUp = qldQuote.previousClose <= 0 ||
          qldQuote.currentPrice >= qldQuote.previousClose;
    } else {
      debugPrint('QLD Finnhub failed, keeping last price: $qldPrice');
    }

    if (tqqqQuote != null) {
      nextTqqqPrice = tqqqQuote.currentPrice;
    } else {
      debugPrint('TQQQ Finnhub failed, keeping last price: $tqqqPrice');
    }

    final hasFreshPrice = qldQuote != null || tqqqQuote != null;

    setState(() {
      qldPrice = nextQldPrice;
      tqqqPrice = nextTqqqPrice;
      isPreMarket = session == _UsMarketSession.pre;
      isRegularMarket = session == _UsMarketSession.regular;
      isPriceUp = nextIsPriceUp;
      latestDate = DateTime.now().toString().substring(0, 10);
      isLoading = false;
      isRefreshingPrice = false;
      isUsingCachedPrice = !hasFreshPrice && (qldPrice > 0 || tqqqPrice > 0);
      if (qldQuote != null) {
        qldMiniCandles = _qldMiniCandlesWithRealtimeClose(
          qldMiniCandles,
          nextQldPrice,
        );
      }
    });

    await saveCachedPrices(
      qld: qldPrice,
      tqqq: tqqqPrice,
      priceUp: isPriceUp,
    );

    await evaluateNewHighFromCurrentPrice(prefs);
    await evaluatePortfolioCashAlert();
    await evaluateProfitTargetAlert();

    if (basePrice > 0 && qldPrice > 0) {
      final nextDropPercent = ((qldPrice - basePrice) / basePrice) * 100;
      evaluateDropAlerts(nextDropPercent);
    }
  }

  Future<void> evaluateNewHighFromCurrentPrice(
    SharedPreferences prefs,
  ) async {
    if (qldPrice <= 0) return;

    final storedAllTimeHigh =
        prefs.getDouble('storedAllTimeHigh') ?? allTimeHigh;
    final isInitialHighLoad = storedAllTimeHigh <= 0;
    final isNewHigh = !isInitialHighLoad && qldPrice > storedAllTimeHigh;
    final today = DateTime.now().toString().substring(0, 10);

    if (isInitialHighLoad) {
      allTimeHigh = math.max(allTimeHigh, qldPrice);
      await prefs.setDouble('storedAllTimeHigh', allTimeHigh);
      return;
    }

    if (!isNewHigh) return;

    allTimeHigh = qldPrice;
    await prefs.setDouble('storedAllTimeHigh', qldPrice);

    final savedHighAlertDate =
        prefs.getString('lastHighAlertDate') ?? lastHighAlertDate;

    if (highAlertEnabled && savedHighAlertDate != today) {
      lastHighAlertDate = today;
      await prefs.setString('lastHighAlertDate', today);
      showZoneAlert(
        AppLocalizations.of(context)!.alertNewHigh,
        Colors.green,
        'high',
      );
    }
  }

  List<QldMiniCandle> buildQldMiniCandles({
    required List? opens,
    required List? highs,
    required List? lows,
    required List? closes,
  }) {
    if (opens == null ||
        highs == null ||
        lows == null ||
        closes == null ||
        closes.isEmpty) {
      return const [];
    }

    final validCandles = <QldMiniCandle>[];
    final rollingCloses = <double>[];
    final length = math.min(
      math.min(opens.length, highs.length),
      math.min(lows.length, closes.length),
    ).toInt();

    for (int i = 0; i < length; i++) {
      final open = _numberToDouble(opens[i]);
      final high = _numberToDouble(highs[i]);
      final low = _numberToDouble(lows[i]);
      final close = _numberToDouble(closes[i]);

      if (open <= 0 || high <= 0 || low <= 0 || close <= 0) {
        continue;
      }

      rollingCloses.add(close);
      final ma200 = rollingCloses.length >= 200
          ? rollingCloses
                  .skip(rollingCloses.length - 200)
                  .fold<double>(0, (sum, value) => sum + value) /
              200
          : null;

      validCandles.add(
        QldMiniCandle(
          open: open,
          high: math.max(high, math.max(open, close)),
          low: math.min(low, math.min(open, close)),
          close: close,
          ma200: ma200,
        ),
      );
    }

    const visibleTradingDays = 66;
    if (validCandles.length <= visibleTradingDays) return validCandles;
    return validCandles.sublist(validCandles.length - visibleTradingDays);
  }

  Future<void> fetchQldHistoricalReference() async {
    try {
      final result = await _fetchChartFromWorker('QLD');

      if (result == null) {
        debugPrint('Yahoo historical QLD failed, keeping previous basePrice');
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        return;
      }

      final timestamps = result['timestamp'] as List?;
      final indicators = result['indicators'] as Map<String, dynamic>?;
      final quoteList = indicators?['quote'] as List?;
      final quote = quoteList != null && quoteList.isNotEmpty
          ? quoteList.first as Map<String, dynamic>?
          : null;
      final opens = quote?['open'] as List?;
      final highs = quote?['high'] as List?;
      final lows = quote?['low'] as List?;
      final closes = quote?['close'] as List?;
      final miniCandles = buildQldMiniCandles(
        opens: opens,
        highs: highs,
        lows: lows,
        closes: closes,
      );

      if (timestamps == null || highs == null || highs.isEmpty) {
        debugPrint('Yahoo historical QLD response missing highs');
        return;
      }

      double highestPrice = 0;
      int highestIndex = 0;

      for (int i = 0; i < highs.length; i++) {
        final high = highs[i];
        if (high != null && high > highestPrice) {
          highestPrice = (high as num).toDouble();
          highestIndex = i;
        }
      }

      if (highestPrice <= 0) return;

      final now = DateTime.now();
      final shouldRefreshHighDate = lastHighDateRefreshAt == null ||
          now.difference(lastHighDateRefreshAt!) >= const Duration(hours: 6) ||
          highDate.isEmpty;
      final highDateTime = DateTime.fromMillisecondsSinceEpoch(
        (timestamps[highestIndex] as num).toInt() * 1000,
      );

      final prefs = await SharedPreferences.getInstance();
      final storedAllTimeHigh =
          prefs.getDouble('storedAllTimeHigh') ?? allTimeHigh;
      final newHighCandidate = math.max(qldPrice, highestPrice);
      final isInitialHighLoad = storedAllTimeHigh <= 0;

      if (isInitialHighLoad || newHighCandidate > storedAllTimeHigh) {
        allTimeHigh = newHighCandidate;
        await prefs.setDouble('storedAllTimeHigh', newHighCandidate);
      }

      if (!mounted) return;

      setState(() {
        basePrice = highestPrice;
        qldMiniCandles = _qldMiniCandlesWithRealtimeClose(
          miniCandles,
          qldPrice,
        );
        if (shouldRefreshHighDate) {
          highDate = highDateTime.toString().substring(0, 10);
          lastHighDateRefreshAt = now;
        }
        isLoading = false;
      });

      if (basePrice > 0 && qldPrice > 0) {
        final nextDropPercent = ((qldPrice - basePrice) / basePrice) * 100;
        evaluateDropAlerts(nextDropPercent);
      }
    } catch (error) {
      debugPrint('Yahoo historical QLD unavailable: $error');
      if (!mounted) return;
      setState(() {
        isLoading = false;
      });
    }
  }
  Future<void> openTradingView() async {
    final Uri uri = tradingViewSymbolOverviewUri('AMEX-QLD');

    if (!await launchUrl(
      uri,
      mode:
          LaunchMode.externalApplication,
    )) {
      throw Exception(
        'Could not launch $uri',
      );
    }
  }

  void showBasePositionInfo() {
    final l10n = AppLocalizations.of(context)!;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.86,
          minChildSize: 0.35,
          maxChildSize: 0.95,
          snap: true,
          snapSizes: const [0.35, 0.86, 0.95],
          shouldCloseOnMinExtent: true,
          builder: (context, scrollController) {
            return Container(
              decoration: const BoxDecoration(
                color: Color(0xFF111D2C),
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              child: SafeArea(
                top: false,
                child: SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.fromLTRB(24, 18, 24, 24),
              child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _cyan.withOpacity(0.16),
                      ),
                      child: const Icon(
                        Icons.shield_outlined,
                        color: _cyan,
                        size: 26,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(
                        l10n.basePosition,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Text(
                  l10n.basePositionDescription,
                  style: const TextStyle(
                    fontSize: 15,
                    height: 1.55,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('OK'),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    double dropPercent = 0;

    if (basePrice > 0) {
      dropPercent =
          ((qldPrice - basePrice) /
                  basePrice) *
              100;
    }
    final qldValue =
        qldShares * qldPrice;

    final tqqqValue =
        tqqqShares * tqqqPrice;

    final totalAsset =
        qldValue +
            tqqqValue +
            cashAmount;

    return Scaffold(
      backgroundColor: _appBg,
      extendBody: true,
      appBar: AppBar(
        toolbarHeight: 48,
        leading: IconButton(
          icon: const Icon(
            Icons.notifications_active_outlined,
            color: Colors.white70,
            size: 20,
          ),
          onPressed: showAlertSettingsSheet,
        ),
        title: const FittedBox(
          fit: BoxFit.scaleDown,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.show_chart_rounded,
                color: _cyan,
                size: 17,
              ),
              SizedBox(width: 6),
              Text(
                'QLD DIP ALERT',
                maxLines: 1,
                style: TextStyle(
                  fontWeight:
                      FontWeight.bold,
                  letterSpacing: 1.1,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: 44,
            child: buildLanguageMenuButton(context, iconSize: 20),
          ),
        ],

        centerTitle: true,
        backgroundColor:
            Colors.transparent,
        elevation: 0,
      ),
      bottomNavigationBar: buildFixedAdBottomBar(_buildBottomNav(dropPercent)),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.2,
            colors: [
              Color(0xFF102033),
              _appBg,
            ],
          ),
        ),
        child: isLoading
            ? const Center(
                child:
                    CircularProgressIndicator(),
              )
            : SingleChildScrollView(
              controller: homeScrollController,
              padding:
                  const EdgeInsets.fromLTRB(
                      12, 10, 12, 144),
              child: Column(
                children: [
                  Container(
                    width:
                        double.infinity,
                    padding:
                        const EdgeInsets.fromLTRB(
                            16, 20, 16, 20),
                    decoration:
                        BoxDecoration(
                      color:
                          _cardBg,
                      borderRadius:
                          BorderRadius.circular(
                              30),
                      border: Border.all(
                        color: _cardLine,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors
                              .black54,
                          blurRadius: 28,
                          offset:
                              Offset(0, 14),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                 Text(
                                  AppLocalizations.of(context)!.tenYearHigh,
                                  style:
                                      const TextStyle(
                                    fontSize:
                                        12,
                                    color: Colors
                                        .white60,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Text(
                                    '\$${basePrice.toStringAsFixed(2)}',
                                    style:
                                        const TextStyle(
                                      fontSize:
                                          25,
                                      fontWeight:
                                          FontWeight.bold,
                                      color: _blue,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                    height:
                                        4),
                                Text(
                                  highDate,
                                  style:
                                      const TextStyle(
                                    fontSize:
                                        12,
                                    color: Colors
                                        .white54,
                                  ),
                                ),
                                ],
                              ),
                            ),
                            Container(
                              width: 1,
                              height: 96,
                              color: _cardLine,
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                 Text(
                                  AppLocalizations.of(context)!.currentPrice,
                                  style:
                                      const TextStyle(
                                    fontSize:
                                        12,
                                    color: Colors
                                        .white60,
                                  ),
                                ),

                                const SizedBox(height: 10),
                                GestureDetector(
                                  onTap: openTradingView,
                                  behavior: HitTestBehavior.opaque,
                                  child: FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          qldPrice > 0
                                              ? '\$${qldPrice.toStringAsFixed(2)}'
                                              : '--',
                                          style: const TextStyle(
                                            fontSize: 25,
                                            fontWeight: FontWeight.bold,
                                            color: _cyan,
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        const Icon(
                                          Icons.chevron_right_rounded,
                                          color: Colors.white54,
                                          size: 18,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                    height:
                                        4),
                                Text(
                                  localizedPriceRefreshStatus(
                                    Localizations.localeOf(context),
                                    isRefreshing: isRefreshingPrice,
                                    isCached: isUsingCachedPrice,
                                  ),
                                  style:
                                      TextStyle(
                                    fontSize:
                                        10,
                                    color: isRefreshingPrice
                                        ? _cyan
                                        : isUsingCachedPrice
                                            ? Colors.amberAccent
                                            : Colors.white54,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                AnimatedBuilder(
                                  animation: _blinkAnimation,
                                  builder: (context, child) {
                                    final currentSession =
                                        _usMarketSessionFromUtc(
                                      DateTime.now().toUtc(),
                                    );

                                    final isMarketClosed = currentSession ==
                                        _UsMarketSession.closed;

                                    final isAfterHours = !isPreMarket &&
                                        !isRegularMarket &&
                                        currentSession ==
                                            _UsMarketSession.afterHours;

                                    final statusText =
                                        localizedMarketStatusText(
                                      Localizations.localeOf(context),
                                      isPreMarket: isPreMarket,
                                      isRegularMarket: isRegularMarket,
                                      isAfterHours: isAfterHours,
                                    );

                                    final statusColor = isMarketClosed
                                        ? Colors.white54
                                        : isPreMarket
                                            ? _cyan
                                            : isAfterHours
                                                ? Colors.purpleAccent
                                                : _cyan;

                                    return Opacity(
                                      opacity: _blinkAnimation.value,
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Container(
                                            width: 8,
                                            height: 8,
                                            decoration: BoxDecoration(
                                              color: statusColor,
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                          const SizedBox(width: 5),
                                          Text(
                                            statusText,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold,
                                              color: statusColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                                ],
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(
                            height: 20),

                        Row(
                          children: [
                            Expanded(
                              flex: 3,
                              child: Container(
                                padding:
                                    const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 12,
                                ),
                                decoration:
                                    BoxDecoration(
                                  color: Colors.white.withOpacity(0.03),
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(
                                    color: _cardLine,
                                  ),
                                ),
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text:
                                              '${AppLocalizations.of(context)!.from10yHigh} ',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white54,
                                          ),
                                        ),
                                        TextSpan(
                                          text:
                                              '${dropPercent.toStringAsFixed(2)}%',
                                          style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.redAccent,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 2,
                              child: GestureDetector(
                                onTap: () => openFearGreedPage(context),
                                child: Container(
                                  padding:
                                      const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 10,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.03),
                                    borderRadius: BorderRadius.circular(18),
                                    border: Border.all(
                                      color: _cardLine,
                                    ),
                                  ),
                                  child: FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          homeFearGreedData == null
                                              ? AppLocalizations.of(context)!
                                                  .navFearGreed
                                              : localizedFearGreedRating(
                                                  AppLocalizations.of(context)!,
                                                  homeFearGreedData!.score,
                                                ),
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white54,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          homeFearGreedData == null
                                              ? '--'
                                              : homeFearGreedData!.score
                                                  .toStringAsFixed(0),
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: homeFearGreedData == null
                                                ? Colors.white54
                                                : fearGreedColorForScore(
                                                    homeFearGreedData!.score,
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                      height: 14),

GestureDetector(
                    onTap: showBasePositionInfo,
                    child:                   Container(
                    width:
                        double.infinity,
                    padding:
                        const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 18),
                    decoration:
                        BoxDecoration(
                      gradient:
                          const LinearGradient(
                        colors: [
                          Color(0xFF0BBF8D),
                          Color(0xFF07304A),
                        ],
                      ),
                      borderRadius:
                          BorderRadius.circular(
                              26),
                      border: Border.all(
                        color: Color(0xFF0AAEAC),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.06),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.25),
                            ),
                          ),
                          child: const Icon(
                            Icons.shield_outlined,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppLocalizations.of(context)!.basePosition,
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.white70,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                AppLocalizations.of(context)!.holdQLDPlusCash,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Icon(
                          Icons.chevron_right_rounded,
                          color: Colors.white70,
                          size: 24,
                        ),
                      ],
                    ),
                  )
                  ),

                  const SizedBox(
                      height: 14),

                  buildAlertCard(
                    dropPercent,
                  ),

                  const SizedBox(
                      height: 14),

                  buildPortfolioCard(
                    qldValue,
                    tqqqValue,
                    totalAsset,
                  ),

                  const SizedBox(height: 24),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.candlestick_chart_rounded,
                          color: _cyan,
                          size: 17,
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: Text(
                            AppLocalizations.of(context)!.chartMiniTitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 8),

                  buildQldMiniChart(),

                  const SizedBox(height: 8),

                  buildChartGuideInfoStrip(),

                  const SizedBox(height: 14),
                  if (DateTime.now().isBefore(DateTime(1900)))
                  const Text(
                    '© 2026 Dong Hwan. All rights reserved.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white30,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    '(C) 2026 Dong Hwan. All rights reserved.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white30,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(
                      height: 144),
                ],
              ),
            ),
      ),
    );
  }

  void showMa200InfoSheet() {
    final l10n = AppLocalizations.of(context)!;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: const BoxDecoration(
            color: Color(0xFF111D2C),
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(24),
            ),
          ),
          child: SafeArea(
            top: false,
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: Colors.amberAccent.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: Colors.amberAccent.withOpacity(0.32),
                          ),
                        ),
                        child: const Icon(
                          Icons.timeline_rounded,
                          color: Colors.amberAccent,
                          size: 23,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          l10n.chartMa200SheetTitle,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    l10n.chartMa200SheetBody,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                      height: 1.55,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _blue,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text('OK'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildChartGuideStrip() {
    final l10n = AppLocalizations.of(context)!;

    return GestureDetector(
      onTap: showMa200InfoSheet,
      behavior: HitTestBehavior.opaque,
      child: Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.035),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.07)),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.candlestick_chart_rounded,
            color: _cyan,
            size: 15,
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              '${l10n.chartGuideCandleTitle} · ${l10n.chartGuideMa200Title}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white60,
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 8),
          const Icon(
            Icons.info_outline_rounded,
            color: Colors.white38,
            size: 14,
          ),
        ],
      ),
      ),
    );
  }

  Widget buildChartGuideInfoStrip() {
    final l10n = AppLocalizations.of(context)!;

    return GestureDetector(
      onTap: showMa200InfoSheet,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.035),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.07)),
        ),
        child: Row(
          children: [
            const Icon(
              Icons.candlestick_chart_rounded,
              color: _cyan,
              size: 15,
            ),
            const SizedBox(width: 7),
            Expanded(
              child: Text(
                l10n.chartMiniTitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.info_outline_rounded,
              color: Colors.white38,
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  Widget buildChartGuideCard() {
    final l10n = AppLocalizations.of(context)!;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.045),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: _cyan.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _cyan.withOpacity(0.28)),
                ),
                child: const Icon(
                  Icons.candlestick_chart_rounded,
                  color: _cyan,
                  size: 17,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  l10n.chartGuideTitle,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _buildChartGuideItem(
                  label: '3M',
                  title: l10n.chartGuideCandleTitle,
                  body: l10n.chartGuideCandleBody,
                  color: _cyan,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildChartGuideItem(
                  label: '200D',
                  title: l10n.chartGuideMa200Title,
                  body: l10n.chartGuideMa200Body,
                  color: Colors.amberAccent,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChartGuideItem({
    required String label,
    required String title,
    required String body,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.14),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            body,
            style: const TextStyle(
              color: Colors.white60,
              fontSize: 10,
              fontWeight: FontWeight.w600,
              height: 1.35,
            ),
          ),
        ],
      ),
    );
  }

  Widget buildQldMiniChart() {
    if (qldMiniCandles.isEmpty) {
      return GestureDetector(
        onTap: openTradingView,
        child: Container(
          width: double.infinity,
          height: 200,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: _cardBg,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _cardLine),
          ),
          child: const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: _cyan,
            ),
          ),
        ),
      );
    }

    final ma200Spots = <FlSpot>[];
    var minY = double.infinity;
    var maxY = 0.0;

    for (int i = 0; i < qldMiniCandles.length; i++) {
      final candle = qldMiniCandles[i];
      minY = math.min(minY, candle.low);
      maxY = math.max(maxY, candle.high);

      final ma200 = candle.ma200;
      if (ma200 != null && ma200 > 0) {
        ma200Spots.add(FlSpot(i.toDouble(), ma200));
        minY = math.min(minY, ma200);
        maxY = math.max(maxY, ma200);
      }
    }

    final currentChartPrice =
        qldPrice > 0 ? qldPrice : qldMiniCandles.last.close;
    minY = math.min(minY, currentChartPrice);
    maxY = math.max(maxY, currentChartPrice);

    final yRange = math.max(0.01, maxY - minY);
    final paddedMinY = minY - yRange * 0.08;
    final paddedMaxY = maxY + yRange * 0.08;
    final lastX = (qldMiniCandles.length - 1).toDouble();

    final lineBars = <LineChartBarData>[
      if (ma200Spots.length >= 2)
        LineChartBarData(
          spots: ma200Spots,
          isCurved: true,
          color: Colors.amberAccent.withOpacity(0.72),
          barWidth: 1.3,
          isStrokeCapRound: true,
          dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(show: false),
        ),
      LineChartBarData(
        spots: [FlSpot(lastX, currentChartPrice)],
        color: _cyan,
        barWidth: 0,
        dotData: FlDotData(
          getDotPainter: (spot, percent, barData, index) {
            return FlDotCirclePainter(
              radius: 3.8,
              color: _cyan,
              strokeWidth: 1.8,
              strokeColor: Colors.white.withOpacity(0.9),
            );
          },
        ),
        belowBarData: BarAreaData(show: false),
      ),
    ];

    return GestureDetector(
      onTap: openTradingView,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          color: _cardBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _cardLine),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _QldMiniCandlePainter(
                  candles: qldMiniCandles,
                  minY: paddedMinY,
                  maxY: paddedMaxY,
                ),
              ),
            ),
            Positioned.fill(
              child: LineChart(
                LineChartData(
                  minX: 0,
                  maxX: lastX,
                  minY: paddedMinY,
                  maxY: paddedMaxY,
                  gridData: const FlGridData(show: false),
                  titlesData: const FlTitlesData(show: false),
                  borderData: FlBorderData(show: false),
                  lineTouchData: const LineTouchData(enabled: false),
                  lineBarsData: lineBars,
                ),
              ),
            ),
            Positioned(
              left: 10,
              top: 8,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'QLD 3M',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  if (ma200Spots.length >= 2) ...[
                    const SizedBox(width: 8),
                    Container(
                      width: 16,
                      height: 2,
                      color: Colors.amberAccent.withOpacity(0.72),
                    ),
                    const SizedBox(width: 4),
                    const Text(
                      '200D',
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Positioned(
              right: 10,
              top: 8,
              child: Text(
                '\$${currentChartPrice.toStringAsFixed(2)}',
                style: const TextStyle(
                  color: _cyan,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildPortfolioCard(
    double qldValue,
    double tqqqValue,
    double totalAsset,
  ) {
    final l10n = AppLocalizations.of(context)!;
    final cashPercent = totalAsset > 0
        ? ((cashAmount / totalAsset) * 100).round()
        : 30;
    final qldPercent = totalAsset > 0
        ? ((qldValue / totalAsset) * 100).round()
        : 70;
    final tqqqPercent = totalAsset > 0
        ? ((tqqqValue / totalAsset) * 100).round()
        : 0;
    final chartCashValue = totalAsset > 0 ? cashAmount : 30.0;
    final chartQldValue = totalAsset > 0 ? qldValue : 70.0;
    final chartTqqqValue = totalAsset > 0 ? tqqqValue : 0.01;
    final qldCost = qldAveragePrice > 0 ? qldShares * qldAveragePrice : 0.0;
    final tqqqCost =
        tqqqAveragePrice > 0 ? tqqqShares * tqqqAveragePrice : 0.0;
    final totalCost = qldCost + tqqqCost;
    final totalProfit = qldValue + tqqqValue - totalCost;
    final hasAverageCost = totalCost > 0;
    final totalProfitText =
        '${totalProfit >= 0 ? '+' : '-'} \$${formatMoney(totalProfit.abs())}';
    final totalProfitColor =
        totalProfit >= 0 ? Colors.greenAccent : Colors.redAccent;

    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:
            _cardBg,
        borderRadius:
            BorderRadius.circular(
                28),
        border: Border.all(
          color: _cardLine,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  AppLocalizations.of(context)!.portfolio,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ),
              TextButton(
                onPressed: () async {
                  if (showPortfolioInput) {
                    await savePortfolio();
                  }

                  if (!mounted) return;
                  setState(() {
                    showPortfolioInput =
                        !showPortfolioInput;
                  });
                },
                child: Text(
                  showPortfolioInput
                      ? AppLocalizations.of(context)!.portfolioClose
                      : AppLocalizations.of(context)!.portfolioAssetInput,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: Colors.white54,
                size: 26,
              ),
            ],
          ),

          const SizedBox(height: 6),

          Row(
            children: [
              Expanded(
                flex: 6,
                child: SizedBox(
                  height: 142,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      PieChart(
                        PieChartData(
                          sectionsSpace: 3,
                          centerSpaceRadius:
                              37,
                          sections: [
                            PieChartSectionData(
                              color: _cyan,
                              value: chartCashValue,
                              title: '',
                              radius: 31,
                            ),
                            PieChartSectionData(
                              color: _purple,
                              value: chartQldValue,
                              title: '',
                              radius: 31,
                            ),
                            PieChartSectionData(
                              color: _blue,
                              value: chartTqqqValue,
                              title: '',
                              radius: 31,
                            ),
                          ],
                        ),
                      ),
                      Column(
                        mainAxisSize:
                            MainAxisSize.min,
                        children: [
                          const Text(
                            'CASH',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '$cashPercent%',
                            style: const TextStyle(
                              color: _cyan,
                              fontSize: 21,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 4,
                child: Column(
                  children: [
                    _buildLegendRow(
                      'CASH',
                      _cyan,
                      cashPercent,
                    ),
                    const SizedBox(height: 10),
                    _buildLegendRow(
                      'QLD',
                      _purple,
                      qldPercent,
                    ),
                    const SizedBox(height: 10),
                    _buildLegendRow(
                      'TQQQ',
                      _blue,
                      tqqqPercent,
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          Row(
            children: [
              if (hasAverageCost)
                Text(
                  '${l10n.portfolioProfitLoss} $totalProfitText',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: totalProfitColor,
                  ),
                ),
              const Spacer(),
              Text(
                '${l10n.portfolioTotal} \$${formatMoney(totalAsset)}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight:
                      FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),

          if (qldAveragePrice > 0 || tqqqAveragePrice > 0)
            const SizedBox(height: 10),

          if (qldAveragePrice > 0)
            buildAveragePriceSummary(
              'QLD',
              qldAveragePrice,
              _purple,
            ),

          if (qldAveragePrice > 0 && tqqqAveragePrice > 0)
            const SizedBox(height: 8),

          if (tqqqAveragePrice > 0)
            buildAveragePriceSummary(
              'TQQQ',
              tqqqAveragePrice,
              _blue,
            ),

          if (showPortfolioInput)
            const SizedBox(height: 20),

          if (showPortfolioInput)
            buildAssetRow(
              'QLD',
              _purple,
              qldShares,
              qldValue,
              totalAsset,
            ),

          if (showPortfolioInput)
            const SizedBox(height: 10),

          if (showPortfolioInput)
            buildAssetRow(
              'TQQQ',
              _blue,
              tqqqShares,
              tqqqValue,
              totalAsset,
            ),

          if (showPortfolioInput)
            const SizedBox(height: 10),

          if (showPortfolioInput)
            buildAssetRow(
              'CASH',
              _cyan,
              0,
              cashAmount,
              totalAsset,
              isCash: true,
            ),

          if (showPortfolioInput)
            Column(
              children: [
                const SizedBox(
                    height: 18),

                buildInput(
                  AppLocalizations.of(context)!.portfolioQldShares,
                  qldController,
                ),

                const SizedBox(
                    height: 12),

                buildInput(
                  AppLocalizations.of(context)!.portfolioQldAveragePrice,
                  qldAverageController,
                  allowDecimal: true,
                ),

                const SizedBox(
                    height: 12),

                buildInput(
                  AppLocalizations.of(context)!.portfolioTqqqShares,
                  tqqqController,
                ),

                const SizedBox(
                    height: 12),

                buildInput(
                  AppLocalizations.of(context)!.portfolioTqqqAveragePrice,
                  tqqqAverageController,
                  allowDecimal: true,
                ),

                const SizedBox(
                    height: 12),

                buildInput(
                  AppLocalizations.of(context)!.portfolioCashUsd,
                  cashController,
                ),

                const SizedBox(height: 12),

                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: OutlinedButton(
                    onPressed: () async {
                      await savePortfolio();
                      if (!mounted) return;
                      setState(() {
                        showPortfolioInput = false;
                      });
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white70,
                      side: BorderSide(
                        color: Colors.white.withOpacity(0.14),
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: Text(
                      AppLocalizations.of(context)!.portfolioClose,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildLegendRow(
    String label,
    Color color,
    int percent,
  ) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Text(
          '$percent%',
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 11,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget buildAssetRow(
    String name,
    Color color,
    double shares,
    double value,
    double totalAsset, {
    bool isCash = false,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: Colors.white
            .withOpacity(0.05),
        borderRadius:
            BorderRadius.circular(
                18),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 8,
            backgroundColor: color,
          ),

          const SizedBox(width: 9),

          Expanded(
            child: Text(
              isCash
                  ? name
                  : '$name ${shares.toStringAsFixed(0)} ${AppLocalizations.of(context)!.portfolioSharesUnit}',
              style: const TextStyle(
                fontWeight:
                    FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),

                    Text(
            totalAsset > 0
                ? '\$${formatMoney(value)} (${((value / totalAsset) * 100).toStringAsFixed(0)}%)'
                : '\$0',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget buildAveragePriceSummary(
    String symbol,
    double averagePrice,
    Color color,
  ) {
    final l10n = AppLocalizations.of(context)!;
    final currentPrice = symbol == 'TQQQ' ? tqqqPrice : qldPrice;
    final hasCurrentPrice = currentPrice > 0;
    final profitPercent = hasCurrentPrice
        ? ((currentPrice - averagePrice) / averagePrice) * 100
        : 0.0;
    final recoveryPercent =
        hasCurrentPrice && currentPrice < averagePrice
            ? ((averagePrice - currentPrice) / currentPrice) * 100
            : 0.0;
    final isProfit = profitPercent >= 0;
    final profitColor =
        isProfit ? Colors.greenAccent : Colors.redAccent;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.045),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.07),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 42,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(99),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$symbol ${l10n.portfolioAveragePriceShort} \$${averagePrice.toStringAsFixed(2)}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  hasCurrentPrice
                      ? '${l10n.currentPrice} \$${currentPrice.toStringAsFixed(2)}'
                      : '$symbol ${l10n.portfolioPriceLoading}',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                hasCurrentPrice
                    ? '${l10n.portfolioReturnRate} ${isProfit ? '+' : ''}${profitPercent.toStringAsFixed(2)}%'
                    : '-',
                style: TextStyle(
                  color: hasCurrentPrice ? profitColor : Colors.white38,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                !hasCurrentPrice
                    ? '${l10n.portfolioToBreakeven} -'
                    : recoveryPercent > 0
                        ? '${l10n.portfolioToBreakeven} +${recoveryPercent.toStringAsFixed(2)}%'
                        : l10n.portfolioBreakevenCleared,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildInput(
  String hint,
  TextEditingController
      controller,
  {
    bool allowDecimal = false,
  }
) {
  return TextField(
    controller: controller,
    keyboardType:
        allowDecimal
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.number,
    textInputAction: TextInputAction.done,
    onSubmitted: (_) => savePortfolio(),
    inputFormatters: [
      FilteringTextInputFormatter.allow(
        allowDecimal ? RegExp(r'[0-9.]') : RegExp(r'[0-9]'),
      ),
    ],
    style: const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.bold,
    ),
    decoration: InputDecoration(
      labelText: hint,
      hintText: '0',
      labelStyle: const TextStyle(
        color: Colors.white70,
        fontWeight: FontWeight.bold,
      ),
      filled: true,
      fillColor: Colors.white
          .withOpacity(0.05),
      border: OutlineInputBorder(
        borderRadius:
            BorderRadius.circular(
                16),
        borderSide:
            BorderSide.none,
      ),
      enabledBorder:
          OutlineInputBorder(
        borderRadius:
            BorderRadius.circular(
                16),
        borderSide:
            BorderSide.none,
      ),
      focusedBorder:
          OutlineInputBorder(
        borderRadius:
            BorderRadius.circular(
                16),
        borderSide:
            const BorderSide(
          color:
              Colors.greenAccent,
          width: 1.5,
        ),
      ),
    ),
  );
}

  Widget buildAlertCard(double dropPercent) {
    Color color;
    IconData icon;
    String percent;
    String title;
    String subtitle;
    Widget page;
    bool useGradient = true;

    if (dropPercent <= -50) {
      color = Colors.purple;
      icon = Icons.bolt_rounded;
      percent = '-50%';
      title = AppLocalizations.of(context)!.minus50Headline;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus50Page();
    } else if (touchedMinus50 && dropPercent > -50) {
      color = Colors.purple;
      icon = Icons.check_circle_outline_rounded;
      percent = '-50%';
      title = AppLocalizations.of(context)!.hold;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus50Page();
    } else if (dropPercent <= -40) {
      color = Colors.red;
      icon = Icons.warning_amber_rounded;
      percent = '-40%';
      title = AppLocalizations.of(context)!.minus40Headline;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus40Page();
    } else if (touchedMinus40 &&
        dropPercent > -40 &&
        dropPercent <= -20) {
      color = Colors.redAccent;
      icon = Icons.check_circle_outline_rounded;
      percent = '-40%';
      title = AppLocalizations.of(context)!.hold;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus40Page();
    } else if (dropPercent <= -30) {
      color = Colors.orange;
      icon = Icons.shopping_cart_checkout_rounded;
      percent = '-30%';
      title = AppLocalizations.of(context)!.minus30Headline;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus30Page();
    } else if (touchedMinus30 &&
        dropPercent > -30 &&
        dropPercent <= -20) {
      color = Colors.orangeAccent;
      icon = Icons.check_circle_outline_rounded;
      percent = '-30%';
      title = AppLocalizations.of(context)!.hold;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus30Page();
    } else if (dropPercent <= -20) {
      color = Colors.green;
      icon = Icons.auto_graph_rounded;
      percent = '-20%';
      title = AppLocalizations.of(context)!.minus20Headline;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus20Page();
    } else if (touchedMinus20 && dropPercent > -20) {
      color = Colors.greenAccent;
      icon = Icons.check_circle_outline_rounded;
      percent = '-20%';
      title = AppLocalizations.of(context)!.buyingInProgress;
      subtitle = AppLocalizations.of(context)!.tapToViewStrategy;
      page = const Minus20Page();
    } else {
      color = Colors.blueGrey;
      icon = Icons.rule_rounded;
      percent = '0% ~ -20%';
      title = AppLocalizations.of(context)!.noBuyZone;
      subtitle = AppLocalizations.of(context)!.buySignalMessage;
      page = const NoBuyZonePage();
      useGradient = false;
    }

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => page,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 16,
        ),
        decoration: BoxDecoration(
          color: useGradient ? null : const Color(0xFF151B24),
          gradient: useGradient
              ? LinearGradient(
                  colors: [
                    color.withOpacity(0.88),
                    const Color(0xFF07304A),
                  ],
                )
              : null,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(
            color: color.withOpacity(0.75),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.06),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                ),
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 28,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    percent,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.white70,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            const Icon(
              Icons.chevron_right_rounded,
              color: Colors.white70,
              size: 24,
            ),
          ],
        ),
      ),
    );
  }
Widget _buildBottomNav(double dropPercent) {
  return Container(
    margin: EdgeInsets.zero,
    padding: const EdgeInsets.symmetric(
      horizontal: 6,
      vertical: 7,
    ),
    decoration: BoxDecoration(
      color: const Color(0xF20A1726),
      borderRadius: BorderRadius.zero,
      border: const Border(
        top: BorderSide(color: _cardLine),
      ),
      boxShadow: const [
        BoxShadow(
          color: Colors.black54,
          blurRadius: 22,
          offset: Offset(0, -6),
        ),
      ],
    ),
    child: SafeArea(
      top: false,
      minimum: EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(
            Icons.home_rounded,
            AppLocalizations.of(context)!.navHome,
            true,
            () {
              goHomeAndScrollTop(context);
            },
          ),
          _navItem(
            Icons.show_chart_rounded,
            AppLocalizations.of(context)!.navChart,
            false,
            () => openChartPage(context),
          ),
          _navItem(
            Icons.currency_exchange_rounded,
            AppLocalizations.of(context)!.navExchange,
            false,
            () => openExchangePage(context),
          ),
          _navItem(
            Icons.speed_rounded,
            AppLocalizations.of(context)!.navFearGreed,
            false,
            () => openFearGreedPage(context),
          ),
          ValueListenableBuilder<int>(
            valueListenable: alertBadgeCount,
            builder: (context, count, _) {
              return _navItem(
                Icons.notifications_none_rounded,
                AppLocalizations.of(context)!.navAlert,
                false,
                () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NotificationHistoryPage(
                        items: alertHistory,
                      ),
                    ),
                  );
                },
                badgeCount: count,
              );
            },
          ),
          _navItem(
            Icons.rule_rounded,
            AppLocalizations.of(context)!.navStrategy,
            false,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const StrategyPage(),
                ),
              );
            },
          ),
        ],
      ),
    ),
  );
}

Widget _navItem(
  IconData icon,
  String label,
  bool selected,
  VoidCallback onTap,
  {int badgeCount = 0}
) {
  final color = selected ? _blue : Colors.white54;

  return InkWell(
    borderRadius: BorderRadius.circular(14),
    onTap: onTap,
    child: SizedBox(
      width: 48,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Icon(
                icon,
                color: color,
                size: 21,
              ),
              if (badgeCount > 0)
                Positioned(
                  right: -9,
                  top: -7,
                  child: Container(
                    constraints: const BoxConstraints(
                      minWidth: 15,
                      minHeight: 15,
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: const BoxDecoration(
                      color: Colors.redAccent,
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      badgeCount > 99 ? '99+' : '$badgeCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontSize: 9,
              fontWeight:
                  selected ? FontWeight.bold : FontWeight.w600,
            ),
          ),
        ],
      ),
    ),
  );
}

String formatMoney(double value) {
  return NumberFormat('#,###')
      .format(value);
}     

}

Future<void> launchTradingViewPage([String symbolPath = 'AMEX-QLD']) async {
  final uri = tradingViewSymbolOverviewUri(symbolPath);

  if (await canLaunchUrl(uri)) {
    await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );
  }
}

Uri tradingViewSymbolOverviewUri(String symbolPath) {
  return Uri.https(
    'www.tradingview.com',
    '/symbols/$symbolPath/',
    const {
      'range': '1M',
      'chartType': 'candlesticks',
      'style': '1',
    },
  );
}

bool matchesSearchQuery(String searchText, String query) {
  final normalizedQuery = normalizeChartSearchText(query);

  if (normalizedQuery.isEmpty) return true;
  final normalizedSearchText = normalizeChartSearchText(searchText);
  return normalizedSearchTextMatchesQuery(
    normalizedSearchText,
    normalizedQuery,
  );
}

bool normalizedSearchTextMatchesQuery(
  String normalizedSearchText,
  String normalizedQuery,
) {
  if (normalizedSearchText.contains(normalizedQuery)) return true;
  if (normalizedSearchText.replaceAll(' ', '').contains(
        normalizedQuery.replaceAll(' ', ''),
      )) {
    return true;
  }

  final tokens = normalizedQuery
      .split(RegExp(r'\s+'))
      .where((token) => token.isNotEmpty)
      .toList();

  return tokens.isNotEmpty && tokens.every(normalizedSearchText.contains);
}

bool matchesAnySearchToken(String searchText, String query) {
  final normalizedSearchText = normalizeChartSearchText(searchText);
  return normalizedSearchTextMatchesAnyToken(
    normalizedSearchText,
    normalizeChartSearchText(query),
  );
}

bool normalizedSearchTextMatchesAnyToken(
  String normalizedSearchText,
  String normalizedQuery,
) {
  final tokens = normalizedQuery
      .split(RegExp(r'\s+'))
      .where((token) => token.isNotEmpty)
      .toList();

  return tokens.isNotEmpty && tokens.any(normalizedSearchText.contains);
}

String normalizeChartSearchText(String value) {
  return value
      .replaceAllMapped(
        RegExp(r'([a-z])([A-Z])'),
        (match) => '${match.group(1)} ${match.group(2)}',
      )
      .toLowerCase()
      .replaceAll(RegExp(r'[áàâãäåā]'), 'a')
      .replaceAll(RegExp(r'[éèêëē]'), 'e')
      .replaceAll(RegExp(r'[íìîïī]'), 'i')
      .replaceAll(RegExp(r'[óòôõöō]'), 'o')
      .replaceAll(RegExp(r'[úùûüū]'), 'u')
      .replaceAll('ç', 'c')
      .replaceAll('ñ', 'n')
      .replaceAll('ß', 'ss')
      .replaceAll('&', ' and ')
      .replaceAll(RegExp(r'[.,/()_\-:]+'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

List<String> expandedChartSearchQueries(String query) {
  final normalizedQuery = normalizeChartSearchText(query);

  if (normalizedQuery.isEmpty) return const [''];

  final expansions = <String>{normalizedQuery};

  for (final entry in _chartSearchTermExpansions.entries) {
    final key = normalizeChartSearchText(entry.key);

    if (key.isEmpty || !normalizedQuery.contains(key)) continue;

    for (final value in entry.value) {
      final normalizedValue = normalizeChartSearchText(value);

      if (normalizedValue.isNotEmpty) {
        expansions.add(normalizedValue);
        expansions.add(normalizedQuery.replaceAll(key, normalizedValue));
      }
    }
  }

  return expansions.toList(growable: false);
}

bool matchesExpandedChartSearch(String searchText, String query) {
  return expandedChartSearchQueries(query)
      .any((expandedQuery) => matchesSearchQuery(searchText, expandedQuery));
}

bool normalizedSearchTextMatchesExpandedQueries(
  String normalizedSearchText,
  List<String> expandedQueries,
) {
  return expandedQueries.any(
    (expandedQuery) => normalizedSearchTextMatchesQuery(
      normalizedSearchText,
      expandedQuery,
    ),
  );
}

bool matchesAnyExpandedChartSearchToken(String searchText, String query) {
  return expandedChartSearchQueries(query).any(
    (expandedQuery) => matchesAnySearchToken(searchText, expandedQuery),
  );
}

bool normalizedSearchTextMatchesAnyExpandedQueryToken(
  String normalizedSearchText,
  List<String> expandedQueries,
) {
  return expandedQueries.any(
    (expandedQuery) => normalizedSearchTextMatchesAnyToken(
      normalizedSearchText,
      expandedQuery,
    ),
  );
}

String localizedChartKeywordAliasesForText(String value) {
  final normalizedValue = normalizeChartSearchText(value);
  final searchableValue = ' $normalizedValue ';
  final aliases = <String>{};

  for (final entry in _localizedChartKeywordAliases.entries) {
    if (searchableValue.contains(' ${entry.key} ')) {
      aliases.addAll(entry.value);
    }
  }

  return aliases.join(' ');
}

void openChartPage(BuildContext context) {
  if (context.findAncestorWidgetOfExactType<ChartPage>() != null) {
    return;
  }

  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => const ChartPage(),
    ),
  );
}

void openExchangePage(BuildContext context) {
  if (context.findAncestorWidgetOfExactType<ExchangePage>() != null) {
    return;
  }

  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => const ExchangePage(),
    ),
  );
}

void openFearGreedPage(BuildContext context) {
  if (context.findAncestorWidgetOfExactType<FearGreedPage>() != null) {
    return;
  }

  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => const FearGreedPage(),
    ),
  );
}

void goHomeAndScrollTop(BuildContext context) {
  Navigator.popUntil(context, (route) => route.isFirst);

  Future.delayed(const Duration(milliseconds: 80), () {
    final controller = _activeHomeScrollController;

    if (controller == null || !controller.hasClients) return;

    controller.animateTo(
      0,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
    );
  });
}

Widget buildPersistentBottomNav(
  BuildContext context, {
  required NavTab currentTab,
}) {
  final l10n = AppLocalizations.of(context)!;
  final isChart = currentTab == NavTab.chart;
  final isExchange = currentTab == NavTab.exchange;
  final isFearGreed = currentTab == NavTab.fearGreed;
  final isAlert = currentTab == NavTab.alert;
  final isStrategy = currentTab == NavTab.strategy;

  Widget item(
    IconData icon,
    String label,
    bool selected,
    VoidCallback onTap,
    {int badgeCount = 0}
  ) {
    final color = selected ? _blue : Colors.white54;

    return InkWell(
      borderRadius: BorderRadius.circular(13),
      onTap: selected ? null : onTap,
      child: SizedBox(
        width: 48,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(
                  icon,
                  color: color,
                  size: 21,
                ),
                if (badgeCount > 0)
                  Positioned(
                    right: -9,
                    top: -7,
                    child: Container(
                      constraints: const BoxConstraints(
                        minWidth: 15,
                        minHeight: 15,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: const BoxDecoration(
                        color: Colors.redAccent,
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        badgeCount > 99 ? '99+' : '$badgeCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 9,
                fontWeight: selected ? FontWeight.bold : FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  return Container(
    margin: EdgeInsets.zero,
    padding: const EdgeInsets.symmetric(
      horizontal: 6,
      vertical: 7,
    ),
    decoration: BoxDecoration(
      color: const Color(0xF20A1726),
      borderRadius: BorderRadius.zero,
      border: const Border(
        top: BorderSide(color: _cardLine),
      ),
      boxShadow: const [
        BoxShadow(
          color: Colors.black54,
          blurRadius: 18,
          offset: Offset(0, -5),
        ),
      ],
    ),
    child: SafeArea(
      top: false,
      minimum: EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          item(
            Icons.home_rounded,
            l10n.navHome,
            false,
            () {
              goHomeAndScrollTop(context);
            },
          ),
          item(
            Icons.show_chart_rounded,
            l10n.navChart,
            isChart,
            () => openChartPage(context),
          ),
          item(
            Icons.currency_exchange_rounded,
            l10n.navExchange,
            isExchange,
            () => openExchangePage(context),
          ),
          item(
            Icons.speed_rounded,
            l10n.navFearGreed,
            isFearGreed,
            () => openFearGreedPage(context),
          ),
          ValueListenableBuilder<int>(
            valueListenable: alertBadgeCount,
            builder: (context, count, _) {
              return item(
                Icons.notifications_none_rounded,
                l10n.navAlert,
                isAlert,
                () {
                  if (isAlert) return;

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const NotificationHistoryPage(),
                    ),
                  );
                },
                badgeCount: isAlert ? 0 : count,
              );
            },
          ),
          item(
            Icons.rule_rounded,
            l10n.navStrategy,
            isStrategy,
            () {
              if (isStrategy) return;

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const StrategyPage(),
                ),
              );
            },
          ),
        ],
      ),
    ),
  );
}

Widget buildFixedAdBottomBar(Widget nav) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      const StrategyBannerAd(),
      nav,
    ],
  );
}

class FearGreedPage extends StatefulWidget {
  const FearGreedPage({super.key});

  @override
  State<FearGreedPage> createState() => _FearGreedPageState();
}

class _FearGreedPageState extends State<FearGreedPage> {
  FearGreedData? data;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchFearGreed();
  }

  Future<void> fetchFearGreed() async {
    setState(() {
      isLoading = true;
    });

    try {
      final parsed = await fetchFearGreedData();
      await saveCachedFearGreedData(parsed);

      if (!mounted) return;

      setState(() {
        data = parsed;
        isLoading = false;
      });
    } catch (_) {
      final cachedData = await loadCachedFearGreedData();
      if (!mounted) return;

      setState(() {
        data = cachedData;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final score = data?.score ?? 0;
    final color = fearGreedColorForScore(score);

    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        title: Text(l10n.fearGreedTitle),
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: fetchFearGreed,
          ),
          buildLanguageMenuButton(context),
        ],
      ),
      bottomNavigationBar: buildFixedAdBottomBar(
        buildPersistentBottomNav(
          context,
          currentTab: NavTab.fearGreed,
        ),
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : data == null
              ? Center(
                  child: Text(
                    l10n.fearGreedUnavailable,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 14,
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 144),
                  children: [
                    Container(
                      padding: const EdgeInsets.fromLTRB(12, 16, 12, 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF151B24),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: color.withOpacity(0.45),
                        ),
                      ),
                      child: Column(
                        children: [
                          Text(
                            l10n.fearGreedSubtitle,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 10),
                          FearGreedGauge(
                            score: score,
                            color: color,
                            labels: [
                              l10n.fearGreedExtremeFear,
                              l10n.fearGreedFear,
                              l10n.fearGreedNeutral,
                              l10n.fearGreedGreed,
                              l10n.fearGreedExtremeGreed,
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            localizedFearGreedRating(
                              l10n,
                              score,
                            ),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: color,
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          if (data!.updatedAt != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text(
                                DateFormat('yyyy.MM.dd HH:mm')
                                    .format(data!.updatedAt!),
                                style: const TextStyle(
                                  color: Colors.white38,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF111923),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.08),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 4,
                            height: 18,
                            decoration: BoxDecoration(
                              color: color,
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              l10n.fearGreedIndicatorsTitle,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      l10n.fearGreedFaqTitle,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    buildFearGreedInfoCard(
                      l10n.fearGreedWhatTitle,
                      l10n.fearGreedWhatBody,
                    ),
                    buildFearGreedInfoCard(
                      l10n.fearGreedCalculatedTitle,
                      l10n.fearGreedCalculatedBody,
                    ),
                    buildFearGreedInfoCard(
                      l10n.fearGreedFrequencyTitle,
                      l10n.fearGreedFrequencyBody,
                    ),
                    buildFearGreedInfoCard(
                      l10n.fearGreedUseTitle,
                      l10n.fearGreedUseBody,
                    ),
                  ],
                ),
    );
  }

  Widget buildFearGreedInfoCard(
    String title,
    String body,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: const Color(0xFF151B24),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.07),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              height: 1.25,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            body,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
              height: 1.42,
            ),
          ),
        ],
      ),
    );
  }
}

String localizedFearGreedRating(
  AppLocalizations l10n,
  double score,
) {
  if (score <= 25) return l10n.fearGreedExtremeFear;
  if (score <= 45) return l10n.fearGreedFear;
  if (score <= 55) return l10n.fearGreedNeutral;
  if (score <= 75) return l10n.fearGreedGreed;
  return l10n.fearGreedExtremeGreed;
}

String localizedAlertDetailForType(
  AppLocalizations l10n,
  String type,
  String fallback,
) {
  if (type.startsWith('profitTarget')) {
    return fallback;
  }

  switch (type) {
    case 'minus20':
      return '${l10n.minus20ActionText}\n\n${l10n.minus20CashText}';
    case 'minus30':
      return '${l10n.minus30ActionText}\n\n${l10n.minus30BuyRuleText}';
    case 'minus40':
      return '${l10n.minus40ActionText}\n\n${l10n.minus40HoldText}';
    case 'minus50':
      return '${l10n.minus50ActionText}\n\n${l10n.minus50AfterText}';
    case 'recovery20':
    case 'recovery30':
    case 'recovery40':
    case 'recovery50':
      return l10n.alertDetailRecovery;
    case 'high':
      return l10n.alertDetailNewHigh;
    case 'marketOpen':
      return l10n.alertDetailMarketOpen;
    case 'nasdaq200Breakdown':
      return l10n.alertDetailNasdaq200Breakdown;
    case 'nasdaq200Breakout':
    case 'nasdaq200Recovery':
      return l10n.alertDetailNasdaq200Breakout;
    case 'portfolioCashHigh':
      return l10n.alertDetailPortfolioCashHigh;
    case 'portfolioCashLow':
      return l10n.alertDetailPortfolioCashLow;
    case _announcementAlertType:
    case 'notice':
    case 'push':
      return fallback;
    default:
      return fallback;
  }
}

class FearGreedGauge extends StatelessWidget {
  const FearGreedGauge({
    super.key,
    required this.score,
    required this.color,
    required this.labels,
  });

  final double score;
  final Color color;
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 164,
      child: CustomPaint(
        painter: _FearGreedGaugePainter(
          score: score,
          color: color,
          labels: labels,
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.only(top: 58),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  score.toStringAsFixed(0),
                  style: TextStyle(
                    color: color,
                    fontSize: 38,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Text(
                  '/ 100',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FearGreedGaugePainter extends CustomPainter {
  const _FearGreedGaugePainter({
    required this.score,
    required this.color,
    required this.labels,
  });

  final double score;
  final Color color;
  final List<String> labels;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height - 10);
    final radius = math.min(size.width * 0.46, size.height * 0.92);
    final strokeWidth = math.max(26.0, radius * 0.22);
    final rect = Rect.fromCircle(
      center: center,
      radius: radius,
    );
    const startAngle = math.pi;
    const totalAngle = math.pi;
    final bgPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.butt;

    for (var i = 0; i < 5; i++) {
      final startValue = _fearGreedZoneBounds[i];
      final endValue = _fearGreedZoneBounds[i + 1];
      final segmentStartAngle = startAngle + totalAngle * (startValue / 100);
      final segmentSweep = totalAngle * ((endValue - startValue) / 100);

      bgPaint.color = i == scoreSegment
          ? color.withOpacity(0.35)
          : Colors.white.withOpacity(0.075);
      canvas.drawArc(
        rect,
        segmentStartAngle + 0.015,
        segmentSweep - 0.03,
        false,
        bgPaint,
      );
    }

    for (final value in [0, 25, 50, 75, 100]) {
      final angle = startAngle + totalAngle * (value / 100);
      _drawText(
        canvas,
        '$value',
        Offset(
          center.dx + math.cos(angle) * (radius - strokeWidth * 1.05),
          center.dy + math.sin(angle) * (radius - strokeWidth * 1.05),
        ),
        11,
        Colors.white54,
        FontWeight.w600,
      );
    }

    for (var i = 0; i < labels.length && i < 5; i++) {
      final midpoint =
          (_fearGreedZoneBounds[i] + _fearGreedZoneBounds[i + 1]) / 2;
      final angle = startAngle + totalAngle * (midpoint / 100);
      _drawText(
        canvas,
        labels[i],
        Offset(
          center.dx + math.cos(angle) * (radius + strokeWidth * 0.05),
          center.dy + math.sin(angle) * (radius + strokeWidth * 0.05),
        ),
        labels[i].length > 9 ? 8.5 : 10,
        i == scoreSegment ? color : Colors.white60,
        FontWeight.bold,
      );
    }

    final clampedScore = score.clamp(0, 100).toDouble();
    final needleAngle = startAngle + totalAngle * (clampedScore / 100);
    final needleEnd = Offset(
      center.dx + math.cos(needleAngle) * (radius - strokeWidth * 0.55),
      center.dy + math.sin(needleAngle) * (radius - strokeWidth * 0.55),
    );
    final needlePaint = Paint()
      ..color = color
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(center, needleEnd, needlePaint);
    canvas.drawCircle(
      center,
      8,
      Paint()..color = color,
    );
  }

  int get scoreSegment {
    return fearGreedSegmentForScore(score);
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset center,
    double fontSize,
    Color color,
    FontWeight weight,
  ) {
    final painter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: fontSize,
          fontWeight: weight,
          height: 1.05,
        ),
      ),
      maxLines: 2,
      textAlign: TextAlign.center,
      textDirection: ui.TextDirection.ltr,
    )..layout(maxWidth: 58);

    painter.paint(
      canvas,
      Offset(
        center.dx - painter.width / 2,
        center.dy - painter.height / 2,
      ),
    );
  }

  @override
  bool shouldRepaint(covariant _FearGreedGaugePainter oldDelegate) {
    return oldDelegate.score != score ||
        oldDelegate.color != color ||
        oldDelegate.labels != labels;
  }
}

class NotificationHistoryPage extends StatefulWidget {
  const NotificationHistoryPage({
    super.key,
    this.items,
  });

  final List<AlertHistoryItem>? items;

  @override
  State<NotificationHistoryPage> createState() =>
      _NotificationHistoryPageState();
}

class _NotificationHistoryPageState extends State<NotificationHistoryPage> {
  List<AlertHistoryItem> items = [];

  @override
  void initState() {
    super.initState();
    clearAlertBadgeCount();

    if (widget.items != null) {
      items = sortAlertHistoryItems(widget.items!);
    } else {
      loadItems();
    }
  }

  Future<void> loadItems() async {
    final prefs = await SharedPreferences.getInstance();
    final savedItems = prefs.getStringList('alertHistory') ?? [];

    if (!mounted) return;

    setState(() {
      items = sortAlertHistoryItems(
        savedItems.map(AlertHistoryItem.fromJson),
      );
    });
  }

  Color colorForType(String type) {
    if (type.startsWith('profitTarget')) {
      return Colors.lightGreenAccent;
    }

    switch (type) {
      case _tradingViewInstallAlertType:
        return _cyan;
      case 'minus20':
        return Colors.green;
      case 'minus30':
        return Colors.orange;
      case 'minus40':
        return Colors.red;
      case 'minus50':
        return Colors.purple;
      case 'recovery20':
      case 'recovery30':
      case 'recovery40':
      case 'recovery50':
        return _cyan;
      case 'high':
        return Colors.lightGreenAccent;
      case 'marketOpen':
        return _blue;
      case 'nasdaq200Breakdown':
      case 'portfolioCashLow':
        return Colors.redAccent;
      case 'nasdaq200Breakout':
      case 'nasdaq200Recovery':
      case 'portfolioCashHigh':
        return _cyan;
      case _announcementAlertType:
      case 'notice':
      case 'push':
        return Colors.amberAccent;
      default:
        return Colors.blueGrey;
    }
  }

  Widget? pageForType(String type) {
    switch (type) {
      case 'minus20':
        return const Minus20Page();
      case 'minus30':
        return const Minus30Page();
      case 'minus40':
        return const Minus40Page();
      case 'minus50':
        return const Minus50Page();
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        toolbarHeight: 48,
        title: Text(
          l10n.navAlert,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        actions: [
          buildLanguageMenuButton(context, iconSize: 20),
        ],
      ),
      bottomNavigationBar: buildFixedAdBottomBar(
        buildPersistentBottomNav(
          context,
          currentTab: NavTab.alert,
        ),
      ),
      body: items.isEmpty
          ? Center(
              child: Text(
                l10n.buySignalMessage,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white54,
                  fontSize: 14,
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(18, 6, 18, 144),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (context, index) {
                final item = items[index];
                final color = colorForType(item.type);
                final isAnnouncement = isAnnouncementAlertType(item.type);
                final isInstallItem =
                    item.type == _tradingViewInstallAlertType;
                final backgroundColor = Color.alphaBlend(
                  color.withOpacity(0.08),
                  const Color(0xFF151B24),
                );
                final dateText = DateFormat('yyyy.MM.dd HH:mm').format(
                  item.createdAt,
                );

                return InkWell(
                  borderRadius: BorderRadius.circular(9),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AlertDetailPage(item: item),
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: backgroundColor,
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(
                        color: color.withOpacity(0.35),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: isAnnouncement || isInstallItem ? 28 : 3,
                          height: 32,
                          decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(
                              isAnnouncement || isInstallItem ? 9 : 6,
                            ),
                          ),
                          child: isAnnouncement || isInstallItem
                              ? Icon(
                                  isInstallItem
                                      ? Icons.install_mobile_rounded
                                      : Icons.campaign_rounded,
                                  color: Color(0xFF0D1117),
                                  size: 17,
                                )
                              : null,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.message,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Color.alphaBlend(
                                    color.withOpacity(0.18),
                                    Colors.white,
                                  ),
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  height: 1.15,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                isAnnouncement
                                    ? '${l10n.alertAnnouncementTitle} · $dateText'
                                    : isInstallItem
                                        ? 'TradingView · Play Store'
                                    : dateText,
                                style: TextStyle(
                                  color: isAnnouncement || isInstallItem
                                      ? color.withOpacity(0.78)
                                      : Colors.white54,
                                  fontSize: 10,
                                  fontWeight: isAnnouncement || isInstallItem
                                      ? FontWeight.w700
                                      : FontWeight.normal,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.chevron_right_rounded,
                          color: Colors.white38,
                          size: 18,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class AlertDetailPage extends StatelessWidget {
  const AlertDetailPage({
    super.key,
    required this.item,
  });

  final AlertHistoryItem item;

  Color colorForType(String type) {
    if (type.startsWith('profitTarget')) {
      return Colors.lightGreenAccent;
    }

    switch (type) {
      case _tradingViewInstallAlertType:
        return _cyan;
      case 'minus20':
        return Colors.green;
      case 'minus30':
        return Colors.orange;
      case 'minus40':
        return Colors.red;
      case 'minus50':
        return Colors.purple;
      case 'recovery20':
      case 'recovery30':
      case 'recovery40':
      case 'recovery50':
        return _cyan;
      case 'high':
        return Colors.lightGreenAccent;
      case 'marketOpen':
        return _blue;
      case 'nasdaq200Breakdown':
      case 'portfolioCashLow':
        return Colors.redAccent;
      case 'nasdaq200Breakout':
      case 'nasdaq200Recovery':
      case 'portfolioCashHigh':
        return _cyan;
      case _announcementAlertType:
      case 'notice':
      case 'push':
        return Colors.amberAccent;
      default:
        return Colors.blueGrey;
    }
  }

  Widget? pageForType(String type) {
    switch (type) {
      case 'minus20':
        return const Minus20Page();
      case 'minus30':
        return const Minus30Page();
      case 'minus40':
        return const Minus40Page();
      case 'minus50':
        return const Minus50Page();
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final color = colorForType(item.type);
    final targetPage = pageForType(item.type);
    final detail = item.detail.trim().isEmpty
        ? localizedAlertDetailForType(l10n, item.type, item.message)
        : item.detail.trim();
    final linkUri = alertLinkUri(item, detail);
    final dateText = DateFormat('yyyy.MM.dd HH:mm').format(item.createdAt);
    final isAnnouncement = isAnnouncementAlertType(item.type);
    final isInstallItem = item.type == _tradingViewInstallAlertType;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        toolbarHeight: 48,
        title: Text(
          l10n.alertDetailTitle,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        actions: [
          buildLanguageMenuButton(context, iconSize: 20),
        ],
      ),
      bottomNavigationBar: buildFixedAdBottomBar(
        buildPersistentBottomNav(
          context,
          currentTab: NavTab.alert,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 144),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 15, 16, 16),
            decoration: BoxDecoration(
              color: const Color(0xFF151B24),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.42)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: isAnnouncement || isInstallItem ? 38 : 4,
                      height: 42,
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(
                          isAnnouncement || isInstallItem ? 12 : 99,
                        ),
                      ),
                      child: isAnnouncement || isInstallItem
                          ? Icon(
                              isInstallItem
                                  ? Icons.install_mobile_rounded
                                  : Icons.campaign_rounded,
                              color: Color(0xFF0D1117),
                              size: 22,
                            )
                          : null,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.message,
                            style: TextStyle(
                              color: color,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              height: 1.25,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            isAnnouncement
                                ? '${l10n.alertAnnouncementTitle} · $dateText'
                                : isInstallItem
                                    ? 'TradingView · Play Store'
                                : dateText,
                            style: TextStyle(
                              color: isAnnouncement || isInstallItem
                                  ? color.withOpacity(0.75)
                                  : const Color(0x73FFFFFF),
                              fontSize: 11,
                              fontWeight: isAnnouncement || isInstallItem
                                  ? FontWeight.w700
                                  : FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  detail,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                    height: 1.5,
                  ),
                ),
                if (linkUri != null &&
                    linkUri.hasScheme &&
                    (linkUri.scheme == 'http' || linkUri.scheme == 'https')) ...[
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 42,
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: color,
                        side: BorderSide(color: color.withOpacity(0.45)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () async {
                        await launchUrl(
                          linkUri!,
                          mode: LaunchMode.externalApplication,
                        );
                      },
                      icon: const Icon(Icons.open_in_new_rounded, size: 17),
                      label: Text(
                        l10n.alertDetailOpenLink,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (targetPage != null) ...[
            const SizedBox(height: 10),
            SizedBox(
              height: 44,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: color.withOpacity(0.18),
                  foregroundColor: color,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: color.withOpacity(0.35)),
                  ),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => targetPage,
                    ),
                  );
                },
                icon: const Icon(Icons.rule_rounded, size: 18),
                label: Text(
                  l10n.alertDetailOpenStrategy,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class ChartListItem {
  const ChartListItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.symbolPath,
    required this.color,
    required this.icon,
  });

  final String id;
  final String title;
  final String subtitle;
  final String symbolPath;
  final Color color;
  final IconData icon;
}

class ExchangeListItem {
  const ExchangeListItem({
    required this.id,
    required this.symbolPath,
    required this.color,
    required this.icon,
  });

  final String id;
  final String symbolPath;
  final Color color;
  final IconData icon;
}

Widget buildTickerBadge(
  String label,
  Color color,
) {
  return Container(
    width: 32,
    height: 32,
    padding: const EdgeInsets.symmetric(horizontal: 3),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(8),
      color: color.withOpacity(0.12),
      border: Border.all(
        color: color.withOpacity(0.35),
      ),
    ),
    alignment: Alignment.center,
    child: FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(
        label,
        maxLines: 1,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 0,
        ),
      ),
    ),
  );
}

ChartListItem popularStockChartItem(
  String ticker,
  String name,
  String exchange,
  Color color,
) {
  final id = 'stock${ticker.replaceAll(RegExp(r'[^A-Za-z0-9]'), '')}';

  return ChartListItem(
    id: id,
    title: '$ticker  $name',
    subtitle: '$exchange:$ticker',
    symbolPath: '$exchange-${ticker.replaceAll('.', '.')}',
    color: color,
    icon: Icons.trending_up_rounded,
  );
}

ChartListItem popularEtfChartItem(
  String ticker,
  String name,
  String exchange,
  Color color,
) {
  return ChartListItem(
    id: 'etf$ticker',
    title: '$ticker  $name',
    subtitle: '$exchange:$ticker',
    symbolPath: '$exchange-$ticker',
    color: color,
    icon: Icons.pie_chart_rounded,
  );
}

ChartListItem commodityChartItem(
  String id,
  String title,
  String subtitle,
  String symbolPath,
  Color color,
) {
  return ChartListItem(
    id: 'commodity$id',
    title: title,
    subtitle: subtitle,
    symbolPath: symbolPath,
    color: color,
    icon: Icons.grain_rounded,
  );
}

ChartListItem globalMegaCapChartItem(
  String id,
  String title,
  String subtitle,
  String symbolPath,
  Color color,
) {
  return ChartListItem(
    id: 'global$id',
    title: title,
    subtitle: subtitle,
    symbolPath: symbolPath,
    color: color,
    icon: Icons.public_rounded,
  );
}

ChartListItem countryLargeCapChartItem(
  String id,
  String title,
  String subtitle,
  String symbolPath,
  Color color,
) {
  return ChartListItem(
    id: 'country$id',
    title: title,
    subtitle: subtitle,
    symbolPath: symbolPath,
    color: color,
    icon: Icons.business_center_rounded,
  );
}

ChartListItem cryptoChartItem(
  String ticker,
  String name,
  Color color,
) {
  return ChartListItem(
    id: 'crypto$ticker',
    title: '$ticker  $name',
    subtitle: 'CRYPTO:$ticker',
    symbolPath: 'CRYPTO-${ticker}USD',
    color: color,
    icon: Icons.currency_bitcoin_rounded,
  );
}

ChartListItem macroChartItem(
  String id,
  String title,
  String subtitle,
  String symbolPath,
  Color color,
) {
  return ChartListItem(
    id: 'macro$id',
    title: title,
    subtitle: subtitle,
    symbolPath: symbolPath,
    color: color,
    icon: Icons.query_stats_rounded,
  );
}

const Map<String, String> _chartSearchAliases = {
  'AAPL': '애플 アップル 苹果 蘋果 Эпл',
  'MSFT': '마이크로소프트 マイクロソフト 微软 微軟 Майкрософт',
  'NVDA': '엔비디아 エヌビディア 英伟达 輝達 Нвидиа',
  'AMZN': '아마존 アマゾン 亚马逊 亞馬遜 Амазон',
  'GOOGL': '구글 알파벳 グーグル アルファベット 谷歌 字母表 Гугл Алфавит',
  'META': '메타 페이스북 メタ フェイスブック 元宇宙 脸书 臉書 Мета Фейсбук',
  'TSLA': '테슬라 テスラ 特斯拉 Тесла',
  'AVGO': '브로드컴 ブロードコム 博通 Бродком',
  'BRK.B': '버크셔 해서웨이 バークシャー 伯克希尔 波克夏 Беркшир',
  'LLY': '일라이 릴리 イーライリリー 礼来 禮來 Эли Лилли',
  'JPM': '제이피모건 JP모건 JPモルガン 摩根大通 Джей피 Морган',
  'V': '비자 ビザ 维萨 維薩 Виза',
  'UNH': '유나이티드헬스 ユナイテッドヘルス 联合健康 聯合健康 Юнайтедヘルス',
  'XOM': '엑슨모빌 エクソンモービル 埃克森美孚 Эксон',
  'MA': '마스터카드 マスターカード 万事达 萬事達 Мастеркард',
  'COST': '코스트코 コストコ 好市多 Костко',
  'HD': '홈디포 ホームデポ 家得宝 家得寶 Хоум Депо',
  'NFLX': '넷플릭스 ネットフリックス 奈飞 奈飛 Нетфликс',
  'PG': '피앤지 P&G プロクター 宝洁 寶潔 Проктер',
  'JNJ': '존슨앤존슨 ジョンソン 强生 強生 Джонсон',
  'WMT': '월마트 ウォルマート 沃尔玛 沃爾瑪 Волмарт',
  'ABBV': '애브비 アッヴィ 艾伯维 艾伯維 Эббви',
  'BAC': '뱅크오브아메리카 バンクオブアメリカ 美国银行 美國銀行 Банк Америка',
  'CRM': '세일즈포스 セールスフォース 赛富时 賽富時 Сейл즈форс',
  'ORCL': '오라클 オラクル 甲骨文 Оракл',
  'KO': '코카콜라 コカコーラ 可口可乐 可口可樂 Кока Кола',
  'CVX': '쉐브론 셰브론 シェブロン 雪佛龙 雪佛龍 Шеврон',
  'AMD': '에이엠디 AMD エーエムディ 超微 半导体 半導體',
  'MRK': '머크 メルク 默克 Мерк',
  'CSCO': '시스코 シスコ 思科 Циско',
  'WFC': '웰스파고 ウェルズファーゴ 富国银行 富國銀行 Уэллс Фарго',
  'MCD': '맥도날드 マクドナルド 麦当劳 麥當勞 Макдональдс',
  'PEP': '펩시 펩시코 ペプシ 百事 Пепси',
  'ADBE': '어도비 アドビ 奥多比 奧多比 Адобе',
  'IBM': '아이비엠 IBM アイビーエム 国际商业机器 國際商業機器',
  'QCOM': '퀄컴 クアルコム 高通 Куалком',
  'CAT': '캐터필러 キャタピラー 卡特彼勒 Катерпиллар',
  'DIS': '디즈니 ディズニー 迪士尼 Дисней',
  'UBER': '우버 ウーバー 优步 優步 Убер',
  'SBUX': '스타벅스 スターバックス 星巴克 Старбакс',
  'PLTR': '팔란티어 パランティア 帕兰提尔 帕蘭提爾 Палантир',
  'SHOP': '쇼피파이 ショッピファイ Shopify ショピファイ',
  'COIN': '코인베이스 コインベース Coinbase 加密货币 加密貨幣',
  'MSTR': '마이크로스트래티지 マイクロストラテジー 微策略 Микростратеги',
  'HOOD': '로빈후드 ロビンフッド Robinhood 罗宾汉 羅賓漢',
  'BTC': '비트코인 ビットコイン 比特币 比特幣 Биткоин',
};

const Map<String, List<String>> _chartSearchTermExpansions = {
  '애플': ['apple', 'aapl'],
  'アップル': ['apple', 'aapl'],
  '苹果': ['apple', 'aapl'],
  '蘋果': ['apple', 'aapl'],
  'манзана': ['apple', 'aapl'],
  '마이크로소프트': ['microsoft', 'msft'],
  'マイクロソフト': ['microsoft', 'msft'],
  '微软': ['microsoft', 'msft'],
  '微軟': ['microsoft', 'msft'],
  'майкрософт': ['microsoft', 'msft'],
  '엔비디아': ['nvidia', 'nvda'],
  'エヌビディア': ['nvidia', 'nvda'],
  '英伟达': ['nvidia', 'nvda'],
  '輝達': ['nvidia', 'nvda'],
  '아마존': ['amazon', 'amzn'],
  'アマゾン': ['amazon', 'amzn'],
  '亚马逊': ['amazon', 'amzn'],
  '亞馬遜': ['amazon', 'amzn'],
  '구글': ['google', 'alphabet', 'googl', 'goog'],
  '알파벳': ['alphabet', 'google', 'googl', 'goog'],
  'グーグル': ['google', 'alphabet', 'googl', 'goog'],
  '谷歌': ['google', 'alphabet', 'googl', 'goog'],
  '메타': ['meta', 'facebook'],
  '페이스북': ['meta', 'facebook'],
  'フェイスブック': ['meta', 'facebook'],
  '脸书': ['meta', 'facebook'],
  '臉書': ['meta', 'facebook'],
  '테슬라': ['tesla', 'tsla'],
  'テスラ': ['tesla', 'tsla'],
  '特斯拉': ['tesla', 'tsla'],
  '브로드컴': ['broadcom', 'avgo'],
  '博通': ['broadcom', 'avgo'],
  '버크셔': ['berkshire', 'brk b'],
  '해서웨이': ['hathaway', 'brk b'],
  '伯克希尔': ['berkshire', 'brk b'],
  '波克夏': ['berkshire', 'brk b'],
  '일라이릴리': ['eli lilly', 'lly'],
  '릴리': ['eli lilly', 'lly'],
  '礼来': ['eli lilly', 'lly'],
  '禮來': ['eli lilly', 'lly'],
  '제이피모건': ['jpmorgan', 'jpm'],
  'jp모건': ['jpmorgan', 'jpm'],
  '摩根大通': ['jpmorgan', 'jpm'],
  '비자': ['visa', 'v'],
  '维萨': ['visa', 'v'],
  '維薩': ['visa', 'v'],
  '마스터카드': ['mastercard', 'ma'],
  '万事达': ['mastercard', 'ma'],
  '萬事達': ['mastercard', 'ma'],
  '유나이티드헬스': ['unitedhealth', 'unh'],
  '联合健康': ['unitedhealth', 'unh'],
  '聯合健康': ['unitedhealth', 'unh'],
  '엑슨모빌': ['exxon mobil', 'xom'],
  '엑손모빌': ['exxon mobil', 'xom'],
  '埃克森美孚': ['exxon mobil', 'xom'],
  '코스트코': ['costco', 'cost'],
  '好市多': ['costco', 'cost'],
  '홈디포': ['home depot', 'hd'],
  '家得宝': ['home depot', 'hd'],
  '家得寶': ['home depot', 'hd'],
  '넷플릭스': ['netflix', 'nflx'],
  '奈飞': ['netflix', 'nflx'],
  '奈飛': ['netflix', 'nflx'],
  '월마트': ['walmart', 'wmt'],
  '沃尔玛': ['walmart', 'wmt'],
  '沃爾瑪': ['walmart', 'wmt'],
  '오라클': ['oracle', 'orcl'],
  '甲骨文': ['oracle', 'orcl'],
  '코카콜라': ['coca cola', 'ko'],
  '可口可乐': ['coca cola', 'ko'],
  '可口可樂': ['coca cola', 'ko'],
  '셰브론': ['chevron', 'cvx'],
  '쉐브론': ['chevron', 'cvx'],
  '雪佛龙': ['chevron', 'cvx'],
  '에이엠디': ['amd'],
  '超微': ['amd'],
  '시스코': ['cisco', 'csco'],
  '思科': ['cisco', 'csco'],
  '맥도날드': ['mcdonalds', 'mcd'],
  '麦当劳': ['mcdonalds', 'mcd'],
  '펩시': ['pepsico', 'pep'],
  '百事': ['pepsico', 'pep'],
  '디즈니': ['disney', 'dis'],
  '迪士尼': ['disney', 'dis'],
  '우버': ['uber'],
  '优步': ['uber'],
  '優步': ['uber'],
  '스타벅스': ['starbucks', 'sbux'],
  '星巴克': ['starbucks', 'sbux'],
  '팔란티어': ['palantir', 'pltr'],
  '帕兰提尔': ['palantir', 'pltr'],
  '帕蘭提爾': ['palantir', 'pltr'],
  '쇼피파이': ['shopify', 'shop'],
  '코인베이스': ['coinbase', 'coin'],
  '로빈후드': ['robinhood', 'hood'],
  '삼성전자': ['samsung electronics', '005930'],
  '삼성': ['samsung electronics', '005930'],
  'サムスン': ['samsung electronics', '005930'],
  '三星电子': ['samsung electronics', '005930'],
  '三星電子': ['samsung electronics', '005930'],
  '하이닉스': ['sk hynix', '000660'],
  'sk하이닉스': ['sk hynix', '000660'],
  '海力士': ['sk hynix', '000660'],
  '현대차': ['hyundai motor', '005380'],
  '현대자동차': ['hyundai motor', '005380'],
  '现代': ['hyundai motor', '005380'],
  '現代': ['hyundai motor', '005380'],
  '네이버': ['naver', '035420'],
  '카카오': ['kakao', '035720'],
  'lg화학': ['lg chem', '051910'],
  '엘지화학': ['lg chem', '051910'],
  'lg에너지솔루션': ['lg energy solution', '373220'],
  '엘지에너지솔루션': ['lg energy solution', '373220'],
  'tsmc': ['taiwan semiconductor', 'tsm'],
  '台積電': ['tsmc', 'taiwan semiconductor', 'tsm'],
  '台积电': ['tsmc', 'taiwan semiconductor', 'tsm'],
  '티에스엠씨': ['tsmc', 'taiwan semiconductor', 'tsm'],
  '텐센트': ['tencent', '0700'],
  '腾讯': ['tencent', '0700'],
  '騰訊': ['tencent', '0700'],
  '알리바바': ['alibaba', '9988', 'baba'],
  '阿里巴巴': ['alibaba', '9988', 'baba'],
  '토요타': ['toyota', '7203'],
  '도요타': ['toyota', '7203'],
  '丰田': ['toyota', '7203'],
  '豐田': ['toyota', '7203'],
  '소니': ['sony', '6758'],
  '索尼': ['sony', '6758'],
  '소프트뱅크': ['softbank', '9984'],
  'ソフトバンク': ['softbank', '9984'],
  '비야디': ['byd', '1211'],
  '比亚迪': ['byd', '1211'],
  '比亞迪': ['byd', '1211'],
  '아이온큐': ['ionq', 'quantum computing'],
  '이온큐': ['ionq', 'quantum computing'],
  '퀀텀컴퓨팅': ['quantum computing', 'ionq', 'rgti', 'qubt', 'qbts', 'qtum'],
  '양자컴퓨터': ['quantum computing'],
  '양자컴퓨팅': ['quantum computing'],
  '量子计算': ['quantum computing'],
  '量子運算': ['quantum computing'],
  'computación cuántica': ['quantum computing'],
  'computação quântica': ['quantum computing'],
  'informatique quantique': ['quantum computing'],
  'quantencomputing': ['quantum computing'],
  'квантовые вычисления': ['quantum computing'],
  '반도체': ['semiconductor'],
  '半導体': ['semiconductor'],
  '半导体': ['semiconductor'],
  '半導體': ['semiconductor'],
  'semiconductor': ['semiconductor'],
  'semiconductores': ['semiconductor'],
  'semi condutores': ['semiconductor'],
  'semi conducteurs': ['semiconductor'],
  'halbleiter': ['semiconductor'],
  'полупроводник': ['semiconductor'],
  '전기차': ['ev', 'electric vehicle'],
  '전기 자동차': ['ev', 'electric vehicle'],
  '電気自動車': ['ev', 'electric vehicle'],
  '电动车': ['ev', 'electric vehicle'],
  '電動車': ['ev', 'electric vehicle'],
  'coche eléctrico': ['ev', 'electric vehicle'],
  'carro elétrico': ['ev', 'electric vehicle'],
  'voiture électrique': ['ev', 'electric vehicle'],
  'elektroauto': ['ev', 'electric vehicle'],
  'электромобиль': ['ev', 'electric vehicle'],
  '은행': ['bank'],
  '銀行': ['bank'],
  '银行': ['bank'],
  'banco': ['bank'],
  'banque': ['bank'],
  'банк': ['bank'],
  '보험': ['insurance'],
  '保险': ['insurance'],
  '保險': ['insurance'],
  'seguro': ['insurance'],
  'assurance': ['insurance'],
  'versicherung': ['insurance'],
  'страхование': ['insurance'],
  '제약': ['pharma', 'pharmaceutical'],
  '医薬': ['pharma', 'pharmaceutical'],
  '制药': ['pharma', 'pharmaceutical'],
  '製藥': ['pharma', 'pharmaceutical'],
  'farmacéutica': ['pharma', 'pharmaceutical'],
  'farmaceutica': ['pharma', 'pharmaceutical'],
  'pharmaceutique': ['pharma', 'pharmaceutical'],
  'pharmazeutik': ['pharma', 'pharmaceutical'],
  'фармацевтика': ['pharma', 'pharmaceutical'],
  '바이오': ['biotech', 'bio'],
  '生物科技': ['biotech', 'bio'],
  'biotecnología': ['biotech', 'bio'],
  'biotecnologia': ['biotech', 'bio'],
  'biotechnologie': ['biotech', 'bio'],
  'биотехнологии': ['biotech', 'bio'],
  '에너지': ['energy'],
  'エネルギー': ['energy'],
  '能源': ['energy'],
  'energía': ['energy'],
  'energia': ['energy'],
  'énergie': ['energy'],
  'энергия': ['energy'],
  '석유': ['oil', 'crude'],
  '원유': ['oil', 'crude'],
  '石油': ['oil', 'crude'],
  'petróleo': ['oil', 'crude'],
  'petroleo': ['oil', 'crude'],
  'pétrole': ['oil', 'crude'],
  'нефть': ['oil', 'crude'],
  '천연가스': ['natural gas'],
  '天然气': ['natural gas'],
  '天然氣': ['natural gas'],
  'gas natural': ['natural gas'],
  'gaz naturel': ['natural gas'],
  'erdgas': ['natural gas'],
  'природный газ': ['natural gas'],
  '금': ['gold'],
  '골드': ['gold'],
  'ゴールド': ['gold'],
  '黄金': ['gold'],
  '黃金': ['gold'],
  'oro': ['gold'],
  'ouro': ['gold'],
  'золото': ['gold'],
  '은': ['silver'],
  '실버': ['silver'],
  'シルバー': ['silver'],
  '白银': ['silver'],
  '白銀': ['silver'],
  'plata': ['silver'],
  'prata': ['silver'],
  'argent': ['silver'],
  'серебро': ['silver'],
  '구리': ['copper'],
  '동': ['copper'],
  '銅': ['copper'],
  '铜': ['copper'],
  'cobre': ['copper'],
  'cuivre': ['copper'],
  'медь': ['copper'],
  'kupfer': ['copper'],
  '비트코인': ['bitcoin', 'btc'],
  'ビットコイン': ['bitcoin', 'btc'],
  '比特币': ['bitcoin', 'btc'],
  '比特幣': ['bitcoin', 'btc'],
  'биткоин': ['bitcoin', 'btc'],
  '이더리움': ['ethereum', 'eth'],
  'イーサリアム': ['ethereum', 'eth'],
  '以太坊': ['ethereum', 'eth'],
  'эфир': ['ethereum', 'eth'],
  '나스닥': ['nasdaq'],
  'ナスダック': ['nasdaq'],
  '纳斯达克': ['nasdaq'],
  '納斯達克': ['nasdaq'],
  '코스피': ['kospi'],
  '니케이': ['nikkei'],
  '닛케이': ['nikkei'],
  '日経': ['nikkei'],
  '중국지수': ['sse composite', 'china'],
  '상해종합': ['sse composite', 'china'],
  '上海综合': ['sse composite', 'china'],
  '上海綜合': ['sse composite', 'china'],
  '대만지수': ['taiex', 'taiwan'],
  '독일지수': ['dax', 'germany'],
  '프랑스지수': ['cac', 'france'],
  '스페인지수': ['ibex', 'spain'],
  '포르투갈지수': ['psi', 'portugal'],
  '러시아지수': ['moex', 'russia'],
  '아이셰어즈': ['ishares'],
  'アイシェアーズ': ['ishares'],
  '安硕': ['ishares'],
  '安碩': ['ishares'],
  '뱅가드': ['vanguard'],
  'バンガード': ['vanguard'],
  '先锋': ['vanguard'],
  '先鋒': ['vanguard'],
  '프로셰어즈': ['proshares'],
  'プロシェアーズ': ['proshares'],
  '디렉시온': ['direxion'],
  'ディレクション': ['direxion'],
  '반에크': ['vaneck'],
  'ヴァンエック': ['vaneck'],
  '아크': ['ark'],
  'アーク': ['ark'],
  '슈왑': ['schwab'],
  'シュワブ': ['schwab'],
  '스파이더': ['spdr'],
  '스테이트스트리트': ['spdr', 'state street'],
  '에스피디알': ['spdr'],
};

const Map<String, List<String>> _localizedChartKeywordAliases = {
  'technology': ['기술', '테크', 'テクノロジー', '科技', 'tecnologia', 'technologie', 'Technologie', 'технологии'],
  'software': ['소프트웨어', 'ソフトウェア', '软件', '軟體', 'software', 'logiciel', 'Software', 'программное обеспечение'],
  'cloud': ['클라우드', 'クラウド', '云', '雲', 'nube', 'nuvem', 'nuage', 'Cloud', 'облако'],
  'data': ['데이터', 'データ', '数据', '數據', 'datos', 'dados', 'données', 'Daten', 'данные'],
  'artificial intelligence': ['인공지능', '人工知能', '人工智能', 'ia', 'inteligencia artificial', 'intelligence artificielle', 'künstliche intelligenz', 'искусственный интеллект'],
  'ai': ['인공지능', '人工知能', '人工智能', 'ia', 'inteligencia artificial', 'intelligence artificielle', 'ki', 'ии'],
  'semiconductor': ['반도체', '半導体', '半导体', '半導體', 'semiconductor', 'semiconductores', 'semi condutores', 'semi-conducteur', 'Halbleiter', 'полупроводник'],
  'chip': ['반도체', '칩', 'チップ', '芯片', '晶片', 'chip', 'puce', 'Halbleiter'],
  'network': ['네트워크', 'ネットワーク', '网络', '網路', 'red', 'rede', 'réseau', 'Netzwerk', 'сеть'],
  'cybersecurity': ['사이버보안', '보안', 'サイバーセキュリティ', '网络安全', '網路安全', 'ciberseguridad', 'ciberseguranca', 'cybersécurité', 'Cybersicherheit', 'кибербезопасность'],
  'security': ['보안', 'セキュリティ', '安全', 'seguridad', 'segurança', 'sécurité', 'Sicherheit', 'безопасность'],
  'communication': ['통신', '通信', 'telecomunicaciones', 'telecomunicações', 'télécom', 'Telekommunikation', 'связь'],
  'telecom': ['통신', '通信', 'telecomunicaciones', 'telecomunicações', 'télécom', 'Telekommunikation', 'связь'],
  'media': ['미디어', 'メディア', '媒体', 'medios', 'mídia', 'médias', 'Medien', 'медиа'],
  'streaming': ['스트리밍', '動画配信', '流媒体', '串流', 'streaming', 'transmisión', 'streamen'],
  'game': ['게임', 'ゲーム', '游戏', '遊戲', 'juego', 'jogo', 'jeu', 'Spiel', 'игра'],
  'gaming': ['게임', 'ゲーム', '游戏', '遊戲', 'juego', 'jogo', 'jeu', 'Spiel', 'игры'],
  'ecommerce': ['이커머스', '전자상거래', '電子商取引', '电子商务', '電子商務', 'comercio electrónico', 'comércio eletrônico', 'commerce électronique', 'E-Commerce', 'электронная коммерция'],
  'commerce': ['상거래', '商取引', '商务', '商務', 'comercio', 'comércio', 'commerce', 'Handel', 'торговля'],
  'retail': ['리테일', '소매', '小売', '零售', 'minorista', 'varejo', 'détail', 'Einzelhandel', 'розница'],
  'consumer': ['소비재', '소비자', '消費者', '消费', '消費', 'consumo', 'consommateur', 'Verbraucher', 'потребитель'],
  'beverage': ['음료', '飲料', '饮料', 'bebida', 'boisson', 'Getränk', 'напитки'],
  'food': ['식품', '음식', '食品', '食物', 'alimentos', 'comida', 'nourriture', 'Lebensmittel', 'еда'],
  'restaurant': ['레스토랑', '음식점', 'レストラン', '餐厅', '餐廳', 'restaurante', 'restaurant', 'ресторан'],
  'travel': ['여행', '旅行', '旅游', '旅遊', 'viaje', 'viagem', 'voyage', 'Reise', 'путешествие'],
  'hotel': ['호텔', 'ホテル', '酒店', '旅館', 'hotel', 'hôtel', 'отель'],
  'bank': ['은행', '銀行', '银行', 'banco', 'banque', 'Bank', 'банк'],
  'financial': ['금융', '金融', 'financiero', 'financeiro', 'financier', 'Finanzen', 'финансы'],
  'finance': ['금융', '金融', 'finanzas', 'finanças', 'finance', 'Finanzen', 'финансы'],
  'fintech': ['핀테크', 'フィンテック', '金融科技', 'fintech', 'финтех'],
  'payment': ['결제', '支払い', '支付', 'pago', 'pagamento', 'paiement', 'Zahlung', 'платеж'],
  'insurance': ['보험', '保険', '保险', '保險', 'seguro', 'assurance', 'Versicherung', 'страхование'],
  'brokerage': ['증권', '브로커리지', '証券', '证券', '證券', 'corretaje', 'courtage', 'Brokerage', 'брокер'],
  'asset': ['자산', '資産', '资产', '資產', 'activo', 'ativo', 'actif', 'Vermögen', 'актив'],
  'health': ['헬스케어', '건강', 'ヘルスケア', '健康', 'salud', 'saúde', 'santé', 'Gesundheit', 'здоровье'],
  'healthcare': ['헬스케어', '의료', 'ヘルスケア', '医疗', '醫療', 'salud', 'saúde', 'santé', 'Gesundheit', 'здравоохранение'],
  'pharma': ['제약', '製薬', '制药', '製藥', 'farmacéutica', 'farmaceutica', 'pharmaceutique', 'Pharma', 'фармацевтика'],
  'pharmaceutical': ['제약', '製薬', '制药', '製藥', 'farmacéutica', 'farmaceutica', 'pharmaceutique', 'Pharma', 'фармацевтика'],
  'biotech': ['바이오', '바이오테크', 'バイオ', '生物科技', 'biotecnología', 'biotecnologia', 'biotechnologie', 'Biotechnologie', 'биотехнологии'],
  'medical': ['의료', '医療', '医疗', '醫療', 'médico', 'medico', 'médical', 'medizinisch', 'медицина'],
  'energy': ['에너지', 'エネルギー', '能源', 'energía', 'energia', 'énergie', 'Energie', 'энергия'],
  'oil': ['석유', '원유', 'オイル', '石油', 'petróleo', 'petroleo', 'pétrole', 'Öl', 'нефть'],
  'gas': ['가스', 'ガス', '天然气', '天然氣', 'gas', 'gaz', 'Gas', 'газ'],
  'natural gas': ['천연가스', '天然气', '天然氣', 'gas natural', 'gaz naturel', 'Erdgas', 'природный газ'],
  'nuclear': ['원전', '원자력', '原子力', '核能', 'nuclear', 'nucléaire', 'Kernenergie', 'ядерная энергетика'],
  'uranium': ['우라늄', 'ウラン', '铀', '鈾', 'uranio', 'uranium', 'Uran', 'уран'],
  'utility': ['유틸리티', '전력', '公益', '公用事业', '公用事業', 'servicios públicos', 'utilidade', 'services publics', 'Versorger', 'коммунальные услуги'],
  'power': ['전력', '파워', '電力', '电力', 'poder', 'energia', 'puissance', 'Strom', 'энергия'],
  'electric': ['전기', '電気', '电力', '電力', 'eléctrico', 'elétrico', 'électrique', 'elektrisch', 'электрический'],
  'industrial': ['산업재', '산업', '工業', '工业', 'industrial', 'industrie', 'Industrie', 'промышленность'],
  'infrastructure': ['인프라', 'インフラ', '基础设施', '基礎設施', 'infraestructura', 'infraestrutura', 'infrastructure', 'Infrastruktur', 'инфраструктура'],
  'construction': ['건설', '建設', '建筑', '建築', 'construcción', 'construção', 'construction', 'Bau', 'строительство'],
  'materials': ['소재', '재료', '材料', 'materiales', 'materiais', 'matériaux', 'Materialien', 'материалы'],
  'chemical': ['화학', '化学', '化工', 'química', 'quimica', 'chimie', 'Chemie', 'химия'],
  'mining': ['광산', '채굴', '鉱業', '矿业', '礦業', 'minería', 'mineração', 'mine', 'Bergbau', 'добыча'],
  'gold': ['금', '골드', 'ゴールド', '黄金', '黃金', 'oro', 'ouro', 'or', 'Gold', 'золото'],
  'silver': ['은', '실버', 'シルバー', '白银', '白銀', 'plata', 'prata', 'argent', 'Silber', 'серебро'],
  'copper': ['구리', '동', '銅', '铜', 'cobre', 'cuivre', 'Kupfer', 'медь'],
  'automotive': ['자동차', '自動車', '汽车', '汽車', 'automóvil', 'automóvel', 'automobile', 'Auto', 'автомобиль'],
  'auto': ['자동차', '自動車', '汽车', '汽車', 'auto', 'coche', 'carro', 'voiture', 'Auto', 'авто'],
  'ev': ['전기차', '電気自動車', '电动车', '電動車', 'coche eléctrico', 'carro elétrico', 'voiture électrique', 'Elektroauto', 'электромобиль'],
  'electric vehicle': ['전기차', '電気自動車', '电动车', '電動車', 'coche eléctrico', 'carro elétrico', 'voiture électrique', 'Elektroauto', 'электромобиль'],
  'battery': ['배터리', '電池', '电池', 'batería', 'bateria', 'batterie', 'Batterie', 'аккумулятор'],
  'lithium': ['리튬', 'リチウム', '锂', '鋰', 'litio', 'lítio', 'lithium', 'Lithium', 'литий'],
  'robot': ['로봇', 'ロボット', '机器人', '機器人', 'robot', 'robótica', 'robotique', 'Roboter', 'робот'],
  'robotics': ['로봇', '로보틱스', 'ロボティクス', '机器人', '機器人', 'robótica', 'robotique', 'Robotik', 'робототехника'],
  'automation': ['자동화', '自動化', '自动化', '自動化', 'automatización', 'automação', 'automatisation', 'Automatisierung', 'автоматизация'],
  'quantum': ['양자', '퀀텀', '量子', 'quantique', 'quântico', 'cuántico', 'Quanten', 'квантовый'],
  'space': ['우주', '宇宙', 'espacio', 'espaço', 'espace', 'Weltraum', 'космос'],
  'aerospace': ['항공우주', '航空宇宙', '航天', 'aeroespacial', 'aeroespacial', 'aérospatial', 'Luft Raumfahrt', 'аэрокосмический'],
  'aviation': ['항공', '航空', 'aviación', 'aviação', 'aviation', 'Luftfahrt', 'авиация'],
  'defense': ['방산', '방위', '防衛', '国防', '國防', 'defensa', 'defesa', 'défense', 'Verteidigung', 'оборона'],
  'railroad': ['철도', '鉄道', '铁路', '鐵路', 'ferrocarril', 'ferrovia', 'chemin de fer', 'Eisenbahn', 'железная дорога'],
  'shipping': ['운송', '해운', '配送', '运输', '運輸', 'envío', 'transporte', 'expédition', 'Versand', 'доставка'],
  'delivery': ['배달', '배송', '配達', '外卖', '外賣', 'entrega', 'livraison', 'Lieferung', 'доставка'],
  'logistics': ['물류', '物流', 'logística', 'logistique', 'Logistik', 'логистика'],
  'etf': ['ETF', '상장지수펀드', '上場投資信託', '交易所交易基金', 'fondo cotizado', 'fonds négocié', 'börsengehandelter fonds'],
  'bond': ['채권', '債券', '债券', 'bono', 'título', 'obligation', 'Anleihe', 'облигация'],
  'treasury': ['국채', '米国債', '美国国债', '美國國債', 'tesoro', 'tesouro', 'trésor', 'Staatsanleihe', 'казначейство'],
  'dividend': ['배당', '配当', '股息', 'dividendo', 'dividende', 'Dividende', 'дивиденд'],
  'covered call': ['커버드콜', 'カバードコール', '备兑看涨', '備兌買權', 'call cubierta', 'call coberta', 'appel couvert'],
  'leveraged': ['레버리지', 'レバレッジ', '杠杆', '槓桿', 'apalancado', 'alavancado', 'effet de levier', 'gehebelt', 'кредитное плечо'],
  'inverse': ['인버스', '역방향', 'インバース', '反向', 'inverso', 'inverse', 'umgekehrt', 'обратный'],
  'bitcoin': ['비트코인', 'ビットコイン', '比特币', '比特幣', 'bitcoin', 'биткоин'],
  'ethereum': ['이더리움', 'イーサリアム', '以太坊', 'ethereum', 'эфир'],
  'crypto': ['코인', '암호화폐', '暗号資産', '加密货币', '加密貨幣', 'cripto', 'cryptomonnaie', 'Krypto', 'криптовалюта'],
  'defi': ['디파이', '분산금융', 'DeFi', '去中心化金融', 'finanzas descentralizadas', 'finance décentralisée'],
  'stablecoin': ['스테이블코인', 'ステーブルコイン', '稳定币', '穩定幣', 'moneda estable', 'stablecoin'],
  'index': ['지수', '指数', '指數', 'índice', 'indice', 'Index', 'индекс'],
  'volatility': ['변동성', 'ボラティリティ', '波动率', '波動率', 'volatilidad', 'volatilidade', 'volatilité', 'Volatilität', 'волатильность'],
  'yield': ['금리', '수익률', '利回り', '收益率', 'rendimiento', 'rendimento', 'rendement', 'Rendite', 'доходность'],
};

const Map<String, List<String>> _exchangeSearchInfo = {
  'usdIndex': ['DXY', 'US Dollar Index', '달러 인덱스 미국 달러'],
  'usdKrw': ['KRW', 'South Korea', '원화 한국 원 달러원 달러/원 won korea'],
  'usdJpy': ['JPY', 'Japan', '엔화 일본 엔 달러엔 달러/엔 yen japan'],
  'eurUsd': ['EUR', 'Eurozone', '유로 유럽 스페인 포르투갈 프랑스 독일 euro'],
  'usdRub': ['RUB', 'Russia', '루블 러시아 ruble'],
  'usdTwd': ['TWD', 'Taiwan', '대만 달러 타이완'],
  'usdCny': ['CNY', 'China', '위안 중국 위안화'],
  'btcUsd': ['BTC', 'Bitcoin', '비트코인 bitcoin'],
  'usdGbp': ['GBP', 'United Kingdom', '파운드 영국 pound'],
  'usdCad': ['CAD', 'Canada', '캐나다 달러'],
  'usdAud': ['AUD', 'Australia', '호주 달러 오스트레일리아'],
  'usdNzd': ['NZD', 'New Zealand', '뉴질랜드 달러'],
  'usdChf': ['CHF', 'Switzerland', '스위스 프랑'],
  'usdSek': ['SEK', 'Sweden', '스웨덴 크로나'],
  'usdNok': ['NOK', 'Norway', '노르웨이 크로네'],
  'usdDkk': ['DKK', 'Denmark', '덴마크 크로네'],
  'usdPln': ['PLN', 'Poland', '폴란드 즈워티'],
  'usdCzk': ['CZK', 'Czech Republic', '체코 코루나'],
  'usdHuf': ['HUF', 'Hungary', '헝가리 포린트'],
  'usdTry': ['TRY', 'Turkey', '튀르키예 터키 리라'],
  'usdMxn': ['MXN', 'Mexico', '멕시코 페소'],
  'usdBrl': ['BRL', 'Brazil', '브라질 헤알'],
  'usdArs': ['ARS', 'Argentina', '아르헨티나 페소'],
  'usdClp': ['CLP', 'Chile', '칠레 페소'],
  'usdCop': ['COP', 'Colombia', '콜롬비아 페소'],
  'usdPen': ['PEN', 'Peru', '페루 솔'],
  'usdZar': ['ZAR', 'South Africa', '남아공 남아프리카 랜드'],
  'usdEgp': ['EGP', 'Egypt', '이집트 파운드'],
  'usdSar': ['SAR', 'Saudi Arabia', '사우디 리얄'],
  'usdAed': ['AED', 'United Arab Emirates', '아랍에미리트 UAE 디르함'],
  'usdQar': ['QAR', 'Qatar', '카타르 리얄'],
  'usdKwd': ['KWD', 'Kuwait', '쿠웨이트 디나르'],
  'usdIls': ['ILS', 'Israel', '이스라엘 셰켈'],
  'usdInr': ['INR', 'India', '인도 루피'],
  'usdIdr': ['IDR', 'Indonesia', '인도네시아 루피아'],
  'usdThb': ['THB', 'Thailand', '태국 바트'],
  'usdVnd': ['VND', 'Vietnam', '베트남 동'],
  'usdPhp': ['PHP', 'Philippines', '필리핀 페소'],
  'usdMyr': ['MYR', 'Malaysia', '말레이시아 링깃'],
  'usdSgd': ['SGD', 'Singapore', '싱가포르 달러'],
  'usdHkd': ['HKD', 'Hong Kong', '홍콩 달러'],
  'usdPkr': ['PKR', 'Pakistan', '파키스탄 루피'],
  'usdBdt': ['BDT', 'Bangladesh', '방글라데시 타카'],
  'usdLkr': ['LKR', 'Sri Lanka', '스리랑카 루피'],
  'usdKzt': ['KZT', 'Kazakhstan', '카자흐스탄 텡게'],
  'usdUah': ['UAH', 'Ukraine', '우크라이나 흐리우냐'],
  'usdRon': ['RON', 'Romania', '루마니아 레우'],
  'usdBgn': ['BGN', 'Bulgaria', '불가리아 레프'],
  'usdIsk': ['ISK', 'Iceland', '아이슬란드 크로나'],
  'usdMad': ['MAD', 'Morocco', '모로코 디르함'],
  'usdNgn': ['NGN', 'Nigeria', '나이지리아 나이라'],
  'usdKes': ['KES', 'Kenya', '케냐 실링'],
};

const Map<String, String> _chartUniversalSearchAliases = {
  'GOOG': '구글 알파벳 グーグル アルファベット 谷歌 字母表 Google Alphabet',
  'ASML': '에이에스엠엘 ASML 반도체 半導体 半导体 半導體 semiconductor',
  'INTC': '인텔 インテル 英特尔 英特爾 Intel',
  'ARM': '암 ARM アーム 安谋 安謀 반도체 semiconductor',
  'TMUS': '티모바일 T모바일 T-Mobile ティーモバイル 电信 電信 통신 telecom',
  'STX': '씨게이트 시게이트 Seagate シーゲイト 希捷 하드디스크 storage',
  'MRVL': '마벨 Marvell マーベル 美满 美滿 반도체 semiconductor',
  'WDC': '웨스턴디지털 Western Digital ウエスタンデジタル 西部数据 storage',
  'CRWD': '크라우드스트라이크 CrowdStrike クラウドストライク 网络安全 사이버보안 security',
  'PDD': '핀둬둬 테무 PDD 拼多多 Temu 전자상거래 ecommerce',
  'CEG': '컨스텔레이션 에너지 Constellation Energy 原子力 에너지 energy',
  'CDNS': '케이던스 Cadence ケイデンス 반도체 설계 EDA semiconductor',
  'SNPS': '시놉시스 Synopsys シノプシス 반도체 설계 EDA semiconductor',
  'MAR': '메리어트 Marriott マリオット 万豪 호텔 hotel',
  'FTNT': '포티넷 Fortinet フォーティネット 飞塔 飛塔 보안 security',
  'CSX': 'CSX 철도 railroad 铁路 鐵路',
  'MNST': '몬스터 Monster Beverage モンスター 饮料 飲料 음료',
  'NXPI': 'NXP 엔엑스피 半导体 半導體 반도체 semiconductor',
  'MPWR': '모놀리식 파워 Monolithic Power 电源 電源 반도체 semiconductor',
  'DDOG': '데이터독 Datadog データドッグ 云监控 雲監控 클라우드 모니터링',
  'ROST': '로스스토어 Ross Stores ロスストア 折扣零售 소매 retail',
  'ORLY': '오라일리 OReilly オライリー 자동차부품 auto parts',
  'AEP': '아메리칸 일렉트릭 파워 American Electric Power 전력 utility',
  'CTAS': '신타스 Cintas シンタス 유니폼 uniform',
  'WBD': '워너브라더스 Warner Bros Discovery ワーナー 미디어 media',
  'DASH': '도어대시 DoorDash ドアダッシュ 外卖 外賣 배달 delivery',
  'BKR': '베이커휴즈 Baker Hughes ベーカーヒューズ 油田 에너지 energy',
  'PCAR': '파카 PACCAR パッカー 트럭 truck',
  'FANG': '다이아몬드백 에너지 Diamondback Energy 석유 oil energy',
  'MCHP': '마이크로칩 Microchip マイクロチップ 반도체 semiconductor',
  'FAST': '패스널 Fastenal ファスナル 산업재 industrial',
  'EA': '일렉트로닉아츠 EA エレクトロニックアーツ 游戏 遊戲 게임',
  'XEL': '엑셀 에너지 Xcel Energy 전력 utility',
  'ADSK': '오토데스크 Autodesk オートデスク 设计 設計 설계 software',
  'FER': '페로비알 Ferrovial インフラ 基础设施 基礎設施 infrastructure',
  'EXC': '엑셀론 Exelon エクセロン 전력 utility',
  'ODFL': '올드도미니언 Old Dominion Freight 物流 운송 transport',
  'IDXX': '아이덱스 IDEXX 動物 医療 동물 의료 veterinary',
  'CCEP': '코카콜라 유로퍼시픽 Coca-Cola Europacific 음료 beverage',
  'TTWO': '테이크투 Take Two テイクツー 游戏 遊戲 게임',
  'KDP': '큐리그 닥터페퍼 Keurig Dr Pepper 饮料 飲料 음료',
  'ALNY': '앨나일람 Alnylam アルナイラム 바이오 bio biotech',
  'PYPL': '페이팔 PayPal ペイパル 支付 결제 payment',
  'TRI': '톰슨로이터 Thomson Reuters トムソンロイター 정보 data',
  'PAYX': '페이첵스 Paychex ペイチェックス 급여 payroll',
  'ROP': '로퍼 Roper Technologies ローパー 산업기술 technology',
  'CPRT': '코파트 Copart コパート 경매 auction',
  'AXON': '액손 Axon アクソン 경찰 장비 taser',
  'WDAY': '워크데이 Workday ワークデイ 인사 HR software',
  'ZS': '지스케일러 Zscaler ゼットスケーラー 보안 security',
  'GEHC': 'GE헬스케어 GE HealthCare 医療 헬스케어 healthcare',
  'KHC': '크래프트하인즈 Kraft Heinz 食品 식품 food',
  'DXCM': '덱스컴 DexCom デックスコム 당뇨 diabetes healthcare',
  'CTSH': '코그니전트 Cognizant コグニザント IT 서비스 service',
  'INSM': '인스메드 Insmed インスメッド 바이오 biotech',
  'VRSK': '베리스크 Verisk ベリスク 데이터 data analytics',
  'TEAM': '아틀라시안 Atlassian アトラシアン 협업 software',
  'CHTR': '차터 Charter Communications ケーブル 통신 cable',
  'CSGP': '코스타 CoStar コスター 부동산 데이터 real estate',
  'SPY': '에스피와이 S&P500 미국지수 米国指数 美股 指数 índice indice ETF',
  'QQQ': '큐큐큐 나스닥100 ナスダック 纳斯达克 納斯達克 ETF',
  'VOO': '부 브이오오 S&P500 뱅가드 Vanguard ETF',
  'IVV': '아이브이브이 S&P500 아이셰어즈 iShares ETF',
  'VTI': '브이티아이 미국전체시장 total market ETF',
  'IWM': '러셀2000 소형주 Russell small cap ETF',
  'DIA': '다우존스 다이아 Dow Jones ダウ ETF',
  'SCHD': '슈드 배당 dividend 配当 股息 ETF',
  'VGT': '기술주 technology テクノロジー 科技 ETF',
  'XLK': '기술 섹터 technology 科技 ETF',
  'XLF': '금융 섹터 financial finance 金融 ETF',
  'XLE': '에너지 섹터 energy 能源 ETF',
  'XLV': '헬스케어 의료 health care 医療 ETF',
  'XLI': '산업재 industrial 工业 工業 ETF',
  'XLY': '임의소비재 consumer discretionary ETF',
  'XLP': '필수소비재 consumer staples ETF',
  'XLU': '유틸리티 전력 utility ETF',
  'XLB': '소재 materials 材料 ETF',
  'XLRE': '부동산 real estate リート 房地产 房地產 ETF',
  'SMH': '반도체 semiconductor 半導体 半导体 半導體 ETF',
  'SOXX': '반도체 semiconductor 半導体 半导体 半導體 ETF',
  'ARKK': '아크 혁신 innovation イノベーション 创新 創新 ETF',
  'TLT': '미국채 장기채 treasury bond 債券 债券 ETF',
  'HYG': '하이일드 채권 high yield bond ETF',
  'LQD': '회사채 투자등급 corporate bond ETF',
  'BND': '채권 bond 債券 债券 ETF',
  'AGG': '종합채권 aggregate bond ETF',
  'SHY': '단기채 short treasury bond ETF',
  'IEF': '중기채 treasury bond ETF',
  'GLD': '금 gold ゴールド 黄金 黃金 oro or ETF',
  'SLV': '은 silver シルバー 白银 白銀 plata argent ETF',
  'USO': '원유 오일 oil crude petróleo petrole ETF',
  'UNG': '천연가스 natural gas gas naturel ETF',
  'EEM': '신흥국 emerging markets 新兴市场 新興市場 ETF',
  'EFA': '선진국 developed markets ETF',
  'VXUS': '미국제외 해외주식 international ex us ETF',
  'VEA': '선진국 developed markets ETF',
  'VNQ': '부동산 리츠 REIT real estate ETF',
  'QQQM': '나스닥100 NASDAQ ETF',
  'SQQQ': '나스닥 인버스 inverse short ETF',
  'SOXL': '반도체 레버리지 leveraged semiconductor ETF',
  'TECL': '기술주 레버리지 leveraged technology ETF',
  'SPXL': 'S&P500 레버리지 leveraged ETF',
  'UPRO': 'S&P500 레버리지 leveraged ETF',
  'TNA': '러셀2000 레버리지 small cap leveraged ETF',
  'JEPI': '월배당 커버드콜 income dividend covered call ETF',
  'JEPQ': '나스닥 월배당 커버드콜 income covered call ETF',
  'QYLD': '나스닥 커버드콜 covered call dividend ETF',
  'IBIT': '비트코인 bitcoin ビットコイン 比特币 比特幣 ETF',
  'BITO': '비트코인 bitcoin futures 선물 ETF',
  'GC1!': '금 골드 gold ゴールド 黄金 黃金 oro or 귀금속 precious metal',
  'SI1!': '은 실버 silver シルバー 白银 白銀 plata argent 귀금속 precious metal',
  'HG1!': '구리 동 copper 銅 铜 c도브레 cobre 산업금속 metal',
  'PL1!': '백금 플래티넘 platinum プラチナ 铂金 鉑金 platino',
  'PA1!': '팔라듐 palladium パラジウム 钯 鈀',
  'CL1!': '원유 WTI crude oil 오일 석유 petróleo petrole energy',
  'BRN1!': '브렌트유 brent crude oil 원유 석유 petróleo petrole',
  'NG1!': '천연가스 natural gas ガス 天然气 天然氣 gas',
  'RB1!': '휘발유 가솔린 gasoline ガソリン 汽油',
  'HO1!': '난방유 heating oil diesel fuel',
  'ZC1!': '옥수수 corn トウモロコシ 玉米 maiz maïs',
  'ZW1!': '밀 wheat 小麦 小麥 trigo blé',
  'ZS1!': '대두 콩 soybean soybeans 大豆 soja',
  'ZL1!': '대두유 콩기름 soybean oil 豆油 aceite',
  'ZM1!': '대두박 soybean meal 豆粕',
  'ZO1!': '귀리 oats オート麦 燕麦 燕麥 avena avoine',
  'ZR1!': '쌀 rice rough rice 米 arroz riz',
  'KC1!': '커피 coffee コーヒー 咖啡 cafe café',
  'SB1!': '설탕 sugar 砂糖 白糖 azucar sucre',
  'CC1!': '코코아 cocoa cacao カカオ 可可',
  'CT1!': '면화 cotton 綿 棉花 algodon coton',
  'OJ1!': '오렌지주스 orange juice オレンジジュース 橙汁',
  'LBR1!': '목재 lumber timber 木材 madera bois',
  'LE1!': '생우 live cattle 소 牛 ganado bétail',
  'GF1!': '비육우 feeder cattle 소 牛 ganado',
  'HE1!': '돼지 lean hogs 豚 猪 豬 cerdo porc',
  'DC1!': '우유 milk dairy ミルク 牛奶 leche lait',
  'FEF1!': '철광석 iron ore 鉄鉱石 铁矿石 鐵礦石 mineral hierro',
  'ALI1!': '알루미늄 aluminum aluminium アルミ 铝 鋁',
  'ZNC1!': '아연 zinc 亜鉛 锌 鋅',
  'NIC1!': '니켈 nickel ニッケル 镍 鎳',
  'LED1!': '납 lead 鉛 铅',
  'TIN1!': '주석 tin 錫 锡 estaño étain',
  'QX1!': '석탄 coal 石炭 煤炭 carbon charbon',
  'UX1!': '우라늄 uranium ウラン 铀 鈾',
  'EH1!': '에탄올 ethanol biofuel 바이오연료',
  'RS1!': '카놀라 canola 菜籽油 rapeseed',
  'COM1!': '유채 rapeseed canola colza',
  'FCPO1!': '팜유 palm oil 棕榈油 棕櫚油',
  'RSS31!': '고무 rubber ゴム 橡胶 橡膠 caucho caoutchouc',
  'PN1!': '프로판 propane 가스 gas',
  'ULSD1!': '디젤 diesel 경유 fuel',
  'QS1!': '경유 가스오일 gasoil diesel',
  'ECF1!': '탄소배출권 carbon emissions carbone carbono 碳排放',
  'DX1!': '달러인덱스 dollar index 美元指数 美元指數',
  'BDI': '발틱운임 Baltic Dry Index 해운 운임 freight shipping',
  'FBX1!': '운임 freight shipping 물류 物流',
  'GOLD': '금 현물 gold spot 黄金 黃金',
  'SILVER': '은 현물 silver spot 白银 白銀',
  'COPPER': '구리 현물 copper spot 銅 铜',
  'TSM': 'TSMC 티에스엠씨 대만반도체 台積電 台积电 台湾半導体 반도체 semiconductor',
  '005930': '삼성전자 삼성 サムスン電子 三星电子 三星電子 Samsung Electronics 반도체',
  '2222': '사우디 아람코 Saudi Aramco サウジアラムコ 沙特阿美 석유 oil energy',
  '0700': '텐센트 Tencent テンセント 腾讯 騰訊 게임 중국 internet',
  '9988': '알리바바 Alibaba アリババ 阿里巴巴 전자상거래 ecommerce',
  'NOVO_B': '노보노디스크 Novo Nordisk ノボノルディスク 诺和诺德 諾和諾德 비만 diabetes',
  'MC': '루이비통 LVMH エルブイエムエイチ 路威酩轩 路威酩軒 luxury 명품',
  '7203': '토요타 도요타 Toyota トヨタ 丰田 豐田 자동차 car',
  'SAP': 'SAP 에스에이피 サップ software ソフト웨어 软件 軟體',
  'NESN': '네슬레 Nestle Nestlé ネスレ 雀巢 food 식품',
  'ROG': '로슈 Roche ロシュ 罗氏 羅氏 제약 pharma',
  'NOVN': '노바티스 Novartis ノバルティス 诺华 諾華 제약 pharma',
  'AZN': '아스트라제네카 AstraZeneca アストラゼネカ 阿斯利康 제약 pharma',
  'SHEL': '쉘 Shell シェル 壳牌 殼牌 석유 oil energy',
  'HSBA': 'HSBC 에이치에스비씨 汇丰 匯豐 은행 bank',
  'BHP': 'BHP 비에이치피 광산 mining iron ore 철광석',
  '300750': 'CATL 닝더스다이 宁德时代 寧德時代 배터리 battery',
  '6758': '소니 Sony ソニー 索尼 전자 entertainment',
  '8306': '미쓰비시UFJ MUFG 三菱UFJ 은행 bank',
  'RELIANCE': '릴라이언스 Reliance リライアンス 인도 india energy',
  '1398': '공상은행 ICBC 工商银行 工商銀行 중국은행 bank',
  '0941': '차이나모바일 China Mobile 中国移动 中國移動 통신 telecom',
  '3690': '메이투안 Meituan 美团 美團 배달 delivery',
  '1211': 'BYD 비야디 比亚迪 比亞迪 전기차 EV battery',
  'RMS': '에르메스 Hermes Hermès エルメス 爱马仕 愛馬仕 명품 luxury',
  'SIE': '지멘스 Siemens シーメンス 西门子 西門子 industrial',
  'TTE': '토탈에너지 TotalEnergies トタル 能源 energy oil',
  'CBA': '커먼웰스은행 Commonwealth Bank 호주은행 bank australia',
  'ULVR': '유니레버 Unilever ユニリーバ 联合利华 聯合利華 consumer',
  '1299': 'AIA 에이아이에이 友邦保险 友邦保險 보험 insurance',
  'BTC': '비트코인 bitcoin ビットコイン 比特币 比特幣 биткоин crypto',
  'ETH': '이더리움 ethereum イーサリアム 以太坊 эфир crypto',
  'USDT': '테더 tether 泰达币 泰達幣 스테이블코인 stablecoin',
  'XRP': '리플 ripple エックスアールピー 瑞波 crypto',
  'BNB': '비앤비 바이낸스코인 Binance coin 币安幣 币安币 crypto',
  'SOL': '솔라나 solana ソラナ 索拉纳 索拉納 crypto',
  'USDC': '유에스디코인 USD Coin 스테이블코인 stablecoin',
  'TRX': '트론 tron トロン 波场 波場 crypto',
  'DOGE': '도지코인 dogecoin ドージコイン 狗狗币 狗狗幣 crypto',
  'ADA': '카르다노 에이다 cardano ada カルダノ 艾达 艾達 crypto',
  'HYPE': '하이퍼리퀴드 hyperliquid hype crypto',
  'SUI': '수이 sui スイ crypto',
  'BCH': '비트코인캐시 bitcoin cash ビットコインキャッシュ crypto',
  'LINK': '체인링크 chainlink チェーンリンク crypto oracle',
  'XLM': '스텔라 stellar lumen ステラ 恒星币 恒星幣 crypto',
  'AVAX': '아발란체 avalanche アバランチ 雪崩 crypto',
  'LEO': '레오 leo unus sed leo crypto',
  'TON': '톤코인 toncoin トンコイン crypto',
  'LTC': '라이트코인 litecoin ライトコイン 莱特币 萊特幣 crypto',
  'SHIB': '시바이누 shiba inu 柴犬币 柴犬幣 crypto meme',
  'HBAR': '헤데라 hedera ヘデラ crypto',
  'DOT': '폴카닷 polkadot ポルカドット 波卡 crypto',
  'UNI': '유니스왑 uniswap ユニスワップ crypto defi',
  'XMR': '모네로 monero モネロ 门罗币 門羅幣 crypto',
  'DAI': '다이 dai ス테이블코인 stablecoin',
  'APT': '앱토스 aptos アプトス crypto',
  'PEPE': '페페 pepe ペペ crypto meme',
  'OKB': '오케이비 OKB crypto exchange token',
  'TAO': '비텐서 bittensor tao crypto ai',
  'ICP': '인터넷컴퓨터 internet computer crypto',
  'ETC': '이더리움클래식 ethereum classic crypto',
  'NEAR': '니어프로토콜 near protocol ニア crypto',
  'AAVE': '아베 에이브 aave defi crypto',
  'ONDO': '온도 ondo finance rwa crypto',
  'POL': '폴리곤 polygon matic crypto',
  'KAS': '카스파 kaspa crypto',
  'CRO': '크로노스 cronos crypto.com crypto',
  'ATOM': '코스모스 cosmos atom crypto',
  'ALGO': '알고랜드 algorand crypto',
  'VET': '비체인 vechain crypto',
  'FIL': '파일코인 filecoin crypto storage',
  'ARB': '아비트럼 arbitrum crypto layer2',
  'KCS': '쿠코인토큰 kucoin token crypto',
  'OP': '옵티미즘 optimism crypto layer2',
  'WLD': '월드코인 worldcoin crypto',
  'SEI': '세이 sei crypto',
  'BONK': '봉크 bonk crypto meme',
  'INJ': '인젝티브 injective crypto',
  'FET': '페치 fetch ai artificial superintelligence crypto',
  'RENDER': '렌더 render crypto ai gpu',
  'EWY': '한국 코리아 korea 韩国 韓國 ETF 국가 country',
  'EWJ': '일본 japan 日本 ETF 국가 country',
  'FXI': '중국 대형주 china 中国 中國 ETF country',
  'MCHI': '중국 china 中国 中國 ETF country',
  'EWT': '대만 타이완 taiwan 台湾 台灣 ETF country',
  'INDA': '인도 india 印度 ETF country',
  'VGK': '유럽 europe europa 欧洲 歐洲 ETF region',
  'EWG': '독일 germany deutschland ドイツ 德国 德國 ETF country',
  'EWQ': '프랑스 france フランス 法国 法國 ETF country',
  'EWZ': '브라질 brazil brasil ブラジル 巴西 ETF country',
  'EWW': '멕시코 mexico méxico メキシコ 墨西哥 ETF country',
  'VIX': '공포지수 변동성 volatility fear index 恐慌指数 恐慌指數',
  'UVXY': '변동성 레버리지 volatility VIX leveraged fear ETF',
  'SVXY': '변동성 인버스 inverse volatility VIX ETF',
  'MOVE': '채권 변동성 bond volatility treasury fear index',
  'VVIX': 'VIX 변동성 volatility of volatility fear index',
  'US10Y': '미국 10년물 금리 국채 treasury yield bond rate',
  'US02Y': '미국 2년물 금리 국채 treasury yield bond rate',
  'US30Y': '미국 30년물 금리 국채 treasury yield bond rate',
  'SMCI': '슈퍼마이크로 Super Micro Computer 서버 AI 인프라 infrastructure',
  'DELL': '델 Dell デル 서버 PC AI 인프라 infrastructure',
  'HPE': '휴렛팩커드 HPE Hewlett Packard Enterprise 서버 AI 인프라',
  'VRT': '버티브 Vertiv 전력 냉각 데이터센터 AI infrastructure',
  '000660': 'SK하이닉스 하이닉스 Hynix 半导体 半導體 메모리 반도체',
  '005380': '현대차 현대자동차 Hyundai Motor ヒョンデ 现代 現代 자동차',
  '035420': '네이버 NAVER ネイバー 검색 포털 인터넷',
  '035720': '카카오 Kakao カカオ 메신저 플랫폼 인터넷',
  '051910': 'LG화학 엘지화학 LG Chem 배터리 화학',
  '373220': 'LG에너지솔루션 엘지에너지솔루션 LG Energy Solution 배터리 battery',
  '9984': '소프트뱅크 SoftBank ソフトバンク 일본 투자 통신',
  '8035': '도쿄일렉트론 Tokyo Electron 반도체 장비 semiconductor equipment',
  '6861': '키엔스 Keyence キーエンス 자동화 센서 automation',
  '4063': '신에츠화학 Shin-Etsu Chemical 반도체 소재 chemical',
  '6098': '리크루트 Recruit リクルート HR 채용 일본',
  'NOC': '노스롭그루먼 Northrop Grumman 방산 defense aerospace',
  'GD': '제너럴다이내믹스 General Dynamics 방산 defense aerospace',
  'LHX': 'L3해리스 L3Harris 방산 defense aerospace',
  'ETR': '엔터지 Entergy 전력 원전 utility nuclear',
  'VST': '비스트라 Vistra 전력 발전 utility power',
  'PWR': '콴타서비스 Quanta Services 전력 인프라 grid infrastructure',
  'IONQ':
      '아이온큐 이온큐 IonQ quantum computing 퀀텀컴퓨팅 양자컴퓨터 양자컴퓨팅 量子计算 量子運算 computación cuántica computacao quantica computação quântica informatique quantique Quantencomputing квантовые вычисления',
  'RGTI':
      '리게티 Rigetti quantum computing 퀀텀컴퓨팅 양자컴퓨터 양자컴퓨팅 量子计算 量子運算 computación cuántica computacao quantica computação quântica informatique quantique Quantencomputing квантовые вычисления',
  'QUBT':
      '퀀텀컴퓨팅 Quantum Computing Inc quantum computing 퀀텀컴퓨팅 양자컴퓨터 양자컴퓨팅 量子计算 量子運算 computación cuántica computacao quantica computação quântica informatique quantique Quantencomputing квантовые вычисления',
  'QBTS':
      '디웨이브 D-Wave quantum computing 퀀텀컴퓨팅 양자컴퓨터 양자컴퓨팅 量子计算 量子運算 computación cuántica computacao quantica computação quântica informatique quantique Quantencomputing квантовые вычисления',
  'QTUM':
      '퀀텀 ETF Defiance Quantum ETF quantum computing 퀀텀컴퓨팅 양자컴퓨터 양자컴퓨팅 量子计算 量子運算 computación cuántica computacao quantica computação quântica informatique quantique Quantencomputing квантовые вычисления',
};

const Map<String, String> _commoditySearchAliases = {
  'commoditygold':
      '금 골드 gold ouro oro or золото Gold ゴールド 黄金 黃金 precious metal 귀금속',
  'commoditysilver':
      '은 실버 silver prata plata argent серебро Silber シルバー 白银 白銀 precious metal 귀금속',
  'commoditycopper':
      '구리 동 copper cobre cuivre медь Kupfer 銅 铜 산업금속 industrial metal',
  'commodityplatinum':
      '백금 플래티넘 platinum platina platino platine платина Platin プラチナ 铂金 鉑金',
  'commoditypalladium':
      '팔라듐 palladium paladio palladium палладий Palladium パラジウム 钯 鈀',
  'commoditywtiCrude':
      '원유 석유 오일 WTI crude oil petroleo petróleo petrole pétrole нефть Öl 原油 石油',
  'commoditybrentCrude':
      '브렌트유 원유 석유 brent crude oil petroleo petróleo petrole pétrole нефть Öl 原油 石油',
  'commoditynaturalGas':
      '천연가스 가스 natural gas gas gaz природный газ Erdgas 天然气 天然氣',
  'commoditygasoline':
      '휘발유 가솔린 gasoline gasolina essence бензин Benzin ガソリン 汽油',
  'commodityheatingOil':
      '난방유 heating oil fuel oil gasoleo gasóleo fioul мазут Heizöl',
  'commoditycorn':
      '옥수수 corn milho maiz maíz mais maïs кукуруза Mais トウモロコシ 玉米',
  'commoditywheat':
      '밀 소맥 wheat trigo ble blé пшеница Weizen 小麦 小麥',
  'commoditysoybeans':
      '대두 콩 soybean soybeans soja соя Sojabohnen 大豆',
  'commoditysoybeanOil':
      '대두유 콩기름 soybean oil oleo de soja aceite de soja huile de soja соевое масло 豆油',
  'commoditysoybeanMeal':
      '대두박 soybean meal farelo de soja harina de soja tourteau de soja соевый шрот 豆粕',
  'commodityoats':
      '귀리 oats aveia avena avoine овес овёс Hafer オート麦 燕麦 燕麥',
  'commodityroughRice':
      '쌀 현미 rice rough rice arroz riz рис Reis 米',
  'commoditycoffee':
      '커피 coffee cafe café кофе Kaffee コーヒー 咖啡',
  'commoditysugar':
      '설탕 sugar acucar açúcar azucar azúcar sucre сахар Zucker 砂糖 白糖',
  'commoditycocoa':
      '코코아 cocoa cacao какао Kakao カカオ 可可',
  'commoditycotton':
      '면화 cotton algodao algodão algodon algodón coton хлопок Baumwolle 綿 棉花',
  'commodityorangeJuice':
      '오렌지주스 orange juice suco de laranja zumo de naranja jus orange апельсиновый сок Orangensaft 橙汁',
  'commoditylumber':
      '목재 lumber timber madeira madera bois древесина Holz 木材',
  'commodityliveCattle':
      '생우 소 live cattle gado ganado betail bétail крупный рогатый скот Rinder 牛',
  'commodityfeederCattle':
      '비육우 소 feeder cattle gado ganado betail bétail Rinder 牛',
  'commodityleanHogs':
      '돼지 lean hogs porco cerdo porc свиньи Schwein 豚 猪 豬',
  'commoditymilk':
      '우유 milk leite leche lait молоко Milch ミルク 牛奶',
  'commodityironOre':
      '철광석 iron ore minerio de ferro minério de ferro mineral de hierro minerai de fer железная руда Eisenerz 鉄鉱石 铁矿石 鐵礦石',
  'commodityaluminum':
      '알루미늄 aluminum aluminium aluminio aluminium алюминий Aluminium アルミ 铝 鋁',
  'commodityzinc':
      '아연 zinc zinco zinc цинк Zink 亜鉛 锌 鋅',
  'commoditynickel':
      '니켈 nickel niquel níquel nickel никель Nickel ニッケル 镍 鎳',
  'commoditylead':
      '납 lead chumbo plomo plomb свинец Blei 鉛 铅',
  'commoditytin':
      '주석 tin estanho estano estaño etain étain олово Zinn 錫 锡',
  'commoditycoal':
      '석탄 coal carvao carvão carbon carbón charbon уголь Kohle 石炭 煤炭',
  'commodityuranium':
      '우라늄 uranium uranio uranium уран Uran ウラン 铀 鈾',
  'commodityethanol':
      '에탄올 ethanol etanol etanol ethanol этанол Ethanol 바이오연료 biofuel',
  'commoditycanola':
      '카놀라 canola colza рапс Raps 菜籽油',
  'commodityrapeseed':
      '유채 rapeseed canola colza рапс Raps 菜籽',
  'commoditypalmOil':
      '팜유 palm oil oleo de palma aceite de palma huile de palme пальмовое масло Palmöl 棕榈油 棕櫚油',
  'commodityrubber':
      '고무 rubber borracha caucho caoutchouc резина Gummi ゴム 橡胶 橡膠',
  'commoditypropane':
      '프로판 propane propano propane пропан Propan 가스 gas',
  'commoditydiesel':
      '디젤 경유 diesel diesel diesel дизель Diesel',
  'commoditygasoil':
      '가스오일 경유 gasoil gasoleo gasóleo gasoil газойль Gasöl diesel',
  'commoditycarbon':
      '탄소배출권 carbon emissions carbono carbone углерод CO2 Kohlenstoff 碳排放',
  'commodityusDollarIndex':
      '달러인덱스 달러 지수 US Dollar Index indice dolar índice dólar indice dollar долларовый индекс Dollarindex 美元指数 美元指數',
  'commoditybalticDry':
      '발틱운임 Baltic Dry Index 해운 운임 freight shipping frete flete fret фрахт Frachtrate',
  'commodityfreight':
      '운임 freight shipping frete flete fret фрахт Fracht 물류 物流',
  'commoditygoldSpot':
      '금 현물 gold spot ouro oro or золото Gold ゴールド 黄金 黃金',
  'commoditysilverSpot':
      '은 현물 silver spot prata plata argent серебро Silber シルバー 白银 白銀',
  'commoditycopperSpot':
      '구리 현물 copper spot cobre cuivre медь Kupfer 銅 铜',
};

const Map<String, String> _extraChartSearchAliases = {
  'AAPL': '애플 아이폰 iphone mac 맥 苹果 蘋果 アップル',
  'MSFT': '마이크로소프트 윈도우 오피스 클라우드 Microsoft 微软 微軟 マイクロソフト',
  'NVDA': '엔비디아 엔디비아 nvidia 그래픽카드 GPU AI 반도체 英伟达 輝達 エヌビディア',
  'AMZN': '아마존 amazon 이커머스 클라우드 AWS 亚马逊 亞馬遜 アマゾン',
  'GOOGL': '구글 알파벳 google alphabet 검색 유튜브 youtube 谷歌 グーグル',
  'GOOG': '구글 알파벳 google alphabet 검색 유튜브 youtube 谷歌 グーグル',
  'META': '메타 페이스북 인스타그램 instagram facebook 메타버스 Meta 脸书 臉書',
  'TSLA': '테슬라 전기차 EV 일론머스크 Tesla 特斯拉 テスラ',
  'AVGO': '브로드컴 broadcom 반도체 AI 네트워크 博通 ブロードコム',
  'BRK.B': '버크셔 해서웨이 워렌버핏 berkshire hathaway 巴菲特 バークシャー',
  'LLY': '일라이릴리 릴리 비만 당뇨 제약 Eli Lilly 礼来 禮來 イーライリリー',
  'JPM': '제이피모건 JP모건 은행 금융 JPMorgan 摩根大通 JPモルガン',
  'V': '비자 visa 카드 결제 支付 ビザ',
  'MA': '마스터카드 mastercard 카드 결제 支付 マスターカード',
  'UNH': '유나이티드헬스 유나이티드헬스케어 건강보험 헬스케어 UnitedHealth',
  'XOM': '엑슨모빌 엑손모빌 석유 에너지 Exxon Mobil oil energy 埃克森美孚',
  'COST': '코스트코 costco 리테일 할인마트 コストコ',
  'HD': '홈디포 home depot 주택 건축 인테리어 家得宝 ホームデポ',
  'NFLX': '넷플릭스 netflix 스트리밍 OTT ネットフリックス 奈飞 奈飛',
  'PG': '피앤지 P&G 프록터앤갬블 생활용품 Procter Gamble 宝洁 寶潔',
  'JNJ': '존슨앤존슨 JNJ 제약 헬스케어 Johnson & Johnson 強生',
  'WMT': '월마트 walmart 리테일 할인마트 沃尔玛 ウォルマート',
  'ABBV': '애브비 AbbVie 제약 바이오 botox 보톡스 艾伯维',
  'BAC': '뱅크오브아메리카 BOA 은행 Bank of America 美国银行',
  'CRM': '세일즈포스 salesforce CRM 클라우드 소프트웨어',
  'ORCL': '오라클 oracle 데이터베이스 클라우드 甲骨文 オラクル',
  'KO': '코카콜라 coca cola 음료 可口可乐 コカコーラ',
  'CVX': '셰브론 쉐브론 chevron 석유 에너지 oil energy 雪佛龙',
  'AMD': '에이엠디 AMD 라이젠 반도체 CPU GPU 超微 半导体',
  'MRK': '머크 merck 제약 키트루다 默沙东 メルク',
  'CSCO': '시스코 cisco 네트워크 통신 보안 思科 シスコ',
  'WFC': '웰스파고 wells fargo 은행 금융 富国银行',
  'MCD': '맥도날드 mcdonalds 햄버거 패스트푸드 麦当劳 マクドナルド',
  'PEP': '펩시 펩시코 pepsi pepsico 음료 스낵 百事 ペプシ',
  'LIN': '린데 linde 산업가스 수소 chemical gas',
  'ADBE': '어도비 adobe 포토샵 creative cloud 소프트웨어 アドビ',
  'TMO': '써모피셔 thermo fisher 생명과학 바이오 장비',
  'GE': 'GE 지이 제너럴일렉트릭 항공 에너지 aerospace',
  'IBM': '아이비엠 IBM AI 왓슨 서버 클라우드',
  'QCOM': '퀄컴 qualcomm 스냅드래곤 반도체 통신 高通',
  'CAT': '캐터필러 caterpillar 중장비 건설 광산 卡特彼勒',
  'INTU': '인튜이트 intuit 터보택스 퀵북스 핀테크 세금',
  'DIS': '디즈니 disney OTT 디즈니플러스 테마파크 迪士尼',
  'TXN': '텍사스인스트루먼트 TI 반도체 Texas Instruments 德州仪器',
  'AMAT': '어플라이드머티리얼즈 applied materials 반도체 장비 应用材料',
  'GS': '골드만삭스 Goldman Sachs 투자은행 금융 高盛',
  'NOW': '서비스나우 ServiceNow 클라우드 워크플로우 소프트웨어',
  'ISRG': '인튜이티브서지컬 다빈치로봇 수술로봇 의료기기',
  'VZ': '버라이즌 verizon 통신 5G',
  'RTX': 'RTX 레이시온 방산 항공 미사일 defense',
  'BKNG': '부킹홀딩스 booking 부킹닷컴 여행 호텔',
  'SPGI': 'S&P글로벌 S&P Global 신용평가 지수 데이터',
  'LOW': '로우스 lowes 주택 인테리어 건축 리테일',
  'PFE': '화이자 pfizer 제약 백신 辉瑞 ファイザー',
  'HON': '하니웰 honeywell 자동화 항공 산업',
  'NKE': '나이키 nike 스포츠 신발 의류 耐克 ナイキ',
  'UBER': '우버 uber 차량공유 배달 모빌리티',
  'CMCSA': '컴캐스트 comcast 케이블 미디어 통신',
  'AMGN': '암젠 amgen 바이오 제약',
  'BA': '보잉 boeing 항공기 방산 波音 ボーイング',
  'UNP': '유니온퍼시픽 union pacific 철도 railroad',
  'SBUX': '스타벅스 starbucks 커피 スターバックス 星巴克',
  'PANW': '팔로알토네트웍스 palo alto cybersecurity 보안',
  'PLTR': '팔란티어 palantir AI 데이터 방산',
  'MU': '마이크론 micron 메모리 반도체 DRAM NAND 美光',
  'LRCX': '램리서치 lam research 반도체 장비',
  'ADP': 'ADP 급여 인사 HR payroll',
  'DE': '디어 존디어 deere 농기계 트랙터',
  'GILD': '길리어드 gilead 바이오 제약',
  'COP': '코노코필립스 conoco phillips 석유 에너지',
  'TJX': '티제이엑스 TJX 리테일 할인매장',
  'ADI': '아날로그디바이시스 analog devices 반도체',
  'C': '씨티그룹 citi citigroup 은행 금융',
  'APP': '앱러빈 applovin 광고 게임 AI',
  'SCHW': '찰스슈왑 schwab 증권 브로커리지',
  'ANET': '아리스타네트웍스 arista 네트워크 데이터센터',
  'MDLZ': '몬델리즈 mondelez 오레오 과자 스낵',
  'SYK': '스트라이커 stryker 의료기기 헬스케어',
  'BLK': '블랙록 blackrock 자산운용 ETF',
  'ETN': '이튼 eaton 전력 전기 인프라',
  'MMC': '마시맥레넌 marsh mclennan 보험 컨설팅',
  'REGN': '리제네론 regeneron 바이오 제약',
  'VRTX': '버텍스 vertex pharma 제약 바이오',
  'LMT': '록히드마틴 lockheed martin 방산 항공 defense',
  'ELV': '엘레번스헬스 elevance health 보험 헬스케어',
  'UPS': '유피에스 UPS 물류 택배 배송',
  'PGR': '프로그레시브 progressive 보험',
  'AMT': '아메리칸타워 american tower 통신탑 리츠',
  'NEE': '넥스트에라에너지 nextera energy 전력 신재생',
  'SO': '서던컴퍼니 southern company 전력 유틸리티',
  'KLAC': 'KLA 케이엘에이 반도체 장비 검사',
  'BX': '블랙스톤 blackstone 사모펀드 부동산',
  'KKR': 'KKR 사모펀드 투자자산운용',
  'SHOP': '쇼피파이 shopify 이커머스 쇼핑몰',
  'MELI': '메르카도리브레 mercadolibre 남미 이커머스',
  'ABNB': '에어비앤비 airbnb 여행 숙박',
  'RIVN': '리비안 rivian 전기차 EV',
  'SNOW': '스노우플레이크 snowflake 데이터 클라우드',
  'COIN': '코인베이스 coinbase 암호화폐 거래소 코인',
  'MSTR': '마이크로스트래티지 microstrategy 비트코인 bitcoin',
  'HOOD': '로빈후드 robinhood 증권 핀테크',
  'ASML': 'ASML 에이에스엠엘 반도체 장비 노광 네덜란드',
  'INTC': '인텔 intel 반도체 CPU',
  'ARM': '암 arm 반도체 설계',
  'TMUS': '티모바일 t-mobile 통신 5G',
  'STX': '씨게이트 seagate 하드디스크 저장장치',
  'MRVL': '마벨 marvell 반도체 네트워크',
  'WDC': '웨스턴디지털 western digital 저장장치 HDD SSD',
  'CRWD': '크라우드스트라이크 crowdstrike 보안 사이버보안',
  'PDD': '핀둬둬 테무 PDD temu 중국 이커머스',
  'CEG': '컨스텔레이션에너지 constellation energy 원전 전력',
  'CDNS': '케이던스 cadence 반도체 설계 EDA',
  'SNPS': '시놉시스 synopsys 반도체 설계 EDA',
  'MAR': '메리어트 marriott 호텔 여행',
  'FTNT': '포티넷 fortinet 보안 사이버보안',
  'CSX': 'CSX 철도 물류 railroad',
  'MNST': '몬스터베버리지 monster beverage 에너지드링크',
  'NXPI': 'NXP 반도체 자동차반도체',
  'MPWR': '모놀리식파워 monolithic power 전력반도체',
  'DDOG': '데이터독 datadog 클라우드 모니터링',
  'ROST': '로스스토어 ross stores 할인 리테일',
  'ORLY': '오라일리 오토파츠 OReilly 자동차부품',
  'AEP': '아메리칸일렉트릭파워 전력 유틸리티',
  'CTAS': '신타스 cintas 유니폼 서비스',
  'WBD': '워너브라더스디스커버리 HBO 미디어',
  'DASH': '도어대시 doordash 배달 음식',
  'BKR': '베이커휴즈 baker hughes 에너지 장비',
  'PCAR': '파카 paccar 트럭',
  'FANG': '다이아몬드백에너지 diamondback oil energy',
  'EA': '일렉트로닉아츠 EA 게임',
  'EXC': '엑셀론 exelon 전력 유틸리티',
  'KDP': '큐리그닥터페퍼 keurig dr pepper 음료',
  'PAYX': '페이첵스 paychex 급여 HR',
  'XEL': '엑셀에너지 xcel energy 전력',
  'FAST': '패스널 fastenal 산업용품',
  'TEAM': '아틀라시안 atlassian jira 소프트웨어',
  'IDXX': '아이덱스 idexx 반려동물 진단',
  'BIIB': '바이오젠 biogen 바이오 제약',
  'CSGP': '코스타그룹 costar 부동산 데이터',
  'ZS': '지스케일러 zscaler 보안',
  'TTD': '트레이드데스크 trade desk 광고',
  'WDAY': '워크데이 workday HR 클라우드',
  'VRSK': '베리스크 verisk 보험 데이터',
  'MCHP': '마이크로칩 microchip 반도체',
  'GFS': '글로벌파운드리스 globalfoundries 반도체 파운드리',
  'ON': '온세미 onsemi 반도체 전력',
  'MRNA': '모더나 moderna 백신 바이오',
  'MDB': '몽고디비 mongodb 데이터베이스',
  'NET': '클라우드플레어 cloudflare 보안 CDN',
  'RDDT': '레딧 reddit 커뮤니티 SNS',
  'HIMS': '힘스 hims 헬스케어 원격진료',
  'CELH': '셀시어스 celsius 에너지드링크',
  'DUOL': '듀오링고 duolingo 교육 언어 AI',
  'CAVA': '카바 cava 레스토랑',
  'SHAK': '쉐이크쉑 shake shack 레스토랑',
  'ELF': '엘프뷰티 elf beauty 화장품',
  'CART': '인스타카트 instacart 배달 장보기',
  'TOST': '토스트 toast 레스토랑 결제',
  'U': '유니티 unity 게임엔진',
  'PATH': '유아이패스 uipath 자동화 RPA',
  'AI': '씨쓰리에이아이 C3 AI 인공지능',
  'SOUN': '사운드하운드 soundhound AI 음성',
  'BBAI': '빅베어 BigBear AI 인공지능',
  'SERV': '서브로보틱스 serve robotics 로봇',
  'SYM': '심보틱 symbotic 로봇 자동화',
  'TER': '테라다인 teradyne 반도체 테스트 로봇',
  'IRBT': '아이로봇 irobot 로봇청소기',
  'OKLO': '오클로 oklo 원전 소형원전 SMR',
  'SMR': '뉴스케일 nuscale 소형원전 SMR',
  'LEU': '센트러스 centrus 우라늄 원전',
  'CCJ': '카메코 cameco 우라늄',
  'UEC': '우라늄에너지 uranium energy',
  'RKLB': '로켓랩 rocket lab 우주 로켓',
  'ASTS': 'AST스페이스모바일 우주통신 위성',
  'LUNR': '인튜이티브머신스 intuitive machines 달탐사 우주',
  'ACHR': '아처항공 archer aviation 전기항공 eVTOL',
  'JOBY': '조비항공 joby aviation 전기항공 eVTOL',
  'EVTL': '버티컬에어로스페이스 vertical aerospace eVTOL',
  'BLDE': '블레이드 blade air mobility 항공모빌리티',
  'LCID': '루시드 lucid 전기차 EV',
  'NIO': '니오 NIO 중국 전기차',
  'LI': '리오토 li auto 중국 전기차',
  'XPEV': '샤오펑 xpeng 중국 전기차',
  'BABA': '알리바바 alibaba 중국 이커머스',
  'BIDU': '바이두 baidu 중국 검색 AI',
  'JD': '징동닷컴 JD 중국 이커머스',
  'TME': '텐센트뮤직 tencent music 중국 음악',
  'BILI': '빌리빌리 bilibili 중국 영상',
  'BEKE': '베이커 KE holdings 중국 부동산',
  'YMM': '만방 full truck alliance 중국 물류',
  'SE': '씨리미티드 sea limited 동남아 쇼피 게임',
  'GRAB': '그랩 grab 동남아 슈퍼앱',
  'NU': '누뱅크 nubank 브라질 핀테크',
  'STNE': '스톤코 stoneco 브라질 핀테크',
  'PAGS': '팍세구로 pagseguro 브라질 핀테크',
  'CRSP': '크리스퍼 CRISPR 유전자편집 바이오',
  'EDIT': '에디타스 editas 유전자편집',
  'BEAM': '빔테라퓨틱스 beam 유전자편집',
  'NTLA': '인텔리아 intellia 유전자편집',
  'DNA': '깅코바이오웍스 ginkgo biotech',
  'RXRX': '리커전 recursion AI 바이오',
  'TEM': '템퍼스 tempus AI 헬스케어',
  'ENVX': '에노빅스 enovix 배터리',
  'QS': '퀀텀스케이프 quantumscape 전고체 배터리',
  'ALB': '앨버말 albemarle 리튬',
  'LAC': '리튬아메리카스 lithium americas 리튬',
  'PLL': '피드몬트리튬 piedmont lithium 리튬',
};

ExchangeListItem exchangeCurrencyItem(
  String id,
  String code,
  Color color,
) {
  return ExchangeListItem(
    id: id,
    symbolPath: 'FX_IDC-USD$code',
    color: color,
    icon: Icons.currency_exchange_rounded,
  );
}

class ChartPage extends StatefulWidget {
  const ChartPage({super.key});

  static final defaultChartItems = <ChartListItem>[
    ChartListItem(
      id: 'nasdaq100Futures',
      title: 'Nasdaq 100 Futures',
      subtitle: 'CME_MINI:NQ1!',
      symbolPath: 'CME_MINI-NQ1!',
      color: _blue,
      icon: Icons.timeline_rounded,
    ),
    ChartListItem(
      id: 'qld',
      title: 'QLD',
      subtitle: 'AMEX:QLD',
      symbolPath: 'AMEX-QLD',
      color: _purple,
      icon: Icons.stacked_line_chart_rounded,
    ),
    ChartListItem(
      id: 'tqqq',
      title: 'TQQQ',
      subtitle: 'NASDAQ:TQQQ',
      symbolPath: 'NASDAQ-TQQQ',
      color: _cyan,
      icon: Icons.show_chart_rounded,
    ),
    ChartListItem(
      id: 'sp500',
      title: 'S&P 500',
      subtitle: 'SP:SPX',
      symbolPath: 'SP-SPX',
      color: Colors.redAccent,
      icon: Icons.bar_chart_rounded,
    ),
    ChartListItem(
      id: 'kospi',
      title: 'Korea KOSPI',
      subtitle: 'KRX:KOSPI',
      symbolPath: 'KRX-KOSPI',
      color: Colors.lightBlueAccent,
      icon: Icons.show_chart_rounded,
    ),
    ChartListItem(
      id: 'nikkei225',
      title: 'Japan Nikkei 225',
      subtitle: 'TVC:NI225',
      symbolPath: 'TVC-NI225',
      color: Colors.pinkAccent,
      icon: Icons.candlestick_chart_rounded,
    ),
    ChartListItem(
      id: 'ibex35',
      title: 'Spain IBEX 35',
      subtitle: 'TVC:IBEX35',
      symbolPath: 'TVC-IBEX35',
      color: Colors.deepOrangeAccent,
      icon: Icons.insert_chart_rounded,
    ),
    ChartListItem(
      id: 'psi',
      title: 'Portugal PSI',
      subtitle: 'INDEXEURO:PSI20',
      symbolPath: 'INDEXEURO-PSI20',
      color: Colors.greenAccent,
      icon: Icons.query_stats_rounded,
    ),
    ChartListItem(
      id: 'moex',
      title: 'Russia MOEX',
      subtitle: 'MOEX:IMOEX',
      symbolPath: 'MOEX-IMOEX',
      color: Colors.redAccent,
      icon: Icons.stacked_line_chart_rounded,
    ),
    ChartListItem(
      id: 'sseComposite',
      title: 'China SSE Composite',
      subtitle: 'SSE:000001',
      symbolPath: 'SSE-000001',
      color: Colors.amberAccent,
      icon: Icons.area_chart_rounded,
    ),
    ChartListItem(
      id: 'taiex',
      title: 'Taiwan TAIEX',
      subtitle: 'INDEX:TAIEX',
      symbolPath: 'INDEX-TAIEX',
      color: Colors.tealAccent,
      icon: Icons.timeline_rounded,
    ),
    ChartListItem(
      id: 'cac40',
      title: 'France CAC 40',
      subtitle: 'TVC:CAC40',
      symbolPath: 'TVC-CAC40',
      color: Colors.indigoAccent,
      icon: Icons.multiline_chart_rounded,
    ),
    ChartListItem(
      id: 'dax',
      title: 'Germany DAX',
      subtitle: 'XETR:DAX',
      symbolPath: 'XETR-DAX',
      color: Colors.yellowAccent,
      icon: Icons.auto_graph_rounded,
    ),
    popularStockChartItem('AAPL', 'Apple', 'NASDAQ', _blue),
    popularStockChartItem('MSFT', 'Microsoft', 'NASDAQ', _cyan),
    popularStockChartItem('NVDA', 'NVIDIA', 'NASDAQ', _purple),
    popularStockChartItem('AMZN', 'Amazon', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('GOOGL', 'Alphabet Class A', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('META', 'Meta Platforms', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('TSLA', 'Tesla', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('AVGO', 'Broadcom', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('BRK.B', 'Berkshire Hathaway', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('LLY', 'Eli Lilly', 'NYSE', Colors.tealAccent),
    popularStockChartItem('JPM', 'JPMorgan Chase', 'NYSE', _blue),
    popularStockChartItem('V', 'Visa', 'NYSE', _cyan),
    popularStockChartItem('UNH', 'UnitedHealth', 'NYSE', _purple),
    popularStockChartItem('XOM', 'Exxon Mobil', 'NYSE', Colors.greenAccent),
    popularStockChartItem('MA', 'Mastercard', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('COST', 'Costco', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('HD', 'Home Depot', 'NYSE', Colors.amberAccent),
    popularStockChartItem('NFLX', 'Netflix', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('PG', 'Procter & Gamble', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('JNJ', 'Johnson & Johnson', 'NYSE', Colors.tealAccent),
    popularStockChartItem('WMT', 'Walmart', 'NYSE', _blue),
    popularStockChartItem('ABBV', 'AbbVie', 'NYSE', _cyan),
    popularStockChartItem('BAC', 'Bank of America', 'NYSE', _purple),
    popularStockChartItem('CRM', 'Salesforce', 'NYSE', Colors.greenAccent),
    popularStockChartItem('ORCL', 'Oracle', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('KO', 'Coca-Cola', 'NYSE', Colors.redAccent),
    popularStockChartItem('CVX', 'Chevron', 'NYSE', Colors.amberAccent),
    popularStockChartItem('AMD', 'AMD', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('MRK', 'Merck', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('CSCO', 'Cisco', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('WFC', 'Wells Fargo', 'NYSE', _blue),
    popularStockChartItem('MCD', 'McDonald\'s', 'NYSE', _cyan),
    popularStockChartItem('PEP', 'PepsiCo', 'NASDAQ', _purple),
    popularStockChartItem('LIN', 'Linde', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('ADBE', 'Adobe', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('TMO', 'Thermo Fisher', 'NYSE', Colors.redAccent),
    popularStockChartItem('GE', 'GE Aerospace', 'NYSE', Colors.amberAccent),
    popularStockChartItem('IBM', 'IBM', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('QCOM', 'Qualcomm', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('CAT', 'Caterpillar', 'NYSE', Colors.tealAccent),
    popularStockChartItem('INTU', 'Intuit', 'NASDAQ', _blue),
    popularStockChartItem('DIS', 'Disney', 'NYSE', _cyan),
    popularStockChartItem('TXN', 'Texas Instruments', 'NASDAQ', _purple),
    popularStockChartItem('AMAT', 'Applied Materials', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('GS', 'Goldman Sachs', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('NOW', 'ServiceNow', 'NYSE', Colors.redAccent),
    popularStockChartItem('ISRG', 'Intuitive Surgical', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('VZ', 'Verizon', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('RTX', 'RTX', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('BKNG', 'Booking Holdings', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('SPGI', 'S&P Global', 'NYSE', _blue),
    popularStockChartItem('LOW', 'Lowe\'s', 'NYSE', _cyan),
    popularStockChartItem('PFE', 'Pfizer', 'NYSE', _purple),
    popularStockChartItem('HON', 'Honeywell', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('NKE', 'Nike', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('UBER', 'Uber', 'NYSE', Colors.redAccent),
    popularStockChartItem('CMCSA', 'Comcast', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('AMGN', 'Amgen', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('BA', 'Boeing', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('UNP', 'Union Pacific', 'NYSE', Colors.tealAccent),
    popularStockChartItem('SBUX', 'Starbucks', 'NASDAQ', _blue),
    popularStockChartItem('PANW', 'Palo Alto Networks', 'NASDAQ', _cyan),
    popularStockChartItem('PLTR', 'Palantir', 'NASDAQ', _purple),
    popularStockChartItem('MU', 'Micron', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('LRCX', 'Lam Research', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('ADP', 'ADP', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('DE', 'Deere', 'NYSE', Colors.amberAccent),
    popularStockChartItem('GILD', 'Gilead Sciences', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('COP', 'ConocoPhillips', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('TJX', 'TJX Companies', 'NYSE', Colors.tealAccent),
    popularStockChartItem('ADI', 'Analog Devices', 'NASDAQ', _blue),
    popularStockChartItem('C', 'Citigroup', 'NYSE', _cyan),
    popularStockChartItem('APP', 'AppLovin', 'NASDAQ', _purple),
    popularStockChartItem('SCHW', 'Charles Schwab', 'NYSE', Colors.greenAccent),
    popularStockChartItem('ANET', 'Arista Networks', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('MDLZ', 'Mondelez', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('SYK', 'Stryker', 'NYSE', Colors.amberAccent),
    popularStockChartItem('BLK', 'BlackRock', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('ETN', 'Eaton', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('MMC', 'Marsh McLennan', 'NYSE', Colors.tealAccent),
    popularStockChartItem('REGN', 'Regeneron', 'NASDAQ', _blue),
    popularStockChartItem('VRTX', 'Vertex Pharma', 'NASDAQ', _cyan),
    popularStockChartItem('LMT', 'Lockheed Martin', 'NYSE', _purple),
    popularStockChartItem('ELV', 'Elevance Health', 'NYSE', Colors.greenAccent),
    popularStockChartItem('UPS', 'UPS', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('PGR', 'Progressive', 'NYSE', Colors.redAccent),
    popularStockChartItem('AMT', 'American Tower', 'NYSE', Colors.amberAccent),
    popularStockChartItem('NEE', 'NextEra Energy', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('SO', 'Southern Company', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('KLAC', 'KLA', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('BX', 'Blackstone', 'NYSE', _blue),
    popularStockChartItem('KKR', 'KKR', 'NYSE', _cyan),
    popularStockChartItem('SHOP', 'Shopify', 'NASDAQ', _purple),
    popularStockChartItem('MELI', 'MercadoLibre', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('ABNB', 'Airbnb', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('RIVN', 'Rivian 리비안 EV', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('SNOW', 'Snowflake', 'NYSE', Colors.amberAccent),
    popularStockChartItem('COIN', 'Coinbase', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('MSTR', 'MicroStrategy', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('HOOD', 'Robinhood', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('GOOG', 'Alphabet Class C', 'NASDAQ', _blue),
    popularStockChartItem('ASML', 'ASML Holding', 'NASDAQ', _cyan),
    popularStockChartItem('INTC', 'Intel', 'NASDAQ', _purple),
    popularStockChartItem('ARM', 'Arm Holdings', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('TMUS', 'T-Mobile US', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('STX', 'Seagate Technology', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('MRVL', 'Marvell Technology', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('WDC', 'Western Digital', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('CRWD', 'CrowdStrike', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('PDD', 'PDD Holdings', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('CEG', 'Constellation Energy', 'NASDAQ', _blue),
    popularStockChartItem('CDNS', 'Cadence Design Systems', 'NASDAQ', _cyan),
    popularStockChartItem('SNPS', 'Synopsys', 'NASDAQ', _purple),
    popularStockChartItem('MAR', 'Marriott International', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('FTNT', 'Fortinet', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('CSX', 'CSX', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('MNST', 'Monster Beverage', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('NXPI', 'NXP Semiconductors', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('MPWR', 'Monolithic Power Systems', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('DDOG', 'Datadog', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('ROST', 'Ross Stores', 'NASDAQ', _blue),
    popularStockChartItem('ORLY', 'O\'Reilly Automotive', 'NASDAQ', _cyan),
    popularStockChartItem('AEP', 'American Electric Power', 'NASDAQ', _purple),
    popularStockChartItem('CTAS', 'Cintas', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('WBD', 'Warner Bros. Discovery', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('DASH', 'DoorDash', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('BKR', 'Baker Hughes', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('PCAR', 'PACCAR', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('FANG', 'Diamondback Energy', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('MCHP', 'Microchip Technology', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('FAST', 'Fastenal', 'NASDAQ', _blue),
    popularStockChartItem('EA', 'Electronic Arts', 'NASDAQ', _cyan),
    popularStockChartItem('XEL', 'Xcel Energy', 'NASDAQ', _purple),
    popularStockChartItem('ADSK', 'Autodesk', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('FER', 'Ferrovial', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('EXC', 'Exelon', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('ODFL', 'Old Dominion Freight Line', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('IDXX', 'IDEXX Laboratories', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('CCEP', 'Coca-Cola Europacific Partners', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('TTWO', 'Take-Two Interactive', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('KDP', 'Keurig Dr Pepper', 'NASDAQ', _blue),
    popularStockChartItem('ALNY', 'Alnylam Pharmaceuticals', 'NASDAQ', _cyan),
    popularStockChartItem('PYPL', 'PayPal', 'NASDAQ', _purple),
    popularStockChartItem('TRI', 'Thomson Reuters', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('PAYX', 'Paychex', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('ROP', 'Roper Technologies', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('CPRT', 'Copart', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('AXON', 'Axon Enterprise', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('WDAY', 'Workday', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('ZS', 'Zscaler', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('GEHC', 'GE HealthCare', 'NASDAQ', _blue),
    popularStockChartItem('KHC', 'Kraft Heinz', 'NASDAQ', _cyan),
    popularStockChartItem('DXCM', 'DexCom', 'NASDAQ', _purple),
    popularStockChartItem('CTSH', 'Cognizant Technology Solutions', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('INSM', 'Insmed', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('VRSK', 'Verisk Analytics', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('TEAM', 'Atlassian', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('CHTR', 'Charter Communications', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('CSGP', 'CoStar Group', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('IONQ', 'IonQ Quantum Computing 퀀텀컴퓨팅', 'NYSE', _cyan),
    popularStockChartItem('RGTI', 'Rigetti Quantum Computing 퀀텀컴퓨팅', 'NASDAQ', Colors.deepPurpleAccent),
    popularStockChartItem('QUBT', 'Quantum Computing Inc 퀀텀컴퓨팅', 'NASDAQ', Colors.lightGreenAccent),
    popularStockChartItem('QBTS', 'D-Wave Quantum Computing 퀀텀컴퓨팅', 'NYSE', Colors.indigoAccent),
    popularEtfChartItem('QTUM', 'Defiance Quantum ETF 퀀텀컴퓨팅', 'AMEX', Colors.cyanAccent),
    popularEtfChartItem('SPY', 'SPDR S&P 500 ETF Trust', 'AMEX', _blue),
    popularEtfChartItem('QQQ', 'Invesco QQQ Trust', 'NASDAQ', _cyan),
    popularEtfChartItem('VOO', 'Vanguard S&P 500 ETF', 'AMEX', _purple),
    popularEtfChartItem('IVV', 'iShares Core S&P 500 ETF', 'AMEX', Colors.greenAccent),
    popularEtfChartItem('VTI', 'Vanguard Total Stock Market ETF', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('IWM', 'iShares Russell 2000 ETF', 'AMEX', Colors.redAccent),
    popularEtfChartItem('DIA', 'SPDR Dow Jones Industrial Average ETF', 'AMEX', Colors.amberAccent),
    popularEtfChartItem('SCHD', 'Schwab U.S. Dividend Equity ETF', 'AMEX', Colors.lightBlueAccent),
    popularEtfChartItem('VGT', 'Vanguard Information Technology ETF', 'AMEX', Colors.pinkAccent),
    popularEtfChartItem('XLK', 'Technology Select Sector SPDR Fund', 'AMEX', Colors.tealAccent),
    popularEtfChartItem('XLF', 'Financial Select Sector SPDR Fund', 'AMEX', _blue),
    popularEtfChartItem('XLE', 'Energy Select Sector SPDR Fund', 'AMEX', _cyan),
    popularEtfChartItem('XLV', 'Health Care Select Sector SPDR Fund', 'AMEX', _purple),
    popularEtfChartItem('XLI', 'Industrial Select Sector SPDR Fund', 'AMEX', Colors.greenAccent),
    popularEtfChartItem('XLY', 'Consumer Discretionary Select Sector SPDR Fund', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('XLP', 'Consumer Staples Select Sector SPDR Fund', 'AMEX', Colors.redAccent),
    popularEtfChartItem('XLU', 'Utilities Select Sector SPDR Fund', 'AMEX', Colors.amberAccent),
    popularEtfChartItem('XLB', 'Materials Select Sector SPDR Fund', 'AMEX', Colors.lightBlueAccent),
    popularEtfChartItem('XLRE', 'Real Estate Select Sector SPDR Fund', 'AMEX', Colors.pinkAccent),
    popularEtfChartItem('SMH', 'VanEck Semiconductor ETF', 'NASDAQ', Colors.tealAccent),
    popularEtfChartItem('SOXX', 'iShares Semiconductor ETF', 'NASDAQ', _blue),
    popularEtfChartItem('ARKK', 'ARK Innovation ETF', 'AMEX', _cyan),
    popularEtfChartItem('TLT', 'iShares 20+ Year Treasury Bond ETF', 'NASDAQ', _purple),
    popularEtfChartItem('HYG', 'iShares iBoxx High Yield Corporate Bond ETF', 'AMEX', Colors.greenAccent),
    popularEtfChartItem('LQD', 'iShares iBoxx Investment Grade Corporate Bond ETF', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('BND', 'Vanguard Total Bond Market ETF', 'NASDAQ', Colors.redAccent),
    popularEtfChartItem('AGG', 'iShares Core U.S. Aggregate Bond ETF', 'AMEX', Colors.amberAccent),
    popularEtfChartItem('SHY', 'iShares 1-3 Year Treasury Bond ETF', 'NASDAQ', Colors.lightBlueAccent),
    popularEtfChartItem('IEF', 'iShares 7-10 Year Treasury Bond ETF', 'NASDAQ', Colors.pinkAccent),
    popularEtfChartItem('GLD', 'SPDR Gold Shares', 'AMEX', Colors.tealAccent),
    popularEtfChartItem('SLV', 'iShares Silver Trust', 'AMEX', _blue),
    popularEtfChartItem('USO', 'United States Oil Fund', 'AMEX', _cyan),
    popularEtfChartItem('UNG', 'United States Natural Gas Fund', 'AMEX', _purple),
    popularEtfChartItem('EEM', 'iShares MSCI Emerging Markets ETF', 'AMEX', Colors.greenAccent),
    popularEtfChartItem('EFA', 'iShares MSCI EAFE ETF', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('VXUS', 'Vanguard Total International Stock ETF', 'NASDAQ', Colors.redAccent),
    popularEtfChartItem('VEA', 'Vanguard FTSE Developed Markets ETF', 'AMEX', Colors.amberAccent),
    popularEtfChartItem('VNQ', 'Vanguard Real Estate ETF', 'AMEX', Colors.lightBlueAccent),
    popularEtfChartItem('QQQM', 'Invesco NASDAQ 100 ETF', 'NASDAQ', Colors.pinkAccent),
    popularEtfChartItem('SQQQ', 'ProShares UltraPro Short QQQ', 'NASDAQ', Colors.tealAccent),
    popularEtfChartItem('SOXL', 'Direxion Daily Semiconductor Bull 3X Shares', 'AMEX', _blue),
    popularEtfChartItem('TECL', 'Direxion Daily Technology Bull 3X Shares', 'AMEX', _cyan),
    popularEtfChartItem('SPXL', 'Direxion Daily S&P 500 Bull 3X Shares', 'AMEX', _purple),
    popularEtfChartItem('UPRO', 'ProShares UltraPro S&P500', 'AMEX', Colors.greenAccent),
    popularEtfChartItem('TNA', 'Direxion Daily Small Cap Bull 3X Shares', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('JEPI', 'JPMorgan Equity Premium Income ETF', 'AMEX', Colors.redAccent),
    popularEtfChartItem('JEPQ', 'JPMorgan Nasdaq Equity Premium Income ETF', 'NASDAQ', Colors.amberAccent),
    popularEtfChartItem('QYLD', 'Global X Nasdaq 100 Covered Call ETF', 'NASDAQ', Colors.lightBlueAccent),
    popularEtfChartItem('IBIT', 'iShares Bitcoin Trust ETF', 'NASDAQ', Colors.pinkAccent),
    popularEtfChartItem('BITO', 'ProShares Bitcoin Strategy ETF', 'AMEX', Colors.tealAccent),
    commodityChartItem('gold', 'Gold Futures', 'COMEX:GC1!', 'COMEX-GC1!', Colors.amberAccent),
    commodityChartItem('silver', 'Silver Futures', 'COMEX:SI1!', 'COMEX-SI1!', Colors.lightBlueAccent),
    commodityChartItem('copper', 'Copper Futures', 'COMEX:HG1!', 'COMEX-HG1!', Colors.orangeAccent),
    commodityChartItem('platinum', 'Platinum Futures', 'NYMEX:PL1!', 'NYMEX-PL1!', Colors.blueGrey),
    commodityChartItem('palladium', 'Palladium Futures', 'NYMEX:PA1!', 'NYMEX-PA1!', Colors.purpleAccent),
    commodityChartItem('wtiCrude', 'WTI Crude Oil Futures', 'NYMEX:CL1!', 'NYMEX-CL1!', Colors.greenAccent),
    commodityChartItem('brentCrude', 'Brent Crude Oil Futures', 'NYMEX:BRN1!', 'NYMEX-BRN1!', Colors.tealAccent),
    commodityChartItem('naturalGas', 'Natural Gas Futures', 'NYMEX:NG1!', 'NYMEX-NG1!', _blue),
    commodityChartItem('gasoline', 'Gasoline RBOB Futures', 'NYMEX:RB1!', 'NYMEX-RB1!', Colors.redAccent),
    commodityChartItem('heatingOil', 'Heating Oil Futures', 'NYMEX:HO1!', 'NYMEX-HO1!', _cyan),
    commodityChartItem('corn', 'Corn Futures', 'CBOT:ZC1!', 'CBOT-ZC1!', Colors.amberAccent),
    commodityChartItem('wheat', 'Wheat Futures', 'CBOT:ZW1!', 'CBOT-ZW1!', Colors.orangeAccent),
    commodityChartItem('soybeans', 'Soybean Futures', 'CBOT:ZS1!', 'CBOT-ZS1!', Colors.greenAccent),
    commodityChartItem('soybeanOil', 'Soybean Oil Futures', 'CBOT:ZL1!', 'CBOT-ZL1!', Colors.tealAccent),
    commodityChartItem('soybeanMeal', 'Soybean Meal Futures', 'CBOT:ZM1!', 'CBOT-ZM1!', Colors.lightGreenAccent),
    commodityChartItem('oats', 'Oats Futures', 'CBOT:ZO1!', 'CBOT-ZO1!', Colors.brown),
    commodityChartItem('roughRice', 'Rough Rice Futures', 'CBOT:ZR1!', 'CBOT-ZR1!', Colors.lightBlueAccent),
    commodityChartItem('coffee', 'Coffee C Futures', 'ICEUS:KC1!', 'ICEUS-KC1!', Colors.brown),
    commodityChartItem('sugar', 'Sugar No. 11 Futures', 'ICEUS:SB1!', 'ICEUS-SB1!', Colors.pinkAccent),
    commodityChartItem('cocoa', 'Cocoa Futures', 'ICEUS:CC1!', 'ICEUS-CC1!', Colors.deepOrangeAccent),
    commodityChartItem('cotton', 'Cotton Futures', 'ICEUS:CT1!', 'ICEUS-CT1!', Colors.white70),
    commodityChartItem('orangeJuice', 'Orange Juice Futures', 'ICEUS:OJ1!', 'ICEUS-OJ1!', Colors.orangeAccent),
    commodityChartItem('lumber', 'Lumber Futures', 'CME:LBR1!', 'CME-LBR1!', Colors.brown),
    commodityChartItem('liveCattle', 'Live Cattle Futures', 'CME:LE1!', 'CME-LE1!', Colors.redAccent),
    commodityChartItem('feederCattle', 'Feeder Cattle Futures', 'CME:GF1!', 'CME-GF1!', Colors.deepOrangeAccent),
    commodityChartItem('leanHogs', 'Lean Hogs Futures', 'CME:HE1!', 'CME-HE1!', Colors.pinkAccent),
    commodityChartItem('milk', 'Class III Milk Futures', 'CME:DC1!', 'CME-DC1!', Colors.white70),
    commodityChartItem('ironOre', 'Iron Ore Futures', 'SGX:FEF1!', 'SGX-FEF1!', Colors.redAccent),
    commodityChartItem('aluminum', 'Aluminum Futures', 'COMEX:ALI1!', 'COMEX-ALI1!', Colors.blueGrey),
    commodityChartItem('zinc', 'Zinc Futures', 'COMEX:ZNC1!', 'COMEX-ZNC1!', Colors.lightBlueAccent),
    commodityChartItem('nickel', 'Nickel Futures', 'COMEX:NIC1!', 'COMEX-NIC1!', Colors.greenAccent),
    commodityChartItem('lead', 'Lead Futures', 'COMEX:LED1!', 'COMEX-LED1!', Colors.grey),
    commodityChartItem('tin', 'Tin Futures', 'COMEX:TIN1!', 'COMEX-TIN1!', Colors.cyanAccent),
    commodityChartItem('coal', 'Coal Futures', 'NYMEX:QX1!', 'NYMEX-QX1!', Colors.grey),
    commodityChartItem('uranium', 'Uranium Futures', 'NYMEX:UX1!', 'NYMEX-UX1!', Colors.lightGreenAccent),
    commodityChartItem('ethanol', 'Ethanol Futures', 'CBOT:EH1!', 'CBOT-EH1!', Colors.greenAccent),
    commodityChartItem('canola', 'Canola Futures', 'ICEUS:RS1!', 'ICEUS-RS1!', Colors.yellowAccent),
    commodityChartItem('rapeseed', 'Rapeseed Futures', 'EURONEXT:COM1!', 'EURONEXT-COM1!', Colors.yellowAccent),
    commodityChartItem('palmOil', 'Palm Oil Futures', 'MYX:FCPO1!', 'MYX-FCPO1!', Colors.orangeAccent),
    commodityChartItem('rubber', 'Rubber Futures', 'OSE:RSS31!', 'OSE-RSS31!', Colors.blueGrey),
    commodityChartItem('propane', 'Propane Futures', 'NYMEX:PN1!', 'NYMEX-PN1!', Colors.cyanAccent),
    commodityChartItem('diesel', 'Diesel Futures', 'NYMEX:ULSD1!', 'NYMEX-ULSD1!', Colors.tealAccent),
    commodityChartItem('gasoil', 'Low Sulphur Gasoil Futures', 'ICEEUR:QS1!', 'ICEEUR-QS1!', Colors.lightBlueAccent),
    commodityChartItem('carbon', 'Carbon Emissions Futures', 'ICEEUR:ECF1!', 'ICEEUR-ECF1!', Colors.greenAccent),
    commodityChartItem('usDollarIndex', 'US Dollar Index Futures', 'ICEUS:DX1!', 'ICEUS-DX1!', _cyan),
    commodityChartItem('balticDry', 'Baltic Dry Index', 'INDEX:BDI', 'INDEX-BDI', _blue),
    commodityChartItem('freight', 'Freight Futures', 'CME:FBX1!', 'CME-FBX1!', _purple),
    commodityChartItem('goldSpot', 'Gold Spot', 'TVC:GOLD', 'TVC-GOLD', Colors.amberAccent),
    commodityChartItem('silverSpot', 'Silver Spot', 'TVC:SILVER', 'TVC-SILVER', Colors.lightBlueAccent),
    commodityChartItem('copperSpot', 'Copper Spot', 'TVC:COPPER', 'TVC-COPPER', Colors.orangeAccent),
    globalMegaCapChartItem('tsmc', 'TSM  TSMC', 'NYSE:TSM', 'NYSE-TSM', _blue),
    globalMegaCapChartItem('samsungElectronics', '005930  Samsung Electronics 삼성전자', 'KRX:005930', 'KRX-005930', _cyan),
    globalMegaCapChartItem('saudiAramco', '2222  Saudi Aramco', 'TADAWUL:2222', 'TADAWUL-2222', _purple),
    globalMegaCapChartItem('tencent', '0700  Tencent Holdings', 'HKEX:0700', 'HKEX-0700', Colors.greenAccent),
    globalMegaCapChartItem('alibaba', '9988  Alibaba Group', 'HKEX:9988', 'HKEX-9988', Colors.orangeAccent),
    globalMegaCapChartItem('novoNordisk', 'NOVO_B  Novo Nordisk', 'OMXCOP:NOVO_B', 'OMXCOP-NOVO_B', Colors.redAccent),
    globalMegaCapChartItem('lvmh', 'MC  LVMH', 'EURONEXT:MC', 'EURONEXT-MC', Colors.amberAccent),
    globalMegaCapChartItem('toyota', '7203  Toyota Motor', 'TSE:7203', 'TSE-7203', Colors.lightBlueAccent),
    globalMegaCapChartItem('sap', 'SAP  SAP', 'XETR:SAP', 'XETR-SAP', Colors.pinkAccent),
    globalMegaCapChartItem('nestle', 'NESN  Nestle', 'SIX:NESN', 'SIX-NESN', Colors.tealAccent),
    globalMegaCapChartItem('roche', 'ROG  Roche', 'SIX:ROG', 'SIX-ROG', _blue),
    globalMegaCapChartItem('novartis', 'NOVN  Novartis', 'SIX:NOVN', 'SIX-NOVN', _cyan),
    globalMegaCapChartItem('astrazeneca', 'AZN  AstraZeneca', 'LSE:AZN', 'LSE-AZN', _purple),
    globalMegaCapChartItem('shell', 'SHEL  Shell', 'LSE:SHEL', 'LSE-SHEL', Colors.greenAccent),
    globalMegaCapChartItem('hsbc', 'HSBA  HSBC Holdings', 'LSE:HSBA', 'LSE-HSBA', Colors.orangeAccent),
    globalMegaCapChartItem('bhp', 'BHP  BHP Group', 'ASX:BHP', 'ASX-BHP', Colors.redAccent),
    globalMegaCapChartItem('catl', '300750  CATL', 'SZSE:300750', 'SZSE-300750', Colors.amberAccent),
    globalMegaCapChartItem('sony', '6758  Sony Group', 'TSE:6758', 'TSE-6758', Colors.lightBlueAccent),
    globalMegaCapChartItem('mufg', '8306  Mitsubishi UFJ', 'TSE:8306', 'TSE-8306', Colors.pinkAccent),
    globalMegaCapChartItem('reliance', 'RELIANCE  Reliance Industries', 'NSE:RELIANCE', 'NSE-RELIANCE', Colors.tealAccent),
    globalMegaCapChartItem('icbc', '1398  ICBC', 'HKEX:1398', 'HKEX-1398', _blue),
    globalMegaCapChartItem('chinaMobile', '0941  China Mobile', 'HKEX:0941', 'HKEX-0941', _cyan),
    globalMegaCapChartItem('meituan', '3690  Meituan', 'HKEX:3690', 'HKEX-3690', _purple),
    globalMegaCapChartItem('byd', '1211  BYD', 'HKEX:1211', 'HKEX-1211', Colors.greenAccent),
    globalMegaCapChartItem('hermes', 'RMS  Hermes', 'EURONEXT:RMS', 'EURONEXT-RMS', Colors.orangeAccent),
    globalMegaCapChartItem('siemens', 'SIE  Siemens', 'XETR:SIE', 'XETR-SIE', Colors.redAccent),
    globalMegaCapChartItem('totalEnergies', 'TTE  TotalEnergies', 'EURONEXT:TTE', 'EURONEXT-TTE', Colors.amberAccent),
    globalMegaCapChartItem('commonwealthBank', 'CBA  Commonwealth Bank', 'ASX:CBA', 'ASX-CBA', Colors.lightBlueAccent),
    globalMegaCapChartItem('unilever', 'ULVR  Unilever', 'LSE:ULVR', 'LSE-ULVR', Colors.pinkAccent),
    globalMegaCapChartItem('aia', '1299  AIA Group', 'HKEX:1299', 'HKEX-1299', Colors.tealAccent),
    cryptoChartItem('BTC', 'Bitcoin', Colors.amberAccent),
    cryptoChartItem('ETH', 'Ethereum', _blue),
    cryptoChartItem('USDT', 'Tether', Colors.greenAccent),
    cryptoChartItem('XRP', 'XRP', Colors.lightBlueAccent),
    cryptoChartItem('BNB', 'BNB', Colors.orangeAccent),
    cryptoChartItem('SOL', 'Solana', _purple),
    cryptoChartItem('USDC', 'USD Coin', _cyan),
    cryptoChartItem('TRX', 'TRON', Colors.redAccent),
    cryptoChartItem('DOGE', 'Dogecoin', Colors.amberAccent),
    cryptoChartItem('ADA', 'Cardano', Colors.blueAccent),
    cryptoChartItem('HYPE', 'Hyperliquid', Colors.greenAccent),
    cryptoChartItem('SUI', 'Sui', Colors.lightBlueAccent),
    cryptoChartItem('BCH', 'Bitcoin Cash', Colors.orangeAccent),
    cryptoChartItem('LINK', 'Chainlink', _blue),
    cryptoChartItem('XLM', 'Stellar', _cyan),
    cryptoChartItem('AVAX', 'Avalanche', Colors.redAccent),
    cryptoChartItem('LEO', 'UNUS SED LEO', Colors.purpleAccent),
    cryptoChartItem('TON', 'Toncoin', Colors.lightBlueAccent),
    cryptoChartItem('LTC', 'Litecoin', Colors.blueGrey),
    cryptoChartItem('SHIB', 'Shiba Inu', Colors.orangeAccent),
    cryptoChartItem('HBAR', 'Hedera', Colors.white70),
    cryptoChartItem('DOT', 'Polkadot', Colors.pinkAccent),
    cryptoChartItem('UNI', 'Uniswap', _purple),
    cryptoChartItem('XMR', 'Monero', Colors.orangeAccent),
    cryptoChartItem('DAI', 'Dai', Colors.amberAccent),
    cryptoChartItem('APT', 'Aptos', Colors.tealAccent),
    cryptoChartItem('PEPE', 'Pepe', Colors.greenAccent),
    cryptoChartItem('OKB', 'OKB', Colors.blueAccent),
    cryptoChartItem('TAO', 'Bittensor', Colors.purpleAccent),
    cryptoChartItem('ICP', 'Internet Computer', Colors.redAccent),
    cryptoChartItem('ETC', 'Ethereum Classic', Colors.greenAccent),
    cryptoChartItem('NEAR', 'NEAR Protocol', Colors.lightGreenAccent),
    cryptoChartItem('AAVE', 'Aave', _blue),
    cryptoChartItem('ONDO', 'Ondo', Colors.lightBlueAccent),
    cryptoChartItem('POL', 'Polygon Ecosystem Token', _purple),
    cryptoChartItem('KAS', 'Kaspa', Colors.cyanAccent),
    cryptoChartItem('CRO', 'Cronos', Colors.blueAccent),
    cryptoChartItem('ATOM', 'Cosmos', Colors.indigoAccent),
    cryptoChartItem('ALGO', 'Algorand', Colors.grey),
    cryptoChartItem('VET', 'VeChain', Colors.tealAccent),
    cryptoChartItem('FIL', 'Filecoin', Colors.lightBlueAccent),
    cryptoChartItem('ARB', 'Arbitrum', _blue),
    cryptoChartItem('KCS', 'KuCoin Token', Colors.greenAccent),
    cryptoChartItem('OP', 'Optimism', Colors.redAccent),
    cryptoChartItem('WLD', 'Worldcoin', Colors.white70),
    cryptoChartItem('SEI', 'Sei', Colors.redAccent),
    cryptoChartItem('BONK', 'Bonk', Colors.orangeAccent),
    cryptoChartItem('INJ', 'Injective', Colors.cyanAccent),
    cryptoChartItem('FET', 'Artificial Superintelligence Alliance', Colors.greenAccent),
    cryptoChartItem('RENDER', 'Render', Colors.purpleAccent),
    popularEtfChartItem('EWY', 'iShares MSCI South Korea ETF', 'AMEX', _blue),
    popularEtfChartItem('EWJ', 'iShares MSCI Japan ETF', 'AMEX', _cyan),
    popularEtfChartItem('FXI', 'iShares China Large-Cap ETF', 'AMEX', _purple),
    popularEtfChartItem('MCHI', 'iShares MSCI China ETF', 'NASDAQ', Colors.greenAccent),
    popularEtfChartItem('EWT', 'iShares MSCI Taiwan ETF', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('INDA', 'iShares MSCI India ETF', 'AMEX', Colors.redAccent),
    popularEtfChartItem('VGK', 'Vanguard FTSE Europe ETF', 'AMEX', Colors.amberAccent),
    popularEtfChartItem('EWG', 'iShares MSCI Germany ETF', 'AMEX', Colors.lightBlueAccent),
    popularEtfChartItem('EWQ', 'iShares MSCI France ETF', 'AMEX', Colors.pinkAccent),
    popularEtfChartItem('EWZ', 'iShares MSCI Brazil ETF', 'AMEX', Colors.tealAccent),
    popularEtfChartItem('EWW', 'iShares MSCI Mexico ETF', 'AMEX', _blue),
    macroChartItem('vix', 'VIX  Volatility Index', 'TVC:VIX', 'TVC-VIX', Colors.redAccent),
    popularEtfChartItem('UVXY', 'ProShares Ultra VIX Short-Term Futures ETF', 'AMEX', Colors.orangeAccent),
    popularEtfChartItem('SVXY', 'ProShares Short VIX Short-Term Futures ETF', 'AMEX', Colors.greenAccent),
    macroChartItem('move', 'MOVE  Bond Volatility Index', 'TVC:MOVE', 'TVC-MOVE', _purple),
    macroChartItem('vvix', 'VVIX  VIX Volatility Index', 'CBOE:VVIX', 'CBOE-VVIX', Colors.pinkAccent),
    macroChartItem('us10y', 'US10Y  U.S. 10-Year Yield', 'TVC:US10Y', 'TVC-US10Y', _blue),
    macroChartItem('us02y', 'US02Y  U.S. 2-Year Yield', 'TVC:US02Y', 'TVC-US02Y', _cyan),
    macroChartItem('us30y', 'US30Y  U.S. 30-Year Yield', 'TVC:US30Y', 'TVC-US30Y', Colors.amberAccent),
    popularStockChartItem('SMCI', 'Super Micro Computer', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('SOFI', 'SoFi Technologies 소파이 핀테크', 'NASDAQ', Colors.cyanAccent),
    popularStockChartItem('AFRM', 'Affirm 어펌 핀테크 BNPL', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('UPST', 'Upstart 업스타트 AI lending', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('RBLX', 'Roblox 로블록스 gaming metaverse', 'NYSE', Colors.redAccent),
    popularStockChartItem('NET', 'Cloudflare 클라우드플레어 cybersecurity', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('MDB', 'MongoDB 몽고디비 database', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('RDDT', 'Reddit 레딧 social media', 'NYSE', Colors.deepOrangeAccent),
    popularStockChartItem('HIMS', 'Hims & Hers 힘스 healthcare', 'NYSE', Colors.tealAccent),
    popularStockChartItem('CELH', 'Celsius 셀시어스 energy drink', 'NASDAQ', Colors.amberAccent),
    popularStockChartItem('DUOL', 'Duolingo 듀오링고 education AI', 'NASDAQ', Colors.lightGreenAccent),
    popularStockChartItem('CAVA', 'Cava 카바 restaurant', 'NYSE', Colors.yellowAccent),
    popularStockChartItem('SHAK', 'Shake Shack 쉐이크쉑 restaurant', 'NYSE', Colors.greenAccent),
    popularStockChartItem('ELF', 'e.l.f. Beauty 엘프뷰티 cosmetics', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('CART', 'Instacart 인스타카트 delivery', 'NASDAQ', Colors.lightGreenAccent),
    popularStockChartItem('TOST', 'Toast 토스트 restaurant tech', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('U', 'Unity Software 유니티 game engine', 'NYSE', Colors.blueAccent),
    popularStockChartItem('PATH', 'UiPath 유아이패스 automation AI', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('AI', 'C3.ai 씨쓰리에이아이 artificial intelligence', 'NYSE', Colors.purpleAccent),
    popularStockChartItem('SOUN', 'SoundHound AI 사운드하운드 AI', 'NASDAQ', Colors.deepPurpleAccent),
    popularStockChartItem('BBAI', 'BigBear.ai 빅베어 AI', 'NYSE', Colors.indigoAccent),
    popularStockChartItem('SERV', 'Serve Robotics 서브로보틱스 robot', 'NASDAQ', Colors.cyanAccent),
    popularStockChartItem('SYM', 'Symbotic 심보틱 robotics automation', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('TER', 'Teradyne 테라다인 robotics semiconductor', 'NASDAQ', Colors.blueAccent),
    popularStockChartItem('IRBT', 'iRobot 아이로봇 robotics', 'NASDAQ', Colors.grey),
    popularStockChartItem('OKLO', 'Oklo 오클로 nuclear SMR', 'NYSE', Colors.amberAccent),
    popularStockChartItem('SMR', 'NuScale 뉴스케일 SMR nuclear', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('LEU', 'Centrus Energy 센트러스 uranium nuclear', 'AMEX', Colors.greenAccent),
    popularStockChartItem('CCJ', 'Cameco 카메코 uranium nuclear', 'NYSE', Colors.lightGreenAccent),
    popularStockChartItem('UEC', 'Uranium Energy 우라늄에너지', 'AMEX', Colors.yellowAccent),
    popularStockChartItem('RKLB', 'Rocket Lab 로켓랩 space', 'NASDAQ', Colors.blueAccent),
    popularStockChartItem('ASTS', 'AST SpaceMobile 에이에스티 우주통신', 'NASDAQ', Colors.purpleAccent),
    popularStockChartItem('LUNR', 'Intuitive Machines 인튜이티브머신스 lunar space', 'NASDAQ', Colors.indigoAccent),
    popularStockChartItem('ACHR', 'Archer Aviation 아처항공 eVTOL', 'NYSE', Colors.cyanAccent),
    popularStockChartItem('JOBY', 'Joby Aviation 조비항공 eVTOL', 'NYSE', Colors.tealAccent),
    popularStockChartItem('EVTL', 'Vertical Aerospace 버티컬 eVTOL', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('BLDE', 'Blade Air Mobility 블레이드 항공모빌리티', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('LCID', 'Lucid 루시드 EV', 'NASDAQ', Colors.grey),
    popularStockChartItem('NIO', 'NIO 니오 중국 전기차 EV', 'NYSE', Colors.greenAccent),
    popularStockChartItem('LI', 'Li Auto 리오토 중국 전기차 EV', 'NASDAQ', Colors.lightGreenAccent),
    popularStockChartItem('XPEV', 'XPeng 샤오펑 중국 전기차 EV', 'NYSE', Colors.cyanAccent),
    popularStockChartItem('BABA', 'Alibaba 알리바바 중국 ecommerce', 'NYSE', Colors.orangeAccent),
    popularStockChartItem('BIDU', 'Baidu 바이두 중국 AI search', 'NASDAQ', Colors.blueAccent),
    popularStockChartItem('JD', 'JD.com 징동닷컴 중국 ecommerce', 'NASDAQ', Colors.redAccent),
    popularStockChartItem('TME', 'Tencent Music 텐센트뮤직 China music', 'NYSE', Colors.greenAccent),
    popularStockChartItem('BILI', 'Bilibili 빌리빌리 China video', 'NASDAQ', Colors.lightBlueAccent),
    popularStockChartItem('BEKE', 'KE Holdings 베이커 China real estate', 'NYSE', Colors.tealAccent),
    popularStockChartItem('YMM', 'Full Truck Alliance 만방 물류 China', 'NYSE', Colors.amberAccent),
    popularStockChartItem('SE', 'Sea Limited 씨 리미티드 동남아 ecommerce game', 'NYSE', Colors.deepPurpleAccent),
    popularStockChartItem('GRAB', 'Grab 그랩 동남아 super app', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('NU', 'Nu Holdings 누뱅크 fintech Brazil', 'NYSE', Colors.purpleAccent),
    popularStockChartItem('STNE', 'StoneCo 스톤코 Brazil fintech', 'NASDAQ', Colors.blueAccent),
    popularStockChartItem('PAGS', 'PagSeguro 팍세구로 Brazil fintech', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('CRSP', 'CRISPR Therapeutics 크리스퍼 gene editing', 'NASDAQ', Colors.greenAccent),
    popularStockChartItem('EDIT', 'Editas Medicine 에디타스 gene editing', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('BEAM', 'Beam Therapeutics 빔 gene editing', 'NASDAQ', Colors.pinkAccent),
    popularStockChartItem('NTLA', 'Intellia Therapeutics 인텔리아 gene editing', 'NASDAQ', Colors.cyanAccent),
    popularStockChartItem('DNA', 'Ginkgo Bioworks 깅코바이오웍스 biotech', 'NYSE', Colors.lightGreenAccent),
    popularStockChartItem('RXRX', 'Recursion Pharmaceuticals 리커전 AI biotech', 'NASDAQ', Colors.deepPurpleAccent),
    popularStockChartItem('TEM', 'Tempus AI 템퍼스 AI healthcare', 'NASDAQ', Colors.indigoAccent),
    popularStockChartItem('ENVX', 'Enovix 에노빅스 battery', 'NASDAQ', Colors.orangeAccent),
    popularStockChartItem('QS', 'QuantumScape 퀀텀스케이프 solid state battery', 'NYSE', Colors.amberAccent),
    popularStockChartItem('ALB', 'Albemarle 앨버말 lithium', 'NYSE', Colors.lightGreenAccent),
    popularStockChartItem('LAC', 'Lithium Americas 리튬아메리카스', 'NYSE', Colors.greenAccent),
    popularStockChartItem('PLL', 'Piedmont Lithium 피드몬트 리튬', 'NASDAQ', Colors.tealAccent),
    popularStockChartItem('DELL', 'Dell Technologies', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('HPE', 'Hewlett Packard Enterprise', 'NYSE', Colors.tealAccent),
    popularStockChartItem('VRT', 'Vertiv Holdings', 'NYSE', Colors.orangeAccent),
    globalMegaCapChartItem('skHynix', '000660  SK Hynix SK하이닉스 하이닉스', 'KRX:000660', 'KRX-000660', _purple),
    globalMegaCapChartItem('hyundaiMotor', '005380  Hyundai Motor 현대차 현대자동차', 'KRX:005380', 'KRX-005380', Colors.greenAccent),
    globalMegaCapChartItem('naver', '035420  NAVER 네이버', 'KRX:035420', 'KRX-035420', Colors.lightGreenAccent),
    globalMegaCapChartItem('kakao', '035720  Kakao 카카오', 'KRX:035720', 'KRX-035720', Colors.amberAccent),
    globalMegaCapChartItem('lgChem', '051910  LG Chem LG화학 엘지화학', 'KRX:051910', 'KRX-051910', Colors.redAccent),
    globalMegaCapChartItem('lgEnergySolution', '373220  LG Energy Solution LG에너지솔루션', 'KRX:373220', 'KRX-373220', Colors.cyanAccent),
    globalMegaCapChartItem('softbank', '9984  SoftBank Group', 'TSE:9984', 'TSE-9984', _blue),
    globalMegaCapChartItem('tokyoElectron', '8035  Tokyo Electron', 'TSE:8035', 'TSE-8035', _cyan),
    globalMegaCapChartItem('keyence', '6861  Keyence', 'TSE:6861', 'TSE-6861', _purple),
    globalMegaCapChartItem('shinEtsu', '4063  Shin-Etsu Chemical', 'TSE:4063', 'TSE-4063', Colors.greenAccent),
    globalMegaCapChartItem('recruit', '6098  Recruit Holdings', 'TSE:6098', 'TSE-6098', Colors.orangeAccent),
    popularStockChartItem('NOC', 'Northrop Grumman', 'NYSE', Colors.redAccent),
    popularStockChartItem('GD', 'General Dynamics', 'NYSE', Colors.lightBlueAccent),
    popularStockChartItem('LHX', 'L3Harris Technologies', 'NYSE', Colors.pinkAccent),
    popularStockChartItem('ETR', 'Entergy', 'NYSE', Colors.greenAccent),
    popularStockChartItem('VST', 'Vistra', 'NYSE', Colors.amberAccent),
    popularStockChartItem('PWR', 'Quanta Services', 'NYSE', Colors.tealAccent),
    countryLargeCapChartItem('krKia', '000270  Kia 기아 Korea auto EV 자동차', 'KRX:000270', 'KRX-000270', Colors.lightBlueAccent),
    countryLargeCapChartItem('krKbFinancial', '105560  KB Financial KB금융 Korea bank finance 은행', 'KRX:105560', 'KRX-105560', _blue),
    countryLargeCapChartItem('krShinhan', '055550  Shinhan Financial 신한지주 Korea bank finance 은행', 'KRX:055550', 'KRX-055550', _cyan),
    countryLargeCapChartItem('krHana', '086790  Hana Financial 하나금융지주 Korea bank finance 은행', 'KRX:086790', 'KRX-086790', _purple),
    countryLargeCapChartItem('krSamsungBio', '207940  Samsung Biologics 삼성바이오로직스 Korea biotech pharma 바이오', 'KRX:207940', 'KRX-207940', Colors.greenAccent),
    countryLargeCapChartItem('krCelltrion', '068270  Celltrion 셀트리온 Korea biotech pharma 바이오', 'KRX:068270', 'KRX-068270', Colors.tealAccent),
    countryLargeCapChartItem('krPosco', '005490  POSCO Holdings 포스코홀딩스 Korea steel materials 철강', 'KRX:005490', 'KRX-005490', Colors.blueGrey),
    countryLargeCapChartItem('krHanwhaAerospace', '012450  Hanwha Aerospace 한화에어로스페이스 Korea defense aerospace 방산', 'KRX:012450', 'KRX-012450', Colors.orangeAccent),
    countryLargeCapChartItem('krLge', '066570  LG Electronics LG전자 Korea electronics appliance 전자', 'KRX:066570', 'KRX-066570', Colors.redAccent),
    countryLargeCapChartItem('krSamsungSdi', '006400  Samsung SDI 삼성SDI Korea battery EV 배터리', 'KRX:006400', 'KRX-006400', Colors.greenAccent),
    countryLargeCapChartItem('krHyundaiMobis', '012330  Hyundai Mobis 현대모비스 Korea auto parts 자동차부품', 'KRX:012330', 'KRX-012330', Colors.lightGreenAccent),
    countryLargeCapChartItem('krKoreaAerospace', '047810  Korea Aerospace 한국항공우주 KAI Korea defense aerospace 항공우주', 'KRX:047810', 'KRX-047810', Colors.indigoAccent),
    countryLargeCapChartItem('krDoosanEnerbility', '034020  Doosan Enerbility 두산에너빌리티 Korea nuclear power energy 원전', 'KRX:034020', 'KRX-034020', Colors.cyanAccent),
    countryLargeCapChartItem('krLgHnh', '051900  LG H&H LG생활건강 Korea cosmetics consumer', 'KRX:051900', 'KRX-051900', Colors.pinkAccent),
    countryLargeCapChartItem('krLgCorp', '003550  LG Corp LG Korea holding electronics chemical', 'KRX:003550', 'KRX-003550', Colors.lightBlueAccent),
    countryLargeCapChartItem('krSkTelecom', '017670  SK Telecom SK텔레콤 Korea telecom AI', 'KRX:017670', 'KRX-017670', Colors.orangeAccent),
    countryLargeCapChartItem('krSkInnovation', '096770  SK Innovation SK이노베이션 Korea battery oil energy', 'KRX:096770', 'KRX-096770', Colors.greenAccent),
    countryLargeCapChartItem('krPoscoFutureM', '003670  POSCO Future M 포스코퓨처엠 Korea battery materials', 'KRX:003670', 'KRX-003670', Colors.tealAccent),
    countryLargeCapChartItem('krSamsungCnt', '028260  Samsung C&T 삼성물산 Korea construction trading', 'KRX:028260', 'KRX-028260', Colors.blueGrey),
    countryLargeCapChartItem('krSamsungLife', '032830  Samsung Life 삼성생명 Korea insurance finance', 'KRX:032830', 'KRX-032830', _blue),
    countryLargeCapChartItem('krSamsungSds', '018260  Samsung SDS 삼성에스디에스 Korea software cloud', 'KRX:018260', 'KRX-018260', _cyan),
    countryLargeCapChartItem('krKoreaZinc', '010130  Korea Zinc 고려아연 Korea materials metal zinc', 'KRX:010130', 'KRX-010130', Colors.blueGrey),
    countryLargeCapChartItem('krSamsungElectro', '009150  Samsung Electro-Mechanics 삼성전기 Korea electronics components', 'KRX:009150', 'KRX-009150', Colors.purpleAccent),
    countryLargeCapChartItem('krSoil', '010950  S-Oil 에쓰오일 Korea oil energy', 'KRX:010950', 'KRX-010950', Colors.redAccent),
    countryLargeCapChartItem('krHmm', '011200  HMM 에이치엠엠 Korea shipping logistics', 'KRX:011200', 'KRX-011200', Colors.lightBlueAccent),
    countryLargeCapChartItem('krEcopro', '086520  EcoPro 에코프로 Korea battery materials', 'KOSDAQ:086520', 'KOSDAQ-086520', Colors.lightGreenAccent),
    countryLargeCapChartItem('krEcoproBm', '247540  EcoPro BM 에코프로비엠 Korea battery materials', 'KOSDAQ:247540', 'KOSDAQ-247540', Colors.greenAccent),
    countryLargeCapChartItem('krOrion', '271560  Orion 오리온 Korea food consumer', 'KRX:271560', 'KRX-271560', Colors.amberAccent),
    countryLargeCapChartItem('krAmorepacific', '090430  Amorepacific 아모레퍼시픽 Korea cosmetics consumer', 'KRX:090430', 'KRX-090430', Colors.pinkAccent),
    countryLargeCapChartItem('krSamsungHeavy', '010140  Samsung Heavy Industries 삼성중공업 Korea shipbuilding industrial', 'KRX:010140', 'KRX-010140', Colors.blueAccent),
    countryLargeCapChartItem('krHyundaiElectric', '267260  HD Hyundai Electric HD현대일렉트릭 Korea power electric', 'KRX:267260', 'KRX-267260', Colors.cyanAccent),
    countryLargeCapChartItem('krHyundaiHeavy', '329180  HD Hyundai Heavy Industries HD현대중공업 Korea shipbuilding industrial', 'KRX:329180', 'KRX-329180', Colors.indigoAccent),
    countryLargeCapChartItem('krSkSquare', '402340  SK Square SK스퀘어 Korea technology investment', 'KRX:402340', 'KRX-402340', Colors.purpleAccent),
    countryLargeCapChartItem('jpHitachi', '6501  Hitachi 히타치 日立 Japan industrial infrastructure', 'TSE:6501', 'TSE-6501', Colors.greenAccent),
    countryLargeCapChartItem('jpMitsubishiCorp', '8058  Mitsubishi Corporation 미쓰비시상사 三菱商事 Japan trading energy', 'TSE:8058', 'TSE-8058', Colors.orangeAccent),
    countryLargeCapChartItem('jpItochu', '8001  Itochu 이토추 伊藤忠 Japan trading commerce', 'TSE:8001', 'TSE-8001', Colors.amberAccent),
    countryLargeCapChartItem('jpSumitomoMitsui', '8316  Sumitomo Mitsui SMFG 미쓰이스미토모 三井住友 Japan bank finance', 'TSE:8316', 'TSE-8316', _blue),
    countryLargeCapChartItem('jpMizuho', '8411  Mizuho Financial 미즈호 みずほ Japan bank finance', 'TSE:8411', 'TSE-8411', _cyan),
    countryLargeCapChartItem('jpNintendo', '7974  Nintendo 닌텐도 任天堂 Japan gaming game', 'TSE:7974', 'TSE-7974', Colors.redAccent),
    countryLargeCapChartItem('jpHonda', '7267  Honda 혼다 本田 Japan auto EV motorcycle', 'TSE:7267', 'TSE-7267', Colors.redAccent),
    countryLargeCapChartItem('jpMitsubishiHeavy', '7011  Mitsubishi Heavy Industries 미쓰비시중공업 三菱重工 Japan defense industrial', 'TSE:7011', 'TSE-7011', Colors.blueGrey),
    countryLargeCapChartItem('jpFastRetailing', '9983  Fast Retailing Uniqlo 패스트리테일링 유니클로 Japan retail apparel', 'TSE:9983', 'TSE-9983', Colors.pinkAccent),
    countryLargeCapChartItem('jpDaikin', '6367  Daikin 다이킨 ダイキン Japan industrial air conditioning', 'TSE:6367', 'TSE-6367', Colors.lightBlueAccent),
    countryLargeCapChartItem('jpFanuc', '6954  FANUC 화낙 ファナック Japan robotics automation robot', 'TSE:6954', 'TSE-6954', Colors.yellowAccent),
    countryLargeCapChartItem('jpMurata', '6981  Murata 무라타 村田製作所 Japan electronics components', 'TSE:6981', 'TSE-6981', Colors.tealAccent),
    countryLargeCapChartItem('jpDisco', '6146  Disco 디스코 ディスコ Japan semiconductor equipment', 'TSE:6146', 'TSE-6146', Colors.purpleAccent),
    countryLargeCapChartItem('jpNtt', '9432  Nippon Telegraph and Telephone NTT 일본전신전화 Japan telecom', 'TSE:9432', 'TSE-9432', Colors.blueAccent),
    countryLargeCapChartItem('jpKddi', '9433  KDDI 케이디디아이 Japan telecom', 'TSE:9433', 'TSE-9433', Colors.orangeAccent),
    countryLargeCapChartItem('jpSoftbankCorp', '9434  SoftBank Corp 소프트뱅크 Japan telecom', 'TSE:9434', 'TSE-9434', Colors.pinkAccent),
    countryLargeCapChartItem('jpSevenI', '3382  Seven & i 세븐앤아이 Japan retail convenience', 'TSE:3382', 'TSE-3382', Colors.greenAccent),
    countryLargeCapChartItem('jpTakeda', '4502  Takeda Pharmaceutical 다케다 武田 Japan pharma healthcare', 'TSE:4502', 'TSE-4502', Colors.lightBlueAccent),
    countryLargeCapChartItem('jpDaiichiSankyo', '4568  Daiichi Sankyo 다이이치산쿄 第一三共 Japan pharma healthcare', 'TSE:4568', 'TSE-4568', Colors.redAccent),
    countryLargeCapChartItem('jpChugai', '4519  Chugai Pharmaceutical 주가이 中外製薬 Japan pharma biotech', 'TSE:4519', 'TSE-4519', Colors.tealAccent),
    countryLargeCapChartItem('jpFujitsu', '6702  Fujitsu 후지쯔 富士通 Japan software technology', 'TSE:6702', 'TSE-6702', _blue),
    countryLargeCapChartItem('jpFujifilm', '4901  Fujifilm 후지필름 富士フイルム Japan healthcare materials', 'TSE:4901', 'TSE-4901', Colors.greenAccent),
    countryLargeCapChartItem('jpPanasonic', '6752  Panasonic 파나소닉 Japan electronics battery', 'TSE:6752', 'TSE-6752', Colors.lightBlueAccent),
    countryLargeCapChartItem('jpCanon', '7751  Canon 캐논 キヤノン Japan electronics camera', 'TSE:7751', 'TSE-7751', Colors.redAccent),
    countryLargeCapChartItem('jpSubaru', '7270  Subaru 스바루 Japan auto', 'TSE:7270', 'TSE-7270', Colors.blueAccent),
    countryLargeCapChartItem('jpNissan', '7201  Nissan 닛산 日産 Japan auto EV', 'TSE:7201', 'TSE-7201', Colors.orangeAccent),
    countryLargeCapChartItem('jpKomatsu', '6301  Komatsu 고마쓰 小松 Japan construction machinery', 'TSE:6301', 'TSE-6301', Colors.yellowAccent),
    countryLargeCapChartItem('jpNidec', '6594  Nidec 니덱 日本電産 Japan electric motor industrial', 'TSE:6594', 'TSE-6594', Colors.purpleAccent),
    countryLargeCapChartItem('cnPdd', 'PDD  PDD Holdings 핀둬둬 拼多多 China ecommerce', 'NASDAQ:PDD', 'NASDAQ-PDD', Colors.tealAccent),
    countryLargeCapChartItem('cnNetEase', '9999  NetEase 넷이즈 网易 網易 China gaming internet', 'HKEX:9999', 'HKEX-9999', Colors.redAccent),
    countryLargeCapChartItem('cnXiaomi', '1810  Xiaomi 샤오미 小米 China electronics EV smartphone', 'HKEX:1810', 'HKEX-1810', Colors.orangeAccent),
    countryLargeCapChartItem('cnJd', '9618  JD.com 징동닷컴 京东 京東 China ecommerce logistics', 'HKEX:9618', 'HKEX-9618', Colors.redAccent),
    countryLargeCapChartItem('cnBaidu', '9888  Baidu 바이두 百度 China AI search internet', 'HKEX:9888', 'HKEX-9888', Colors.blueAccent),
    countryLargeCapChartItem('cnCnooc', '0883  CNOOC 중국해양석유 中国海洋石油 China oil energy', 'HKEX:0883', 'HKEX-0883', Colors.greenAccent),
    countryLargeCapChartItem('cnPetroChina', '0857  PetroChina 페트로차이나 中国石油 China oil energy', 'HKEX:0857', 'HKEX-0857', Colors.redAccent),
    countryLargeCapChartItem('cnSinopec', '0386  Sinopec 시노펙 中国石化 China oil energy', 'HKEX:0386', 'HKEX-0386', Colors.pinkAccent),
    countryLargeCapChartItem('cnPingAn', '2318  Ping An Insurance 핑안보험 中国平安 China insurance finance', 'HKEX:2318', 'HKEX-2318', Colors.orangeAccent),
    countryLargeCapChartItem('cnCcb', '0939  China Construction Bank 건설은행 建设银行 China bank finance', 'HKEX:0939', 'HKEX-0939', _blue),
    countryLargeCapChartItem('cnBoc', '3988  Bank of China 중국은행 中国银行 China bank finance', 'HKEX:3988', 'HKEX-3988', _cyan),
    countryLargeCapChartItem('cnCmb', '3968  China Merchants Bank 초상은행 招商银行 China bank finance', 'HKEX:3968', 'HKEX-3968', _purple),
    countryLargeCapChartItem('cnKweichowMoutai', '600519  Kweichow Moutai 귀주모태 贵州茅台 China beverage liquor', 'SSE:600519', 'SSE-600519', Colors.amberAccent),
    countryLargeCapChartItem('cnWuliangye', '000858  Wuliangye 우량예 五粮液 China beverage liquor', 'SZSE:000858', 'SZSE-000858', Colors.deepOrangeAccent),
    countryLargeCapChartItem('cnFoxconnIndustrial', '601138  Foxconn Industrial Internet 폭스콘산업인터넷 工业富联 China electronics AI', 'SSE:601138', 'SSE-601138', Colors.blueGrey),
    countryLargeCapChartItem('cnLiAuto', '2015  Li Auto 리오토 理想汽车 China EV auto', 'HKEX:2015', 'HKEX-2015', Colors.lightGreenAccent),
    countryLargeCapChartItem('cnNio', '9866  NIO 니오 蔚来 China EV auto', 'HKEX:9866', 'HKEX-9866', Colors.cyanAccent),
    countryLargeCapChartItem('cnSmic', '0981  SMIC 중신국제 中芯国际 China semiconductor foundry', 'HKEX:0981', 'HKEX-0981', Colors.purpleAccent),
    countryLargeCapChartItem('cnTrip', '9961  Trip.com 트립닷컴 携程 China travel internet', 'HKEX:9961', 'HKEX-9961', Colors.lightBlueAccent),
    countryLargeCapChartItem('cnHaier', '6690  Haier Smart Home 하이얼 海尔智家 China appliance consumer', 'HKEX:6690', 'HKEX-6690', Colors.blueAccent),
    countryLargeCapChartItem('cnChinaLife', '2628  China Life Insurance 중국생명 中国人寿 China insurance finance', 'HKEX:2628', 'HKEX-2628', Colors.redAccent),
    countryLargeCapChartItem('cnShenhua', '1088  China Shenhua 중국신화 中国神华 China coal energy', 'HKEX:1088', 'HKEX-1088', Colors.grey),
    countryLargeCapChartItem('cnZijin', '2899  Zijin Mining 쯔진광업 紫金矿业 China mining gold copper', 'HKEX:2899', 'HKEX-2899', Colors.amberAccent),
    countryLargeCapChartItem('cnAnta', '2020  Anta Sports 안타 安踏 China sports apparel', 'HKEX:2020', 'HKEX-2020', Colors.redAccent),
    countryLargeCapChartItem('cnLiNing', '2331  Li Ning 리닝 李宁 China sports apparel', 'HKEX:2331', 'HKEX-2331', Colors.orangeAccent),
    countryLargeCapChartItem('cnNongfu', '9633  Nongfu Spring 농푸산취안 农夫山泉 China beverage consumer', 'HKEX:9633', 'HKEX-9633', Colors.lightBlueAccent),
    countryLargeCapChartItem('cnCrBeer', '0291  China Resources Beer 화룬맥주 华润啤酒 China beverage', 'HKEX:0291', 'HKEX-0291', Colors.greenAccent),
    countryLargeCapChartItem('cnChinaTower', '0788  China Tower 중국철탑 中国铁塔 China telecom infrastructure', 'HKEX:0788', 'HKEX-0788', Colors.blueGrey),
    countryLargeCapChartItem('cnGeely', '0175  Geely Auto 지리자동차 吉利汽车 China auto EV', 'HKEX:0175', 'HKEX-0175', Colors.cyanAccent),
    countryLargeCapChartItem('twHonHai', '2317  Hon Hai Foxconn 훙하이 鴻海 Taiwan electronics AI server', 'TWSE:2317', 'TWSE-2317', Colors.blueAccent),
    countryLargeCapChartItem('twMediatek', '2454  MediaTek 미디어텍 聯發科 Taiwan semiconductor chip', 'TWSE:2454', 'TWSE-2454', Colors.greenAccent),
    countryLargeCapChartItem('twQuanta', '2382  Quanta Computer 콴타 廣達 Taiwan AI server electronics', 'TWSE:2382', 'TWSE-2382', Colors.cyanAccent),
    countryLargeCapChartItem('twDelta', '2308  Delta Electronics 델타 台達電 Taiwan power electronics', 'TWSE:2308', 'TWSE-2308', Colors.lightGreenAccent),
    countryLargeCapChartItem('twFubon', '2881  Fubon Financial 푸본 富邦金 Taiwan bank insurance finance', 'TWSE:2881', 'TWSE-2881', _blue),
    countryLargeCapChartItem('twCathay', '2882  Cathay Financial 캐세이 國泰金 Taiwan insurance finance', 'TWSE:2882', 'TWSE-2882', _cyan),
    countryLargeCapChartItem('twChunghwa', '2412  Chunghwa Telecom 중화텔레콤 中華電 Taiwan telecom', 'TWSE:2412', 'TWSE-2412', Colors.tealAccent),
    countryLargeCapChartItem('twUmc', '2303  UMC 유나이티드마이크로 聯電 Taiwan semiconductor foundry', 'TWSE:2303', 'TWSE-2303', Colors.purpleAccent),
    countryLargeCapChartItem('twAsus', '2357  ASUS 에이수스 華碩 Taiwan electronics computer', 'TWSE:2357', 'TWSE-2357', Colors.indigoAccent),
    countryLargeCapChartItem('twAcer', '2353  Acer 에이서 宏碁 Taiwan electronics computer', 'TWSE:2353', 'TWSE-2353', Colors.greenAccent),
    countryLargeCapChartItem('twEsun', '2884  E.SUN Financial 옥산금융 玉山金 Taiwan bank finance', 'TWSE:2884', 'TWSE-2884', Colors.amberAccent),
    countryLargeCapChartItem('twMega', '2886  Mega Financial 메가금융 兆豐金 Taiwan bank finance', 'TWSE:2886', 'TWSE-2886', Colors.orangeAccent),
    countryLargeCapChartItem('twFirstFinancial', '2892  First Financial 제일금융 第一金 Taiwan bank finance', 'TWSE:2892', 'TWSE-2892', Colors.lightBlueAccent),
    countryLargeCapChartItem('twYuanta', '2885  Yuanta Financial 유안타 元大金 Taiwan brokerage finance', 'TWSE:2885', 'TWSE-2885', Colors.pinkAccent),
    countryLargeCapChartItem('twWistron', '3231  Wistron 위스트론 緯創 Taiwan AI server electronics', 'TWSE:3231', 'TWSE-3231', Colors.blueGrey),
    countryLargeCapChartItem('twLargan', '3008  Largan Precision 라간 大立光 Taiwan electronics optics', 'TWSE:3008', 'TWSE-3008', Colors.pinkAccent),
    countryLargeCapChartItem('twNovatek', '3034  Novatek 노바텍 聯詠 Taiwan semiconductor chip', 'TWSE:3034', 'TWSE-3034', Colors.purpleAccent),
    countryLargeCapChartItem('twRealtek', '2379  Realtek 리얼텍 瑞昱 Taiwan semiconductor chip', 'TWSE:2379', 'TWSE-2379', Colors.indigoAccent),
    countryLargeCapChartItem('twAse', '3711  ASE Technology ASE 日月光 Taiwan semiconductor packaging', 'TWSE:3711', 'TWSE-3711', Colors.greenAccent),
    countryLargeCapChartItem('twLiteon', '2301  Lite-On Technology 라이트온 光寶科 Taiwan electronics', 'TWSE:2301', 'TWSE-2301', Colors.lightBlueAccent),
    countryLargeCapChartItem('twPegatron', '4938  Pegatron 페가트론 和碩 Taiwan electronics manufacturing', 'TWSE:4938', 'TWSE-4938', Colors.blueAccent),
    countryLargeCapChartItem('twCompal', '2324  Compal 컴팔 仁寶 Taiwan electronics computer', 'TWSE:2324', 'TWSE-2324', Colors.orangeAccent),
    countryLargeCapChartItem('twInventec', '2356  Inventec 인벤텍 英業達 Taiwan electronics AI server', 'TWSE:2356', 'TWSE-2356', Colors.tealAccent),
    countryLargeCapChartItem('twAdvantech', '2395  Advantech 어드밴텍 研華 Taiwan industrial computer', 'TWSE:2395', 'TWSE-2395', Colors.greenAccent),
    countryLargeCapChartItem('twEInk', '8069  E Ink 이잉크 元太 Taiwan display electronics', 'TPEX:8069', 'TPEX-8069', Colors.grey),
    countryLargeCapChartItem('twEvergreenMarine', '2603  Evergreen Marine 에버그린 長榮 Taiwan shipping logistics', 'TWSE:2603', 'TWSE-2603', Colors.greenAccent),
    countryLargeCapChartItem('twYangMing', '2609  Yang Ming Marine 양밍 陽明 Taiwan shipping logistics', 'TWSE:2609', 'TWSE-2609', Colors.lightBlueAccent),
    countryLargeCapChartItem('twFormosaPlastics', '1301  Formosa Plastics 포모사 台塑 Taiwan chemical materials', 'TWSE:1301', 'TWSE-1301', Colors.orangeAccent),
    countryLargeCapChartItem('twNanYa', '1303  Nan Ya Plastics 난야 南亞 Taiwan chemical materials', 'TWSE:1303', 'TWSE-1303', Colors.redAccent),
    countryLargeCapChartItem('deAllianz', 'ALV  Allianz 알리안츠 Germany insurance finance', 'XETR:ALV', 'XETR-ALV', _blue),
    countryLargeCapChartItem('deSiemensEnergy', 'ENR  Siemens Energy 지멘스에너지 Germany energy industrial', 'XETR:ENR', 'XETR-ENR', Colors.greenAccent),
    countryLargeCapChartItem('deDeutscheTelekom', 'DTE  Deutsche Telekom 도이치텔레콤 Germany telecom', 'XETR:DTE', 'XETR-DTE', Colors.pinkAccent),
    countryLargeCapChartItem('deMunichRe', 'MUV2  Munich Re 뮌헨리 Germany insurance reinsurance', 'XETR:MUV2', 'XETR-MUV2', _cyan),
    countryLargeCapChartItem('deMercedes', 'MBG  Mercedes-Benz 메르세데스벤츠 Germany auto EV', 'XETR:MBG', 'XETR-MBG', Colors.lightBlueAccent),
    countryLargeCapChartItem('deBmw', 'BMW  BMW 비엠더블유 Germany auto EV', 'XETR:BMW', 'XETR-BMW', Colors.blueAccent),
    countryLargeCapChartItem('deVolkswagen', 'VOW3  Volkswagen 폭스바겐 Germany auto EV', 'XETR:VOW3', 'XETR-VOW3', Colors.indigoAccent),
    countryLargeCapChartItem('deBayer', 'BAYN  Bayer 바이엘 Germany pharma chemical', 'XETR:BAYN', 'XETR-BAYN', Colors.greenAccent),
    countryLargeCapChartItem('deBasf', 'BAS  BASF 바스프 Germany chemical materials', 'XETR:BAS', 'XETR-BAS', Colors.orangeAccent),
    countryLargeCapChartItem('deInfineon', 'IFX  Infineon 인피니언 Germany semiconductor chip', 'XETR:IFX', 'XETR-IFX', Colors.purpleAccent),
    countryLargeCapChartItem('dePorscheAg', 'P911  Porsche AG 포르쉐 Germany auto luxury EV', 'XETR:P911', 'XETR-P911', Colors.amberAccent),
    countryLargeCapChartItem('dePorscheHolding', 'PAH3  Porsche Holding 포르쉐홀딩 Germany auto investment', 'XETR:PAH3', 'XETR-PAH3', Colors.orangeAccent),
    countryLargeCapChartItem('deDeutscheBank', 'DBK  Deutsche Bank 도이체방크 Germany bank finance', 'XETR:DBK', 'XETR-DBK', _blue),
    countryLargeCapChartItem('deCommerzbank', 'CBK  Commerzbank 코메르츠방크 Germany bank finance', 'XETR:CBK', 'XETR-CBK', _cyan),
    countryLargeCapChartItem('deRheinmetall', 'RHM  Rheinmetall 라인메탈 Germany defense industrial', 'XETR:RHM', 'XETR-RHM', Colors.redAccent),
    countryLargeCapChartItem('deEon', 'EOAN  E.ON 이온 Germany utility energy power', 'XETR:EOAN', 'XETR-EOAN', Colors.pinkAccent),
    countryLargeCapChartItem('deRwe', 'RWE  RWE Germany utility renewable energy', 'XETR:RWE', 'XETR-RWE', Colors.greenAccent),
    countryLargeCapChartItem('deHenkel', 'HEN3  Henkel 헨켈 Germany consumer chemical', 'XETR:HEN3', 'XETR-HEN3', Colors.purpleAccent),
    countryLargeCapChartItem('deAdidas', 'ADS  Adidas 아디다스 Germany sports apparel', 'XETR:ADS', 'XETR-ADS', Colors.lightBlueAccent),
    countryLargeCapChartItem('deDhl', 'DHL  DHL Group 도이치포스트 Germany logistics delivery', 'XETR:DHL', 'XETR-DHL', Colors.yellowAccent),
    countryLargeCapChartItem('deHeidelberg', 'HEI  Heidelberg Materials 하이델베르크 Germany construction materials', 'XETR:HEI', 'XETR-HEI', Colors.blueGrey),
    countryLargeCapChartItem('deMerckKgaa', 'MRK  Merck KGaA 머크 Germany pharma chemical', 'XETR:MRK', 'XETR-MRK', Colors.tealAccent),
    countryLargeCapChartItem('frLoreal', 'OR  L Oreal 로레알 France cosmetics consumer', 'EURONEXT:OR', 'EURONEXT-OR', Colors.pinkAccent),
    countryLargeCapChartItem('frSanofi', 'SAN  Sanofi 사노피 France pharma healthcare', 'EURONEXT:SAN', 'EURONEXT-SAN', Colors.lightBlueAccent),
    countryLargeCapChartItem('frAirbus', 'AIR  Airbus 에어버스 France aerospace defense aviation', 'EURONEXT:AIR', 'EURONEXT-AIR', _blue),
    countryLargeCapChartItem('frSchneider', 'SU  Schneider Electric 슈나이더 France electric industrial', 'EURONEXT:SU', 'EURONEXT-SU', Colors.greenAccent),
    countryLargeCapChartItem('frBnp', 'BNP  BNP Paribas BNP파리바 France bank finance', 'EURONEXT:BNP', 'EURONEXT-BNP', _cyan),
    countryLargeCapChartItem('frAxa', 'CS  AXA 악사 France insurance finance', 'EURONEXT:CS', 'EURONEXT-CS', _purple),
    countryLargeCapChartItem('frVinci', 'DG  Vinci 빈치 France infrastructure construction', 'EURONEXT:DG', 'EURONEXT-DG', Colors.blueGrey),
    countryLargeCapChartItem('frEssilor', 'EL  EssilorLuxottica 에실로룩소티카 France healthcare eyewear', 'EURONEXT:EL', 'EURONEXT-EL', Colors.lightBlueAccent),
    countryLargeCapChartItem('frSafran', 'SAF  Safran 사프란 France aerospace defense aviation', 'EURONEXT:SAF', 'EURONEXT-SAF', Colors.blueAccent),
    countryLargeCapChartItem('frDassaultSystemes', 'DSY  Dassault Systemes 다쏘시스템 France software industrial', 'EURONEXT:DSY', 'EURONEXT-DSY', Colors.purpleAccent),
    countryLargeCapChartItem('frKering', 'KER  Kering 케링 France luxury consumer', 'EURONEXT:KER', 'EURONEXT-KER', Colors.pinkAccent),
    countryLargeCapChartItem('frDanone', 'BN  Danone 다논 France food consumer', 'EURONEXT:BN', 'EURONEXT-BN', Colors.lightGreenAccent),
    countryLargeCapChartItem('frPernod', 'RI  Pernod Ricard 페르노리카 France beverage consumer', 'EURONEXT:RI', 'EURONEXT-RI', Colors.orangeAccent),
    countryLargeCapChartItem('frEngie', 'ENGI  Engie 엔지 France utility energy', 'EURONEXT:ENGI', 'EURONEXT-ENGI', Colors.greenAccent),
    countryLargeCapChartItem('frLegrand', 'LR  Legrand 르그랑 France electric industrial', 'EURONEXT:LR', 'EURONEXT-LR', Colors.cyanAccent),
    countryLargeCapChartItem('frCapgemini', 'CAP  Capgemini 캡제미니 France IT software consulting', 'EURONEXT:CAP', 'EURONEXT-CAP', _blue),
    countryLargeCapChartItem('frCreditAgricole', 'ACA  Credit Agricole 크레디아그리콜 France bank finance', 'EURONEXT:ACA', 'EURONEXT-ACA', _cyan),
    countryLargeCapChartItem('frSocGen', 'GLE  Societe Generale 소시에테제네랄 France bank finance', 'EURONEXT:GLE', 'EURONEXT-GLE', _purple),
    countryLargeCapChartItem('frMichelin', 'ML  Michelin 미쉐린 France auto tire', 'EURONEXT:ML', 'EURONEXT-ML', Colors.blueGrey),
    countryLargeCapChartItem('frOrange', 'ORA  Orange 오랑주 France telecom', 'EURONEXT:ORA', 'EURONEXT-ORA', Colors.orangeAccent),
    countryLargeCapChartItem('frVeolia', 'VIE  Veolia 베올리아 France utility water infrastructure', 'EURONEXT:VIE', 'EURONEXT-VIE', Colors.tealAccent),
    countryLargeCapChartItem('esInditex', 'ITX  Inditex 인디텍스 Spain retail apparel Zara', 'BME:ITX', 'BME-ITX', Colors.greenAccent),
    countryLargeCapChartItem('esIberdrola', 'IBE  Iberdrola 이베르드롤라 Spain utility energy power', 'BME:IBE', 'BME-IBE', Colors.lightGreenAccent),
    countryLargeCapChartItem('esSantander', 'SAN  Banco Santander 산탄데르 Spain bank finance', 'BME:SAN', 'BME-SAN', Colors.redAccent),
    countryLargeCapChartItem('esBbva', 'BBVA  BBVA 비비바 Spain bank finance', 'BME:BBVA', 'BME-BBVA', _blue),
    countryLargeCapChartItem('esCaixa', 'CABK  CaixaBank 카이샤뱅크 Spain bank finance', 'BME:CABK', 'BME-CABK', _cyan),
    countryLargeCapChartItem('esTelefonica', 'TEF  Telefonica 텔레포니카 Spain telecom', 'BME:TEF', 'BME-TEF', Colors.indigoAccent),
    countryLargeCapChartItem('esAmadeus', 'AMS  Amadeus 아마데우스 Spain travel software', 'BME:AMS', 'BME-AMS', Colors.lightBlueAccent),
    countryLargeCapChartItem('esFerrovial', 'FER  Ferrovial 페로비알 Spain infrastructure construction', 'BME:FER', 'BME-FER', Colors.orangeAccent),
    countryLargeCapChartItem('esRepsol', 'REP  Repsol 렙솔 Spain oil energy', 'BME:REP', 'BME-REP', Colors.redAccent),
    countryLargeCapChartItem('esAcs', 'ACS  ACS Spain construction infrastructure', 'BME:ACS', 'BME-ACS', Colors.blueGrey),
    countryLargeCapChartItem('esAena', 'AENA  Aena 아에나 Spain airport infrastructure travel', 'BME:AENA', 'BME-AENA', Colors.lightBlueAccent),
    countryLargeCapChartItem('esNaturgy', 'NTGY  Naturgy 나투르지 Spain utility gas energy', 'BME:NTGY', 'BME-NTGY', Colors.greenAccent),
    countryLargeCapChartItem('esRedeia', 'RED  Redeia 레데이아 Spain utility power grid', 'BME:RED', 'BME-RED', Colors.pinkAccent),
    countryLargeCapChartItem('esEndesa', 'ELE  Endesa 엔데사 Spain utility energy power', 'BME:ELE', 'BME-ELE', Colors.yellowAccent),
    countryLargeCapChartItem('esCellnex', 'CLNX  Cellnex 셀넥스 Spain telecom infrastructure', 'BME:CLNX', 'BME-CLNX', Colors.cyanAccent),
    countryLargeCapChartItem('esGrifols', 'GRF  Grifols 그리폴스 Spain pharma healthcare', 'BME:GRF', 'BME-GRF', Colors.redAccent),
    countryLargeCapChartItem('esMapfre', 'MAP  Mapfre 마프레 Spain insurance finance', 'BME:MAP', 'BME-MAP', _blue),
    countryLargeCapChartItem('esAcciona', 'ANA  Acciona 악시오나 Spain infrastructure renewable energy', 'BME:ANA', 'BME-ANA', Colors.greenAccent),
    countryLargeCapChartItem('ptEdp', 'EDP  EDP Portugal utility energy power', 'EURONEXT:EDP', 'EURONEXT-EDP', Colors.greenAccent),
    countryLargeCapChartItem('ptGalp', 'GALP  Galp Energia 갈프 Portugal oil energy', 'EURONEXT:GALP', 'EURONEXT-GALP', Colors.orangeAccent),
    countryLargeCapChartItem('ptJeronimo', 'JMT  Jeronimo Martins 제로니모마르틴스 Portugal retail food', 'EURONEXT:JMT', 'EURONEXT-JMT', Colors.lightGreenAccent),
    countryLargeCapChartItem('ptBcp', 'BCP  Millennium BCP 밀레니엄BCP Portugal bank finance', 'EURONEXT:BCP', 'EURONEXT-BCP', _blue),
    countryLargeCapChartItem('ptEdpRenovaveis', 'EDPR  EDP Renovaveis EDP리뉴어블 Portugal renewable energy', 'EURONEXT:EDPR', 'EURONEXT-EDPR', Colors.cyanAccent),
    countryLargeCapChartItem('ptNos', 'NOS  NOS Portugal telecom media', 'EURONEXT:NOS', 'EURONEXT-NOS', Colors.purpleAccent),
    countryLargeCapChartItem('ruSber', 'SBER  Sberbank 스베르방크 Сбербанк Russia bank finance', 'MOEX:SBER', 'MOEX-SBER', Colors.greenAccent),
    countryLargeCapChartItem('ruGazprom', 'GAZP  Gazprom 가즈프롬 Газпром Russia gas energy', 'MOEX:GAZP', 'MOEX-GAZP', Colors.blueAccent),
    countryLargeCapChartItem('ruLukoil', 'LKOH  Lukoil 루코일 Лукойл Russia oil energy', 'MOEX:LKOH', 'MOEX-LKOH', Colors.redAccent),
    countryLargeCapChartItem('ruRosneft', 'ROSN  Rosneft 로스네프트 Роснефть Russia oil energy', 'MOEX:ROSN', 'MOEX-ROSN', Colors.orangeAccent),
    countryLargeCapChartItem('ruNovatek', 'NVTK  Novatek 노바텍 Новатэк Russia gas energy', 'MOEX:NVTK', 'MOEX-NVTK', Colors.cyanAccent),
    countryLargeCapChartItem('ruNornickel', 'GMKN  Nornickel 노르니켈 Норникель Russia mining nickel materials', 'MOEX:GMKN', 'MOEX-GMKN', Colors.blueGrey),
    countryLargeCapChartItem('ruYandex', 'YDEX  Yandex 얀덱스 Яндекс Russia internet AI search', 'MOEX:YDEX', 'MOEX-YDEX', Colors.amberAccent),
    countryLargeCapChartItem('ruTcs', 'TCSG  TCS Tinkoff 틴코프 Тинькофф Russia fintech bank', 'MOEX:TCSG', 'MOEX-TCSG', Colors.yellowAccent),
  ];

  @override
  State<ChartPage> createState() => _ChartPageState();
}

class _ChartPageState extends State<ChartPage> {
  static const _orderKey = 'chartItemOrder';
  static const _favoriteKey = 'favoriteChartItemIds';
  static const _defaultFavoriteChartIds = {
    'nasdaq100Futures',
    'qld',
    'tqqq',
  };
  late List<ChartListItem> chartItems = List.of(ChartPage.defaultChartItems);
  Set<String> favoriteChartIds = {};
  final chartSearchController = TextEditingController();
  final chartListController = ScrollController();
  final chartItemKeys = <String, GlobalKey>{};
  final chartSearchTextCache = <String, String>{};

  @override
  void initState() {
    super.initState();
    loadOrder();
  }

  @override
  void dispose() {
    chartSearchController.dispose();
    chartListController.dispose();
    super.dispose();
  }

  Future<void> loadOrder() async {
    final prefs = await SharedPreferences.getInstance();
    final savedOrder = prefs.getStringList(_orderKey);
    final savedFavorites = prefs.getStringList(_favoriteKey);

    favoriteChartIds = savedFavorites == null
        ? Set<String>.of(_defaultFavoriteChartIds)
        : savedFavorites.toSet();

    if (savedFavorites == null) {
      await prefs.setStringList(
        _favoriteKey,
        _defaultFavoriteChartIds.toList(),
      );
    }

    final byId = {
      for (final item in ChartPage.defaultChartItems) item.id: item,
    };
    final ordered = savedOrder == null || savedOrder.isEmpty
        ? <ChartListItem>[]
        : <ChartListItem>[
            for (final id in savedOrder)
              if (byId.containsKey(id)) byId[id]!,
          ];

    for (final item in ChartPage.defaultChartItems) {
      if (!ordered.any((orderedItem) => orderedItem.id == item.id)) {
        ordered.add(item);
      }
    }

    if (!mounted) return;
    setState(() {
      chartItems = sortedByFavorites(ordered);
      chartSearchTextCache.clear();
    });
    warmChartSearchCache();
  }

  void warmChartSearchCache() {
    Future.delayed(const Duration(milliseconds: 120), () {
      if (!mounted) return;

      for (final item in chartItems) {
        cachedSearchTextForItem(item);
      }
    });
  }

  Future<void> saveOrder() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _orderKey,
      chartItems.map((item) => item.id).toList(),
    );
  }

  Future<void> saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_favoriteKey, favoriteChartIds.toList());
  }

  List<ChartListItem> sortedByFavorites(List<ChartListItem> items) {
    final favorites = items
        .where((item) => favoriteChartIds.contains(item.id))
        .toList();
    final others = items
        .where((item) => !favoriteChartIds.contains(item.id))
        .toList();

    return [
      ...favorites,
      ...others,
    ];
  }

  Future<void> toggleFavorite(ChartListItem item) async {
    setState(() {
      if (favoriteChartIds.contains(item.id)) {
        favoriteChartIds.remove(item.id);
      } else {
        favoriteChartIds.add(item.id);
      }

      chartItems = sortedByFavorites(chartItems);
    });

    await saveFavorites();
    await saveOrder();

    if (favoriteChartIds.contains(item.id) &&
        chartListController.hasClients) {
      chartListController.animateTo(
        0,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
      );
    }
  }

  String badgeForItem(ChartListItem item) {
    switch (item.id) {
      case 'nasdaq100Futures':
        return 'NQ';
      case 'qld':
        return 'QLD';
      case 'tqqq':
        return 'TQQQ';
      case 'sp500':
        return 'SPX';
      case 'kospi':
        return 'KOSPI';
      case 'nikkei225':
        return 'N225';
      case 'ibex35':
        return 'IBEX';
      case 'psi':
        return 'PSI';
      case 'moex':
        return 'MOEX';
      case 'sseComposite':
        return 'SSE';
      case 'taiex':
        return 'TAIEX';
      case 'cac40':
        return 'CAC';
      case 'dax':
        return 'DAX';
      default:
        final symbol = item.subtitle.contains(':')
            ? item.subtitle.split(':').last
            : item.title;

        return symbol.length <= 5
            ? symbol.toUpperCase()
            : symbol.substring(0, 5).toUpperCase();
    }
  }

  GlobalKey keyForItem(String id) {
    return chartItemKeys.putIfAbsent(id, () => GlobalKey());
  }

  void jumpToSearchResult(String value) {
    final query = normalizeChartSearchText(value);

    if (query.isEmpty || !chartListController.hasClients) return;

    final expandedQueries = expandedChartSearchQueries(query);
    var index = chartItems.indexWhere((item) {
      return normalizedSearchTextMatchesExpandedQueries(
        cachedSearchTextForItem(item),
        expandedQueries,
      );
    });

    if (index < 0) {
      index = chartItems.indexWhere((item) {
        return normalizedSearchTextMatchesAnyExpandedQueryToken(
          cachedSearchTextForItem(item),
          expandedQueries,
        );
      });
    }


    if (index < 0) return;

    final maxOffset = chartListController.position.maxScrollExtent;
    final targetOffset = (index * 58.0).clamp(0.0, maxOffset);

    chartListController.jumpTo(targetOffset);
  }

  List<ChartListItem> filteredChartItems() {
    final query = normalizeChartSearchText(chartSearchController.text);

    if (query.isEmpty) return chartItems;

    final expandedQueries = expandedChartSearchQueries(query);
    final exactMatches = chartItems
        .where(
          (item) => normalizedSearchTextMatchesExpandedQueries(
            cachedSearchTextForItem(item),
            expandedQueries,
          ),
        )
        .toList();

    if (exactMatches.isNotEmpty) return exactMatches;

    return chartItems
        .where(
          (item) => normalizedSearchTextMatchesAnyExpandedQueryToken(
            cachedSearchTextForItem(item),
            expandedQueries,
          ),
        )
        .toList();
  }

  String cachedSearchTextForItem(ChartListItem item) {
    return chartSearchTextCache.putIfAbsent(
      item.id,
      () => normalizeChartSearchText(searchTextForItem(item)),
    );
  }

  String searchTextForItem(ChartListItem item) {
    final symbolTicker = item.symbolPath.contains('-')
        ? item.symbolPath.split('-').last
        : item.symbolPath;
    final ticker = item.subtitle.contains(':')
        ? item.subtitle.split(':').last
        : item.title.split(' ').first;
    final aliasKeys = {
      ticker,
      symbolTicker,
      item.id,
      item.symbolPath,
      item.symbolPath.replaceAll('-', ':'),
      item.symbolPath.replaceAll(':', '-'),
    };
    final aliases = aliasKeys
        .map((key) => _chartSearchAliases[key] ?? '')
        .where((alias) => alias.isNotEmpty)
        .join(' ');
    final universalAliases = aliasKeys
        .map((key) => _chartUniversalSearchAliases[key] ?? '')
        .where((alias) => alias.isNotEmpty)
        .join(' ');
    final extraAliases = aliasKeys
        .map((key) => _extraChartSearchAliases[key] ?? '')
        .where((alias) => alias.isNotEmpty)
        .join(' ');
    final commodityAliases = _commoditySearchAliases[item.id] ?? '';
    final localizedKeywordAliases = localizedChartKeywordAliasesForText([
      item.title,
      item.subtitle,
      item.id,
      item.symbolPath,
      symbolTicker,
      ticker,
      aliases,
      universalAliases,
      extraAliases,
      commodityAliases,
    ].join(' '));

    return [
      item.title,
      item.subtitle,
      item.id,
      item.symbolPath,
      symbolTicker,
      ticker,
      aliases,
      universalAliases,
      extraAliases,
      commodityAliases,
      localizedKeywordAliases,
    ].join(' ').toLowerCase();
  }

  void reorderItems(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }

    setState(() {
      final item = chartItems.removeAt(oldIndex);
      chartItems.insert(newIndex, item);
      chartItems = sortedByFavorites(chartItems);
    });

    saveOrder();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final visibleChartItems = filteredChartItems();
    final isSearching = chartSearchController.text.trim().isNotEmpty;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        title: Text(l10n.navChart),
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        actions: [
          buildLanguageMenuButton(context),
        ],
      ),
      bottomNavigationBar: buildFixedAdBottomBar(
        buildPersistentBottomNav(
          context,
          currentTab: NavTab.chart,
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 6),
            child: TextField(
              controller: chartSearchController,
              onChanged: (value) {
                setState(() {});
              },
              onSubmitted: jumpToSearchResult,
              textInputAction: TextInputAction.search,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                isDense: true,
                hintText: 'Search ticker',
                hintStyle: const TextStyle(
                  color: Colors.white38,
                  fontSize: 13,
                ),
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  color: Colors.white54,
                  size: 18,
                ),
                suffixIcon: chartSearchController.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(
                          Icons.close_rounded,
                          color: Colors.white54,
                          size: 17,
                        ),
                        onPressed: () {
                          chartSearchController.clear();
                          setState(() {});
                        },
                      ),
                filled: true,
                fillColor: const Color(0xFF151B24),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 9,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.white.withOpacity(0.08),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: _blue.withOpacity(0.65),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: ReorderableListView.builder(
        scrollController: chartListController,
        buildDefaultDragHandles: false,
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 144),
        itemCount: visibleChartItems.length,
        onReorder: isSearching ? (_, __) {} : reorderItems,
        itemBuilder: (context, index) {
          final item = visibleChartItems[index];
          final isFavorite = favoriteChartIds.contains(item.id);

          return Container(
            key: ValueKey(item.id),
            margin: const EdgeInsets.only(bottom: 6),
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => launchTradingViewPage(item.symbolPath),
              child: Container(
                key: keyForItem(item.id),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF151B24),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                  ),
                ),
                child: Row(
                  children: [
                    buildTickerBadge(
                      badgeForItem(item),
                      item.color,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            item.subtitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 34,
                      height: 32,
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        icon: Icon(
                          isFavorite
                              ? Icons.star_rounded
                              : Icons.star_border_rounded,
                          color: isFavorite
                              ? Colors.amberAccent
                              : Colors.white38,
                          size: 20,
                        ),
                        onPressed: () => toggleFavorite(item),
                      ),
                    ),
                    if (!isSearching)
                      ReorderableDelayedDragStartListener(
                        index: index,
                        child: const Padding(
                          padding: EdgeInsets.only(left: 10),
                          child: Icon(
                            Icons.drag_handle_rounded,
                            color: Colors.white38,
                            size: 20,
                          ),
                        ),
                      )
                    else
                      const Padding(
                        padding: EdgeInsets.only(left: 10),
                        child: Icon(
                          Icons.search_rounded,
                          color: Colors.white24,
                          size: 20,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
            ),
          ),
        ],
      ),
    );
  }
}

class ExchangePage extends StatefulWidget {
  const ExchangePage({super.key});

  static final defaultExchangeItems = [
    ExchangeListItem(
      id: 'usdIndex',
      symbolPath: 'TVC-DXY',
      color: _cyan,
      icon: Icons.attach_money_rounded,
    ),
    ExchangeListItem(
      id: 'usdKrw',
      symbolPath: 'FX_IDC-USDKRW',
      color: Colors.greenAccent,
      icon: Icons.attach_money_rounded,
    ),
    ExchangeListItem(
      id: 'usdJpy',
      symbolPath: 'FX-USDJPY',
      color: Colors.orangeAccent,
      icon: Icons.currency_yen_rounded,
    ),
    ExchangeListItem(
      id: 'eurUsd',
      symbolPath: 'FX-EURUSD',
      color: _blue,
      icon: Icons.euro_rounded,
    ),
    ExchangeListItem(
      id: 'usdRub',
      symbolPath: 'FX_IDC-USDRUB',
      color: Colors.redAccent,
      icon: Icons.currency_ruble_rounded,
    ),
    ExchangeListItem(
      id: 'usdTwd',
      symbolPath: 'FX_IDC-USDTWD',
      color: _purple,
      icon: Icons.paid_rounded,
    ),
    ExchangeListItem(
      id: 'usdCny',
      symbolPath: 'FX_IDC-USDCNY',
      color: Colors.amberAccent,
      icon: Icons.currency_yuan_rounded,
    ),
    ExchangeListItem(
      id: 'btcUsd',
      symbolPath: 'BITSTAMP-BTCUSD',
      color: Colors.amberAccent,
      icon: Icons.currency_bitcoin_rounded,
    ),
    exchangeCurrencyItem('usdGbp', 'GBP', Colors.lightBlueAccent),
    exchangeCurrencyItem('usdCad', 'CAD', Colors.redAccent),
    exchangeCurrencyItem('usdAud', 'AUD', Colors.greenAccent),
    exchangeCurrencyItem('usdNzd', 'NZD', Colors.tealAccent),
    exchangeCurrencyItem('usdChf', 'CHF', Colors.pinkAccent),
    exchangeCurrencyItem('usdSek', 'SEK', _blue),
    exchangeCurrencyItem('usdNok', 'NOK', _cyan),
    exchangeCurrencyItem('usdDkk', 'DKK', _purple),
    exchangeCurrencyItem('usdPln', 'PLN', Colors.orangeAccent),
    exchangeCurrencyItem('usdCzk', 'CZK', Colors.amberAccent),
    exchangeCurrencyItem('usdHuf', 'HUF', Colors.lightBlueAccent),
    exchangeCurrencyItem('usdTry', 'TRY', Colors.redAccent),
    exchangeCurrencyItem('usdMxn', 'MXN', Colors.greenAccent),
    exchangeCurrencyItem('usdBrl', 'BRL', Colors.tealAccent),
    exchangeCurrencyItem('usdArs', 'ARS', Colors.pinkAccent),
    exchangeCurrencyItem('usdClp', 'CLP', _blue),
    exchangeCurrencyItem('usdCop', 'COP', _cyan),
    exchangeCurrencyItem('usdPen', 'PEN', _purple),
    exchangeCurrencyItem('usdZar', 'ZAR', Colors.orangeAccent),
    exchangeCurrencyItem('usdEgp', 'EGP', Colors.amberAccent),
    exchangeCurrencyItem('usdSar', 'SAR', Colors.lightBlueAccent),
    exchangeCurrencyItem('usdAed', 'AED', Colors.redAccent),
    exchangeCurrencyItem('usdQar', 'QAR', Colors.greenAccent),
    exchangeCurrencyItem('usdKwd', 'KWD', Colors.tealAccent),
    exchangeCurrencyItem('usdIls', 'ILS', Colors.pinkAccent),
    exchangeCurrencyItem('usdInr', 'INR', _blue),
    exchangeCurrencyItem('usdIdr', 'IDR', _cyan),
    exchangeCurrencyItem('usdThb', 'THB', _purple),
    exchangeCurrencyItem('usdVnd', 'VND', Colors.orangeAccent),
    exchangeCurrencyItem('usdPhp', 'PHP', Colors.amberAccent),
    exchangeCurrencyItem('usdMyr', 'MYR', Colors.lightBlueAccent),
    exchangeCurrencyItem('usdSgd', 'SGD', Colors.redAccent),
    exchangeCurrencyItem('usdHkd', 'HKD', Colors.greenAccent),
    exchangeCurrencyItem('usdPkr', 'PKR', Colors.tealAccent),
    exchangeCurrencyItem('usdBdt', 'BDT', Colors.pinkAccent),
    exchangeCurrencyItem('usdLkr', 'LKR', _blue),
    exchangeCurrencyItem('usdKzt', 'KZT', _cyan),
    exchangeCurrencyItem('usdUah', 'UAH', _purple),
    exchangeCurrencyItem('usdRon', 'RON', Colors.orangeAccent),
    exchangeCurrencyItem('usdBgn', 'BGN', Colors.amberAccent),
    exchangeCurrencyItem('usdIsk', 'ISK', Colors.lightBlueAccent),
    exchangeCurrencyItem('usdMad', 'MAD', Colors.redAccent),
    exchangeCurrencyItem('usdNgn', 'NGN', Colors.greenAccent),
    exchangeCurrencyItem('usdKes', 'KES', Colors.tealAccent),
  ];

  @override
  State<ExchangePage> createState() => _ExchangePageState();
}

class _ExchangePageState extends State<ExchangePage> {
  static const _orderKey = 'exchangeItemOrder';
  static const _favoriteKey = 'favoriteExchangeItemIds';
  late List<ExchangeListItem> exchangeItems =
      List.of(ExchangePage.defaultExchangeItems);
  Set<String> favoriteExchangeIds = {};
  final exchangeSearchController = TextEditingController();
  final exchangeListController = ScrollController();
  final exchangeItemKeys = <String, GlobalKey>{};
  Timer? exchangeSearchDebounce;

  @override
  void initState() {
    super.initState();
    loadOrder();
  }

  @override
  void dispose() {
    exchangeSearchDebounce?.cancel();
    exchangeSearchController.dispose();
    exchangeListController.dispose();
    super.dispose();
  }

  Future<void> loadOrder() async {
    final prefs = await SharedPreferences.getInstance();
    final savedOrder = prefs.getStringList(_orderKey);
    favoriteExchangeIds =
        (prefs.getStringList(_favoriteKey) ?? []).toSet();

    final byId = {
      for (final item in ExchangePage.defaultExchangeItems) item.id: item,
    };
    final ordered = savedOrder == null || savedOrder.isEmpty
        ? <ExchangeListItem>[]
        : <ExchangeListItem>[
            for (final id in savedOrder)
              if (byId.containsKey(id)) byId[id]!,
          ];

    for (final item in ExchangePage.defaultExchangeItems) {
      if (!ordered.any((orderedItem) => orderedItem.id == item.id)) {
        ordered.add(item);
      }
    }

    if (!mounted) return;
    setState(() {
      exchangeItems = sortedByFavorites(ordered);
    });
  }

  Future<void> saveOrder() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _orderKey,
      exchangeItems.map((item) => item.id).toList(),
    );
  }

  Future<void> saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_favoriteKey, favoriteExchangeIds.toList());
  }

  List<ExchangeListItem> sortedByFavorites(List<ExchangeListItem> items) {
    final favorites = items
        .where((item) => favoriteExchangeIds.contains(item.id))
        .toList();
    final others = items
        .where((item) => !favoriteExchangeIds.contains(item.id))
        .toList();

    return [
      ...favorites,
      ...others,
    ];
  }

  Future<void> toggleFavorite(ExchangeListItem item) async {
    setState(() {
      if (favoriteExchangeIds.contains(item.id)) {
        favoriteExchangeIds.remove(item.id);
      } else {
        favoriteExchangeIds.add(item.id);
      }

      exchangeItems = sortedByFavorites(exchangeItems);
    });

    await saveFavorites();
    await saveOrder();

    if (favoriteExchangeIds.contains(item.id) &&
        exchangeListController.hasClients) {
      exchangeListController.animateTo(
        0,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
      );
    }
  }

  void reorderItems(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }

    setState(() {
      final item = exchangeItems.removeAt(oldIndex);
      exchangeItems.insert(newIndex, item);
      exchangeItems = sortedByFavorites(exchangeItems);
    });

    saveOrder();
  }

  String titleForKey(AppLocalizations l10n, String key) {
    switch (key) {
      case 'usdIndex':
        return 'US Dollar Index';
      case 'usdKrw':
        return l10n.exchangeUsdKrw;
      case 'usdJpy':
        return l10n.exchangeUsdJpy;
      case 'eurUsd':
        return '${l10n.exchangeEurUsd} (EU)';
      case 'usdRub':
        return l10n.exchangeUsdRub;
      case 'usdTwd':
        return l10n.exchangeUsdTwd;
      case 'usdCny':
        return l10n.exchangeUsdCny;
      case 'btcUsd':
        return 'Bitcoin';
      default:
        final info = _exchangeSearchInfo[key];
        if (info == null) return key;

        return 'USD/${info[0]}  ${info[1]}';
    }
  }

  String symbolTextForKey(String key) {
    switch (key) {
      case 'usdIndex':
        return 'DXY - United States';
      case 'usdKrw':
        return 'USD/KRW - Korea';
      case 'usdJpy':
        return 'USD/JPY - Japan';
      case 'eurUsd':
        return 'EUR/USD - Spain / Portugal / France / Germany';
      case 'usdRub':
        return 'USD/RUB - Russia';
      case 'usdTwd':
        return 'USD/TWD - Taiwan';
      case 'usdCny':
        return 'USD/CNY - China';
      case 'btcUsd':
        return 'BTC/USD';
      default:
        final info = _exchangeSearchInfo[key];
        if (info == null) return key;

        return 'USD/${info[0]} - ${info[1]}';
    }
  }

  String badgeForItem(ExchangeListItem item) {
    switch (item.id) {
      case 'usdIndex':
        return 'DXY';
      case 'usdKrw':
        return 'KRW';
      case 'usdJpy':
        return 'JPY';
      case 'eurUsd':
        return 'EUR';
      case 'usdRub':
        return 'RUB';
      case 'usdTwd':
        return 'TWD';
      case 'usdCny':
        return 'CNY';
      case 'btcUsd':
        return 'BTC';
      default:
        return _exchangeSearchInfo[item.id]?[0] ?? item.id.toUpperCase();
    }
  }

  GlobalKey keyForItem(String id) {
    return exchangeItemKeys.putIfAbsent(id, () => GlobalKey());
  }

  String searchTextForItem(
    AppLocalizations l10n,
    ExchangeListItem item,
  ) {
    final info = _exchangeSearchInfo[item.id];

    return [
      titleForKey(l10n, item.id),
      symbolTextForKey(item.id),
      item.id,
      item.symbolPath,
      if (info != null) ...info,
    ].join(' ').toLowerCase();
  }

  void scheduleSearchJump(String value) {
    exchangeSearchDebounce?.cancel();

    if (value.trim().isEmpty) return;

    exchangeSearchDebounce = Timer(
      const Duration(milliseconds: 260),
      () => jumpToSearchResult(value),
    );
  }

  void jumpToSearchResult(String value) {
    final query = value.trim().toLowerCase();
    final l10n = AppLocalizations.of(context)!;

    if (query.isEmpty || !exchangeListController.hasClients) return;

    final index = exchangeItems.indexWhere((item) {
      return matchesSearchQuery(searchTextForItem(l10n, item), query);
    });

    if (index < 0) return;

    final maxOffset = exchangeListController.position.maxScrollExtent;
    final targetOffset = (index * 58.0).clamp(0.0, maxOffset);

    exchangeListController.animateTo(
      targetOffset,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );

    Future.delayed(const Duration(milliseconds: 320), () {
      final context = exchangeItemKeys[exchangeItems[index].id]?.currentContext;

      if (context == null) return;

      Scrollable.ensureVisible(
        context,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        alignment: 0.12,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        title: Text(l10n.navExchange),
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        actions: [
          buildLanguageMenuButton(context),
        ],
      ),
      bottomNavigationBar: buildFixedAdBottomBar(
        buildPersistentBottomNav(
          context,
          currentTab: NavTab.exchange,
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 6),
            child: TextField(
              controller: exchangeSearchController,
              onChanged: (value) {
                setState(() {});
                scheduleSearchJump(value);
              },
              onSubmitted: jumpToSearchResult,
              textInputAction: TextInputAction.search,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                isDense: true,
                hintText: 'Search FX',
                hintStyle: const TextStyle(
                  color: Colors.white38,
                  fontSize: 13,
                ),
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  color: Colors.white54,
                  size: 18,
                ),
                suffixIcon: exchangeSearchController.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(
                          Icons.close_rounded,
                          color: Colors.white54,
                          size: 17,
                        ),
                        onPressed: () {
                          exchangeSearchController.clear();
                          setState(() {});
                        },
                      ),
                filled: true,
                fillColor: const Color(0xFF151B24),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 9,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.white.withOpacity(0.08),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: _blue.withOpacity(0.65),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: ReorderableListView.builder(
        scrollController: exchangeListController,
        buildDefaultDragHandles: false,
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 144),
        itemCount: exchangeItems.length,
        onReorder: reorderItems,
        itemBuilder: (context, index) {
          final item = exchangeItems[index];
          final title = titleForKey(l10n, item.id);
          final subtitle = symbolTextForKey(item.id);
          final isFavorite = favoriteExchangeIds.contains(item.id);

          return Container(
            key: ValueKey(item.id),
            margin: const EdgeInsets.only(bottom: 6),
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => launchTradingViewPage(item.symbolPath),
              child: Container(
                key: keyForItem(item.id),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF151B24),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                  ),
                ),
                child: Row(
                  children: [
                    buildTickerBadge(
                      badgeForItem(item),
                      item.color,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            subtitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 34,
                      height: 32,
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        icon: Icon(
                          isFavorite
                              ? Icons.star_rounded
                              : Icons.star_border_rounded,
                          color: isFavorite
                              ? Colors.amberAccent
                              : Colors.white38,
                          size: 20,
                        ),
                        onPressed: () => toggleFavorite(item),
                      ),
                    ),
                    ReorderableDelayedDragStartListener(
                      index: index,
                      child: const Padding(
                        padding: EdgeInsets.only(left: 10),
                        child: Icon(
                          Icons.drag_handle_rounded,
                          color: Colors.white38,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
            ),
          ),
        ],
      ),
    );
  }
}

class StrategyPage extends StatelessWidget {
  const StrategyPage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.buyStrategy,
        ),
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        actions: [
          buildLanguageMenuButton(context),
        ],
      ),
      bottomNavigationBar: buildFixedAdBottomBar(
        buildPersistentBottomNav(
          context,
          currentTab: NavTab.strategy,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 144),
        children: [
          buildStrategyCard(
            context: context,
            color: Colors.blueGrey,
            percent: '0% ~ -20%',
            text: AppLocalizations.of(context)!.noBuyZone,
            page: const NoBuyZonePage(),
          ),
          buildStrategyCard(
            context: context,
            color: Colors.green,
            percent: '-20%',
            text: AppLocalizations.of(context)!.minus20Headline,
            page: const Minus20Page(),
          ),
          buildStrategyCard(
            context: context,
            color: Colors.orange,
            percent: '-30%',
            text: AppLocalizations.of(context)!.minus30Headline,
            page: const Minus30Page(),
          ),
          buildStrategyCard(
            context: context,
            color: Colors.red,
            percent: '-40%',
            text: AppLocalizations.of(context)!.minus40Headline,
            page: const Minus40Page(),
          ),
          buildStrategyCard(
            context: context,
            color: Colors.purple,
            percent: '-50%',
            text: AppLocalizations.of(context)!.minus50Headline,
            page: const Minus50Page(),
          ),
        ],
      ),
    );
  }

  Widget buildStrategyCard(
    {
    required BuildContext context,
    required Color color,
    required String percent,
    required String text,
    required Widget page,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => page,
            ),
          );
        },
        child: Container(
          constraints: const BoxConstraints(
          minHeight: 76,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 12,
          ),
          decoration: BoxDecoration(
            color: const Color(0xFF151B24),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 5,
                height: 44,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 88,
                child: Text(
                  percent,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  text,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    height: 1.35,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              const Icon(
                Icons.chevron_right_rounded,
                color: Colors.white38,
                size: 28,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget strategyDetailCard({
  required Color accent,
  required String title,
  required String text,
}) {
  return Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.fromLTRB(16, 15, 16, 16),
    decoration: BoxDecoration(
      color: const Color(0xFF151B24),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(
        color: Colors.white.withOpacity(0.08),
      ),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 4,
              height: 22,
              decoration: BoxDecoration(
                color: accent,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: accent,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  height: 1.25,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            height: 1.55,
          ),
        ),
      ],
    ),
  );
}

String localizedStrategyHeadline(
  AppLocalizations l10n,
  String zone,
  String fallback,
) {
  switch (zone) {
    case '0% ~ -20%':
      return l10n.noBuyHeadline;
    case '-20%':
      return l10n.minus20Headline;
    case '-30%':
      return l10n.minus30Headline;
    case '-40%':
      return l10n.minus40Headline;
    case '-50%':
      return l10n.minus50Headline;
    default:
      return fallback;
  }
}

List<({String title, String text})> localizedStrategyActions(
  AppLocalizations l10n,
  String zone,
  List<({String title, String text})> fallback,
) {
  switch (zone) {
    case '0% ~ -20%':
      return [
        (title: l10n.noBuyActionTitle, text: l10n.noBuyActionText),
        (title: l10n.noBuyCashTitle, text: l10n.noBuyCashText),
        (title: l10n.noBuyAvoidTitle, text: l10n.noBuyAvoidText),
        (title: l10n.noBuyNextTitle, text: l10n.noBuyNextText),
      ];
    case '-20%':
      return [
        (title: l10n.minus20ActionTitle, text: l10n.minus20ActionText),
        (title: l10n.minus20BuyRuleTitle, text: l10n.minus20BuyRuleText),
        (title: l10n.minus20CashTitle, text: l10n.minus20CashText),
        (title: l10n.minus20AvoidTitle, text: l10n.minus20AvoidText),
      ];
    case '-30%':
      return [
        (title: l10n.minus30ActionTitle, text: l10n.minus30ActionText),
        (title: l10n.minus30BuyRuleTitle, text: l10n.minus30BuyRuleText),
        (
          title: l10n.minus30AdditionalTitle,
          text: l10n.minus30AdditionalText,
        ),
        (title: l10n.minus30AvoidTitle, text: l10n.minus30AvoidText),
      ];
    case '-40%':
      return [
        (title: l10n.minus40ActionTitle, text: l10n.minus40ActionText),
        (title: l10n.minus40BuyRuleTitle, text: l10n.minus40BuyRuleText),
        (title: l10n.minus40HoldTitle, text: l10n.minus40HoldText),
        (title: l10n.minus40AvoidTitle, text: l10n.minus40AvoidText),
      ];
    case '-50%':
      return [
        (title: l10n.minus50ActionTitle, text: l10n.minus50ActionText),
        (title: l10n.minus50BuyRuleTitle, text: l10n.minus50BuyRuleText),
        (title: l10n.minus50AfterTitle, text: l10n.minus50AfterText),
        (title: l10n.minus50AvoidTitle, text: l10n.minus50AvoidText),
      ];
    default:
      return fallback;
  }
}

Widget strategyActionPage({
  required BuildContext context,
  required String appBarTitle,
  required String zone,
  required String headline,
  required Color accent,
  required IconData icon,
  required List<({String title, String text})> actions,
}) {
  final l10n = AppLocalizations.of(context)!;
  final displayedHeadline = localizedStrategyHeadline(
    l10n,
    zone,
    headline,
  );
  final displayedActions = localizedStrategyActions(
    l10n,
    zone,
    actions,
  );

  return Scaffold(
    backgroundColor: const Color(0xFF0D1117),
    appBar: AppBar(
      title: Text(appBarTitle),
      backgroundColor: const Color(0xFF0D1117),
      elevation: 0,
      actions: [
        buildLanguageMenuButton(context),
      ],
    ),
    bottomNavigationBar: buildFixedAdBottomBar(
      buildPersistentBottomNav(
        context,
        currentTab: NavTab.strategy,
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 144),
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
          decoration: BoxDecoration(
            color: const Color(0xFF151B24),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: accent.withOpacity(0.55)),
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withOpacity(0.14),
                  border: Border.all(color: accent.withOpacity(0.45)),
                ),
                child: Icon(icon, color: accent, size: 25),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      zone,
                      style: TextStyle(
                        color: accent,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      displayedHeadline,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        for (final action in displayedActions)
          strategyDetailCard(
            accent: accent,
            title: action.title,
            text: action.text,
          ),
      ],
    ),
  );
}

class NoBuyZonePage extends StatelessWidget {
  const NoBuyZonePage({super.key});

  @override
  Widget build(BuildContext context) {
    return strategyActionPage(
      context: context,
      appBarTitle: AppLocalizations.of(context)!.noBuyZone,
      zone: '0% ~ -20%',
      headline: '추가 매수 금지, 현금 30% 유지',
      accent: Colors.blueAccent,
      icon: Icons.lock_outline_rounded,
      actions: const [
        (
          title: '즉시 행동',
          text: '신규 QLD/TQQQ 매수는 하지 않습니다. 기존 QLD 비중을 유지하고 현금 30%를 지킵니다.',
        ),
        (
          title: '현금 기준',
          text: '현금은 다음 하락 구간을 위한 탄약입니다. 상승장이더라도 현금을 줄이지 않습니다.',
        ),
        (
          title: '금지 행동',
          text: '가격이 오른다고 추격 매수하지 않습니다. -20% 구간이 오기 전까지는 기다립니다.',
        ),
        (
          title: '다음 준비',
          text: '-20%에 도달하면 소수점 단위로 QLD 적립 매수를 시작할 준비를 합니다.',
        ),
      ],
    );
  }
}

class Minus20Page extends StatelessWidget {
  const Minus20Page({super.key});

  @override
  Widget build(BuildContext context) {
    return strategyActionPage(
      context: context,
      appBarTitle: AppLocalizations.of(context)!.minus20Title,
      zone: '-20%',
      headline: AppLocalizations.of(context)!.minus20Headline,
      accent: Colors.greenAccent,
      icon: Icons.savings_outlined,
      actions: const [
        (
          title: '즉시 행동',
          text: 'QLD를 소수점 단위로 아주 작게 적립 매수합니다. 큰 금액을 한 번에 넣지 않습니다.',
        ),
        (
          title: '매수 기준',
          text: '전체 현금 중 아주 일부만 사용합니다. 핵심은 진입이 아니라 리듬을 시작하는 것입니다.',
        ),
        (
          title: '현금 관리',
          text: '대부분의 현금은 반드시 남깁니다. -30%, -40%, -50% 구간을 대비해야 합니다.',
        ),
        (
          title: '금지 행동',
          text: 'TQQQ를 성급하게 크게 사지 않습니다. -20%는 아직 초입 구간입니다.',
        ),
      ],
    );
  }
}
class Minus30Page extends StatelessWidget {
  const Minus30Page({super.key});

  @override
  Widget build(BuildContext context) {
    return strategyActionPage(
      context: context,
      appBarTitle: AppLocalizations.of(context)!.minus30Title,
      zone: '-30%',
      headline: AppLocalizations.of(context)!.minus30Headline,
      accent: Colors.orangeAccent,
      icon: Icons.trending_down_rounded,
      actions: const [
        (
          title: '즉시 행동',
          text: '보유 현금의 10%만 사용해서 TQQQ를 매수합니다. 주문 전 현금 총액을 먼저 확인합니다.',
        ),
        (
          title: '매수 기준',
          text: '현금이 \$10,000이면 \$1,000만 TQQQ에 사용합니다. 남은 90% 현금은 반드시 보존합니다.',
        ),
        (
          title: '추가 행동',
          text: 'QLD 적립 매수는 유지할 수 있지만, TQQQ 추가 매수는 다음 구간까지 기다립니다.',
        ),
        (
          title: '금지 행동',
          text: '반등을 확신하고 현금을 크게 쓰지 않습니다. -40% 구간이 올 수 있다는 전제로 움직입니다.',
        ),
      ],
    );
  }
}
class Minus40Page extends StatelessWidget {
  const Minus40Page({super.key});

  @override
  Widget build(BuildContext context) {
    return strategyActionPage(
      context: context,
      appBarTitle: AppLocalizations.of(context)!.minus40Title,
      zone: '-40%',
      headline: AppLocalizations.of(context)!.minus40Headline,
      accent: Colors.redAccent,
      icon: Icons.warning_amber_rounded,
      actions: const [
        (
          title: '즉시 행동',
          text: '남은 현금 중 30%를 TQQQ 매수에 사용합니다. 이미 -30%에서 사용한 금액은 제외하고 계산합니다.',
        ),
        (
          title: '매수 기준',
          text: '남은 현금이 \$9,000이면 \$2,700만 사용합니다. 한 번에 모두 쓰지 않는 것이 핵심입니다.',
        ),
        (
          title: '보유 기준',
          text: 'QLD는 유지하고, TQQQ는 계획된 비중까지만 늘립니다. 추가 하락을 전제로 현금을 남깁니다.',
        ),
        (
          title: '금지 행동',
          text: '공포 때문에 기존 보유분을 던지지 않습니다. 동시에 욕심 때문에 전액 매수하지도 않습니다.',
        ),
      ],
    );
  }
}
class Minus50Page extends StatelessWidget {
  const Minus50Page({super.key});

  @override
  Widget build(BuildContext context) {
    return strategyActionPage(
      context: context,
      appBarTitle: AppLocalizations.of(context)!.minus50Title,
      zone: '-50%',
      headline: AppLocalizations.of(context)!.minus50Headline,
      accent: Colors.purpleAccent,
      icon: Icons.bolt_rounded,
      actions: const [
        (
          title: '즉시 행동',
          text: '보유한 남은 현금 전체를 TQQQ 매수에 사용합니다. 이 구간은 현금 투입의 마지막 단계입니다.',
        ),
        (
          title: '매수 기준',
          text: '-30%, -40%에서 이미 사용한 금액을 제외하고 실제 남아 있는 현금만 기준으로 합니다.',
        ),
        (
          title: '이후 행동',
          text: '추가 현금이 생기면 정기적으로 TQQQ 또는 QLD를 적립합니다. 평균 단가를 낮추는 데 집중합니다.',
        ),
        (
          title: '금지 행동',
          text: '손실률만 보고 포기하지 않습니다. 다만 빚이나 단기 생활자금으로 추가 매수하지 않습니다.',
        ),
      ],
    );
  }
}
class StrategyBannerAd extends StatefulWidget {
  const StrategyBannerAd({super.key});

  @override
  State<StrategyBannerAd> createState() => _StrategyBannerAdState();
}

class _StrategyBannerAdState extends State<StrategyBannerAd> {
  BannerAd? _bannerAd;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
  debugPrint('전략 배너 광고 시작');
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-8561157852710726/9908440913',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (!mounted) return;
          setState(() {
            _loaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
           debugPrint('배너 광고 실패: ${error.code} / ${error.message}');
          ad.dispose();
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _bannerAd == null) {
      return const SizedBox(height: 50);
    }

    return Center(
      child: SizedBox(
        width: _bannerAd!.size.width.toDouble(),
        height: _bannerAd!.size.height.toDouble(),
        child: AdWidget(ad: _bannerAd!),
      ),
    );
  }
}
